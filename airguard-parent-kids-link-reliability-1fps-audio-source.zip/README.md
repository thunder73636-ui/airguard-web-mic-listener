# AirGuard Android and Web Mic Source

This source package contains the AirGuard Parent and Kids Android projects plus the Django website that streams browser microphone audio to the Parent app.

## Android configuration

Before building, put your Firebase Android configuration at `latest-parent/app/google-services.json` and `latest-kids/app/google-services.json`. Those project-specific files and debug keystores are intentionally not included in this public source package. Configure TURN values using each Android project's `.env.example` if relay connectivity is needed.

## Web microphone sender

The Django website is in `django_mic_web/`. Follow its README. Start the web mic, then in Parent go to **Device → Website Mic Listener** and enter the session code. Browser microphone capture requires user permission, and a deployed website must use HTTPS.

The website uses `web_audio_sessions` in the same Firestore database as the Parent app. The Django `.env` must point to that Firebase project and its Firestore rules must allow access to these session documents and candidate subcollections.
