# AirGuard source bundle

This archive contains the Android Studio project source and Firebase Android app config for this app. Open this folder in Android Studio to build it.

## Pairing, ownership, and presence

Pairing sessions expire after 15 minutes. The child app checks with Firestore directly and reports a clear timeout or error instead of waiting forever. The child writes its parent Firebase UID onto its device record before completing pairing. The parent imports and listens only to records owned by the currently signed-in Firebase UID, so one parent's devices do not appear in another parent's app. Multiple child devices can be paired to one parent account.

The child keeps its paired device ID in app storage and resumes the foreground link service on app launch and after reboot. The child sends presence every 30 seconds and immediately after a validated network returns; brief timed wake locks protect each presence write from Doze. Battery optimization remains a user-controlled Android setting. Parent device data is merged into Room and kept visible while offline; a successful server sync removes local rows that were explicitly deleted from Firestore. The parent treats a device as online only when its heartbeat is no older than two minutes. If the parent app has notification permission, it posts a local alert when the Firestore listener observes a child transition from offline to online. This local listener cannot deliver alerts after Android has terminated the parent process; that requires a trusted push sender such as Firebase Cloud Functions/FCM.

Each live camera or microphone request gets a fresh random session token. The parent retries failed or dropped media connections with increasing delays. The child keeps listening for new requests and accepts a fresh request after reconnecting. Hardware permission prompts still require the child user to approve Android's camera or microphone permission.

Unlinking verifies device ownership, removes cloud pairing and remote-request records, then removes the device and local associated data. The child clears its saved link when Firestore reports that its device record was deleted. Existing paired child installs also send their saved parent UID on their next heartbeat so records created before ownership scoping can be recovered.

## Firebase rules

The included `firestore.rules` file is a development sample that grants broad read/write access. Do not deploy it to a real Firebase project. Account scoping in the apps is not a substitute for server-side authorization. Configure rules that verify Firebase Authentication and ownership for every collection before using real family data.

## Build notes

These are debug builds signed with the included Android debug keystore. They are for installation and development, not Google Play release. The Kids APK is one installable file that includes both common Android phone CPU architectures, `arm64-v8a` and `armeabi-v7a`, and omits x86 native libraries to reduce its size. x86-only devices are not supported by that APK. For Play Store distribution, build an Android App Bundle with the release signing key so Play can deliver ABI-specific optimized downloads. Keep each app's package ID and signing key stable when installing updates; installing as an update preserves local app data, while uninstalling clears Android app storage.

## No-reset setup and Android controls

Pairing and the app-level monitoring features do not require a factory reset. The child user must approve each Android permission or special access in system settings. The parent app can display reported status but cannot grant those permissions remotely.

Device-owner mode is not enabled by this app. Android only allows a DPC to become device owner during managed-device provisioning on an eligible, unprovisioned device. This is separate from standard AirGuard setup and cannot be enabled for a normally configured device without reprovisioning it. Without device-owner privileges, AirGuard cannot enforce system-wide install or uninstall restrictions or unlock the Android lock screen.
