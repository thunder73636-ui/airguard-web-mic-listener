# TURN relay setup

The apps use Firebase Firestore for signaling and WebRTC ICE for media. A TURN relay is used only when direct peer-to-peer ICE is blocked, and the same relay credentials must be configured in both Parent and Kids builds.

Set these Gradle properties in the user's Gradle properties file (normally `%USERPROFILE%\.gradle\gradle.properties`) or set environment variables before building both apps:

```properties
TURN_SERVER_URL=turn:turn.example.net:3478?transport=udp,turns:turn.example.net:5349?transport=tcp
TURN_USERNAME=short-lived-username
TURN_CREDENTIAL=short-lived-credential
```

`TURN_SERVER_URL` accepts comma, semicolon, or newline separated `turn:` / `turns:` URLs. The project will add each endpoint to WebRTC; the Parent's relay retry uses relay candidates only. Build each project again after changing settings:

```powershell
gradle assembleDebug
```

Do not commit real TURN credentials. Values compiled into an Android APK can be extracted, so production deployments should issue short-lived TURN credentials from an authenticated backend. These projects do not provision a TURN server or mint credentials; a reachable TURN service and valid credentials are required for relay connectivity.
