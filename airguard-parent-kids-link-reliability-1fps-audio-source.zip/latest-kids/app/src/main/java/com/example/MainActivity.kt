package com.example

import android.content.pm.PackageManager
import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.repository.ChildSyncRepository
import com.example.ui.components.WebRtcHardwarePermissionDialog
import com.example.ui.screens.ChildDashboardScreen
import com.example.ui.screens.PairingStartScreen
import com.example.ui.screens.PermissionWizardScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

enum class ChildScreenDestination {
    PAIRING_START,
    PERMISSION_WIZARD,
    DASHBOARD
}

class MainActivity : ComponentActivity() {

    private lateinit var repository: ChildSyncRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        repository = ChildSyncRepository.getInstance(this)
        if (repository.isDevicePaired()) {
            com.example.service.AirGuardMediaCaptureService.start(this)
        }

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AirGuardKidsApp(repository = repository)
                }
            }
        }
    }
}

@Composable
fun AirGuardKidsApp(repository: ChildSyncRepository) {
    val context = LocalContext.current
    val navController = rememberNavController()

    val isAlreadyPaired = remember { repository.isDevicePaired() }
    val initialPermissions = remember { repository.checkPermissionState() }

    val pendingPermissionPrompt by repository.mediaSignalingManager.pendingPermissionPrompt.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    val startupRuntimePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        val updatedPermissions = repository.checkPermissionState()
        if (repository.isDevicePaired()) {
            // Re-evaluate foreground-service types now that Android has applied the grants.
            com.example.service.AirGuardMediaCaptureService.start(context)
            coroutineScope.launch { repository.syncTelemetryToCloud(updatedPermissions) }
        }
    }

    LaunchedEffect(Unit) {
        val current = repository.checkPermissionState()
        val missingRuntimePermissions = buildList {
            if (!current.hasCamera) add(android.Manifest.permission.CAMERA)
            if (!current.hasMicrophone) add(android.Manifest.permission.RECORD_AUDIO)
            if (!current.hasLocation) {
                add(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                add(android.Manifest.permission.ACCESS_FINE_LOCATION)
            }
            if (!current.hasPhoneState) add(android.Manifest.permission.READ_PHONE_STATE)
            if (!current.hasCallLog) add(android.Manifest.permission.READ_CALL_LOG)
        }
        if (missingRuntimePermissions.isNotEmpty()) {
            startupRuntimePermissionsLauncher.launch(missingRuntimePermissions.toTypedArray())
        }
    }

    val globalHardwarePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        com.example.service.AirGuardMediaCaptureService.start(context)
        val updatedPerms = repository.checkPermissionState()
        coroutineScope.launch {
            repository.syncTelemetryToCloud(updatedPerms)
        }

        val prompt = pendingPermissionPrompt
        if (prompt != null) {
            val hasRequired = prompt.missingPermissions.all { perm ->
                results[perm] == true || ContextCompat.checkSelfPermission(
                    context, perm
                ) == PackageManager.PERMISSION_GRANTED
            }
            if (hasRequired) {
                repository.mediaSignalingManager.onPermissionsGranted(prompt.session)
            } else {
                repository.mediaSignalingManager.onPermissionsDenied(prompt.session)
            }
        }
    }

    val screenCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val session = repository.mediaSignalingManager.pendingScreenCaptureSession
        val projectionData = result.data
        if (result.resultCode == Activity.RESULT_OK && projectionData != null && session != null) {
            runCatching {
                com.example.service.AirGuardMediaCaptureService.startScreenCapture(
                    context, result.resultCode, projectionData
                )
            }.onFailure { error ->
                repository.mediaSignalingManager.onScreenCaptureStartFailed(
                    error.message ?: "Android could not start the screen-sharing service"
                )
            }
        } else {
            repository.mediaSignalingManager.onScreenCaptureDenied()
        }
    }

    if (pendingPermissionPrompt != null) {
        val prompt = pendingPermissionPrompt!!
        WebRtcHardwarePermissionDialog(
            prompt = prompt,
            onGrant = {
                if (prompt.session.type.equals("SCREEN_MIRROR", ignoreCase = true)) {
                    repository.mediaSignalingManager.onPermissionsGranted(prompt.session)
                    val projectionManager = context.getSystemService(MediaProjectionManager::class.java)
                    screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
                } else if (prompt.missingPermissions.isEmpty()) {
                    repository.mediaSignalingManager.onPermissionsGranted(prompt.session)
                } else {
                    globalHardwarePermissionsLauncher.launch(prompt.missingPermissions.toTypedArray())
                }
            },
            onDeny = {
                repository.mediaSignalingManager.onPermissionsDenied(prompt.session)
            }
        )
    }

    val startDest = when {
        !isAlreadyPaired -> "pairing"
        initialPermissions.totalGranted < initialPermissions.totalCount -> "wizard"
        else -> "dashboard"
    }

    NavHost(
        navController = navController,
        startDestination = startDest,
        modifier = Modifier
            .fillMaxSize()
            .wrapContentWidth(Alignment.CenterHorizontally)
            .widthIn(max = 840.dp),
        enterTransition = { fadeIn(tween(180)) + slideInHorizontally(tween(180)) { it / 14 } },
        exitTransition = { fadeOut(tween(140)) + slideOutHorizontally(tween(140)) { -it / 18 } }
    ) {
        composable("pairing") {
            PairingStartScreen(
                repository = repository,
                onPairingSuccess = {
                    navController.navigate("wizard") {
                        popUpTo("pairing") { inclusive = true }
                    }
                }
            )
        }

        composable("wizard") {
            PermissionWizardScreen(
                repository = repository,
                onComplete = {
                    navController.navigate("dashboard") {
                        popUpTo("wizard") { inclusive = true }
                    }
                },
                onBack = {
                    if (repository.isDevicePaired()) {
                        navController.navigate("dashboard") {
                            popUpTo("wizard") { inclusive = true }
                        }
                    } else {
                        navController.navigate("pairing") {
                            popUpTo("wizard") { inclusive = true }
                        }
                    }
                }
            )
        }

        composable("dashboard") {
            ChildDashboardScreen(
                repository = repository,
                onNavigateToPermissions = {
                    navController.navigate("wizard")
                },
                onUnpair = {
                    navController.navigate("pairing") {
                        popUpTo("dashboard") { inclusive = true }
                    }
                }
            )
        }
    }
}
