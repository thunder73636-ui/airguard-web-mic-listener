package com.example.data.model

import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
data class ChildDeviceInfo(
    val id: String = "",
    val deviceName: String = "",
    val model: String = "",
    val androidVersion: String = "",
    val ipAddress: String = "",
    val batteryLevel: Int = 0,
    val isOnline: Boolean = false,
    val isLocked: Boolean = false,
    val screenTimeLimitMinutes: Int = 180,
    val todayUsageMinutes: Int = 0,
    val webDailyLimitMinutes: Int = 60,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val address: String? = null,
    val locationTimestamp: Long = 0L,
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val downtimeEnabled: Boolean = false,
    val downtimeStartHour: Int = 21,
    val downtimeStartMinute: Int = 30,
    val downtimeEndHour: Int = 7,
    val downtimeEndMinute: Int = 0,
    val downtimeDays: String = "Mon,Tue,Wed,Thu,Sun",
    val unlockCountToday: Int = 0,
    val notificationsCountToday: Int = 0,
    val hasAccessibilityPermission: Boolean = false,
    val hasUsageStatsPermission: Boolean = false,
    val hasNotificationPermission: Boolean = false,
    val hasLocationPermission: Boolean = false,
    val hasCameraPermission: Boolean = false,
    val hasMicrophonePermission: Boolean = false,
    val hasAdminPermission: Boolean = false,
    val blockNewInstalls: Boolean = false,
    val alwaysAllowedApps: String = "Phone,Maps,Calculator",
    val preventUninstall: Boolean = false,
    val extraTimeRequestAt: Long = 0L,
    val extraTimeRequestHandledAt: Long = 0L,
    val extraTimeUntil: Long = 0L,
    val parentUid: String = ""
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "deviceName" to deviceName,
        "model" to model,
        "androidVersion" to androidVersion,
        "ipAddress" to ipAddress,
        "batteryLevel" to batteryLevel,
        "isOnline" to isOnline,
        "isLocked" to isLocked,
        "screenTimeLimitMinutes" to screenTimeLimitMinutes,
        "todayUsageMinutes" to todayUsageMinutes,
        "webDailyLimitMinutes" to webDailyLimitMinutes,
        "latitude" to latitude,
        "longitude" to longitude,
        "address" to address,
        "locationTimestamp" to locationTimestamp,
        "lastSeenTimestamp" to lastSeenTimestamp,
        "downtimeEnabled" to downtimeEnabled,
        "downtimeStartHour" to downtimeStartHour,
        "downtimeStartMinute" to downtimeStartMinute,
        "downtimeEndHour" to downtimeEndHour,
        "downtimeEndMinute" to downtimeEndMinute,
        "downtimeDays" to downtimeDays,
        "unlockCountToday" to unlockCountToday,
        "notificationsCountToday" to notificationsCountToday,
        "hasAccessibilityPermission" to hasAccessibilityPermission,
        "hasUsageStatsPermission" to hasUsageStatsPermission,
        "hasNotificationPermission" to hasNotificationPermission,
        "hasLocationPermission" to hasLocationPermission,
        "hasCameraPermission" to hasCameraPermission,
        "hasMicrophonePermission" to hasMicrophonePermission,
        "hasAdminPermission" to hasAdminPermission,
        "blockNewInstalls" to blockNewInstalls,
        "alwaysAllowedApps" to alwaysAllowedApps,
        "preventUninstall" to preventUninstall,
        "extraTimeRequestAt" to extraTimeRequestAt,
        "extraTimeRequestHandledAt" to extraTimeRequestHandledAt,
        "extraTimeUntil" to extraTimeUntil,
        "parentUid" to parentUid
    )
}

data class ChildPermissionState(
    val hasAccessibility: Boolean = false,
    val hasCamera: Boolean = false,
    val hasMicrophone: Boolean = false,
    val hasUsageStats: Boolean = false,
    val hasPhoneState: Boolean = false,
    val hasCallLog: Boolean = false,
    val hasNotificationListener: Boolean = false,
    val hasPostNotifications: Boolean = true,
    val isIgnoringBatteryOptimizations: Boolean = false,
    val hasLocation: Boolean = false,
    val hasManageAllFiles: Boolean = false,
    val hasDeviceAdmin: Boolean = false
) {
    val totalGranted: Int
        get() = listOf(
            hasAccessibility, hasCamera, hasMicrophone,
            hasUsageStats, hasPhoneState, hasCallLog, hasNotificationListener, hasPostNotifications,
            isIgnoringBatteryOptimizations, hasLocation, hasManageAllFiles
        ).count { it }

    val totalCount: Int = 11

    val isAllEssentialGranted: Boolean
        get() = hasAccessibility && hasUsageStats
}

data class ChildAppRule(
    val id: String = "",
    val deviceId: String = "",
    val packageName: String = "",
    val appName: String = "",
    val category: String = "App",
    val isBlocked: Boolean = false,
    val dailyLimitMinutes: Int = 0,
    val todayUsageMinutes: Int = 0
)

@IgnoreExtraProperties
data class ChildPairingSession(
    val id: String = "",
    val code: String = "",
    val token: String = "",
    val deviceName: String = "",
    val qrPayload: String = "",
    val parentUid: String = "",
    val status: String = "WAITING", // WAITING, PAIRED, EXPIRED, CANCELLED
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 15 * 60 * 1000L,
    val childDeviceId: String? = null,
    val childModel: String? = null,
    val childAndroidVersion: String? = null
)

data class NotificationEntry(
    val id: String = "",
    val deviceId: String = "",
    val appName: String = "",
    val packageName: String = "",
    val sender: String = "",
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isFlagged: Boolean = false
)
