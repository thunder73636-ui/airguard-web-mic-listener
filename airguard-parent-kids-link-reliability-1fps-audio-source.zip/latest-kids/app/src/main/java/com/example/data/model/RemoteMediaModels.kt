package com.example.data.model

import com.google.firebase.firestore.IgnoreExtraProperties

enum class MediaSessionState {
    IDLE,
    OFFER_SENT,
    OFFER_RECEIVED,
    PENDING_CONSENT,
    ANSWER_SENT,
    CONNECTED,
    STREAMING,
    DISCONNECTED,
    FAILED,
    PERMISSION_DENIED,
    DEVICE_OFFLINE
}

@IgnoreExtraProperties
data class SdpPayload(
    val type: String = "offer", // "offer" or "answer"
    val sdp: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class IceCandidatePayload(
    val sdpMid: String = "",
    val sdpMLineIndex: Int = 0,
    val sdpCandidate: String = "",
    val serverUrl: String = ""
)

@IgnoreExtraProperties
data class RemoteMediaSession(
    val id: String = "",
    val sessionToken: String = "",
    val deviceId: String = "",
    val type: String = "CAMERA", // CAMERA, ONE_WAY_AUDIO, SCREEN_MIRROR
    val status: String = "IDLE", // maps to MediaSessionState names
    val sdpOffer: SdpPayload? = null,
    val sdpAnswer: SdpPayload? = null,
    val iceCandidates: List<Map<String, Any>> = emptyList(),
    val details: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val lastHandshake: Long = System.currentTimeMillis(),
    val audioPacketChunk: String? = null,
    val videoFrameChunk: String? = null,
    val fps: Int = 30,
    val sampleRate: Int = 44100,
    val forceRelay: Boolean = false,
    val expiresAt: Long = 0L,
    val parentHeartbeatAt: Long = 0L
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "sessionToken" to sessionToken,
        "deviceId" to deviceId,
        "type" to type,
        "status" to status,
        "sdpOffer" to sdpOffer?.let { mapOf("type" to it.type, "sdp" to it.sdp, "timestamp" to it.timestamp) },
        "sdpAnswer" to sdpAnswer?.let { mapOf("type" to it.type, "sdp" to it.sdp, "timestamp" to it.timestamp) },
        "iceCandidates" to iceCandidates,
        "details" to details,
        "timestamp" to timestamp,
        "lastHandshake" to lastHandshake,
        "audioPacketChunk" to audioPacketChunk,
        "videoFrameChunk" to videoFrameChunk,
        "fps" to fps,
        "sampleRate" to sampleRate,
        "forceRelay" to forceRelay,
        "expiresAt" to expiresAt,
        "parentHeartbeatAt" to parentHeartbeatAt
    )
}
