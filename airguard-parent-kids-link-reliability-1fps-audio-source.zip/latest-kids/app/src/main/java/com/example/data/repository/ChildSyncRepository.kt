package com.example.data.repository

import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.provider.CallLog
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.Environment
import android.os.Handler
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.util.Base64
import android.util.Size
import android.os.Process
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.data.model.ChildDeviceInfo
import com.example.data.model.ChildPairingSession
import com.example.data.model.ChildPermissionState
import com.example.data.model.NotificationEntry
import com.example.monitoring.DeviceUsageStats
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import java.util.UUID

class ChildSyncRepository(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("airguard_child_prefs", Context.MODE_PRIVATE)

    private val scope = CoroutineScope(Dispatchers.IO)
    private var remoteRequestListener: ListenerRegistration? = null
    private var snapshotListener: ListenerRegistration? = null
    private var parentCommandListener: ListenerRegistration? = null
    private var fileAccessListener: ListenerRegistration? = null
    private var fileDownloadListener: ListenerRegistration? = null
    private var remoteListenerRetryJob: Job? = null
    private var remoteListenerRetryAttempt = 0
    private val activeFileTransfers = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    @Volatile private var lastServedFilePath: String? = null
    private var callLogObserver: ContentObserver? = null
    private val _offlineUnlockActive = MutableStateFlow(prefs.getBoolean("offline_unlock_active", false))
    val offlineUnlockActive: StateFlow<Boolean> = _offlineUnlockActive.asStateFlow()

    enum class OfflinePinResult { UNLOCKED, INCORRECT, NOT_CONFIGURED, COOLDOWN }

    val mediaSignalingManager = com.example.media.ChildMediaSignalingManager(context, this)

    companion object {
        @Volatile private var instance: ChildSyncRepository? = null

        /** One shared repository (and ONE signaling listener / camera owner) for activity + services. */
        fun getInstance(context: Context): ChildSyncRepository =
            instance ?: synchronized(this) {
                instance ?: ChildSyncRepository(context.applicationContext).also { instance = it }
            }

        private const val TAG = "ChildSyncRepository"
        private const val DETAILED_USAGE_SYNC_INTERVAL_MS = 120_000L
        private const val PREF_DETAILED_USAGE_SYNC_AT = "detailed_usage_sync_at"
        const val PREF_IS_PAIRED = "is_paired"
        const val PREF_CHILD_DEVICE_ID = "child_device_id"
        const val PREF_PARENT_UID = "parent_uid"
        const val PREF_DEVICE_NAME = "device_name"
        const val PREF_PAIRING_CODE = "pairing_code"
        const val PREF_SESSION_ID = "session_id"
    }

    init {
        registerNetworkRecoveryCallback()
        // Automatically start remote listeners if already paired
        if (isDevicePaired()) {
            startRemoteListeners()
            mediaSignalingManager.startListening()
        }
    }

    fun getFirestore(): FirebaseFirestore? {
        return try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                val dbIdRes = context.resources.getIdentifier("firestore_database_id", "string", context.packageName)
                val customDbId = if (dbIdRes != 0) context.getString(dbIdRes) else null
                if (!customDbId.isNullOrBlank()) {
                    FirebaseFirestore.getInstance(FirebaseApp.getInstance(), customDbId)
                } else {
                    FirebaseFirestore.getInstance()
                }
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore initialization error: ${e.message}")
            null
        }
    }

    fun isDevicePaired(): Boolean = prefs.getBoolean(PREF_IS_PAIRED, false)

    private fun registerNetworkRecoveryCallback() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        try {
            manager.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (isDevicePaired()) scheduleRemoteListenerReconnect("network restored", immediate = true)
                }

                override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                    if (isDevicePaired() && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                        scheduleRemoteListenerReconnect("validated network restored", immediate = true)
                    }
                }
            })
        } catch (e: Exception) {
            Log.w(TAG, "Could not register network recovery callback: ${e.message}")
        }
    }

    @Synchronized
    private fun scheduleRemoteListenerReconnect(reason: String, immediate: Boolean = false) {
        if (!isDevicePaired()) return
        if (remoteListenerRetryJob?.isActive == true) {
            if (!immediate) return
            remoteListenerRetryJob?.cancel()
        }
        val attempt = remoteListenerRetryAttempt.coerceAtMost(5)
        val waitMs = if (immediate) 300L else (1_000L shl attempt).coerceAtMost(30_000L)
        remoteListenerRetryAttempt = (remoteListenerRetryAttempt + 1).coerceAtMost(6)
        remoteListenerRetryJob = scope.launch {
            delay(waitMs)
            synchronized(this@ChildSyncRepository) { remoteListenerRetryJob = null }
            if (isDevicePaired()) {
                Log.i(TAG, "Reconnecting child cloud listeners after $reason")
                startRemoteListeners()
            }
        }
    }

    fun getChildDeviceId(): String {
        var id = prefs.getString(PREF_CHILD_DEVICE_ID, null)
        if (id.isNullOrBlank()) {
            id = "dev_" + UUID.randomUUID().toString().take(8)
            prefs.edit().putString(PREF_CHILD_DEVICE_ID, id).apply()
        }
        return id
    }

    fun getParentUid(): String? = prefs.getString(PREF_PARENT_UID, null)

    suspend fun requestExtraTime() {
        val firestore = getFirestore() ?: throw IllegalStateException("No network connection is available.")
        firestore.collection("devices").document(getChildDeviceId()).update(
            mapOf("extraTimeRequestAt" to System.currentTimeMillis())
        ).await()
    }

    fun getDeviceName(): String {
        val saved = prefs.getString(PREF_DEVICE_NAME, null)
        if (!saved.isNullOrBlank()) return saved
        return "${Build.MANUFACTURER} ${Build.MODEL}".ifBlank { "Child Device" }
    }

    fun setDeviceName(name: String) {
        prefs.edit().putString(PREF_DEVICE_NAME, name).apply()
    }

    /**
     * Checks permission status on device for all 10 permissions corresponding to the user screenshots.
     */
    fun checkPermissionState(): ChildPermissionState {
        val hasCamera = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        val hasMicrophone = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val hasLocation = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val hasPhoneState = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        val hasCallLog = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.READ_CALL_LOG
        ) == PackageManager.PERMISSION_GRANTED

        val hasNotificationListener = NotificationManagerCompat.getEnabledListenerPackages(context)
            .contains(context.packageName)

        val adminComponent = ComponentName(context, com.example.service.AirGuardDeviceAdminReceiver::class.java)
        val hasDeviceAdmin = (context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager)
            ?.isAdminActive(adminComponent) == true

        val hasPostNotifications = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isIgnoringBattery = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
        } else {
            true
        }

        val hasUsageStats = try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }

        val accessibilityEnabled = try {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            val expectedService = ComponentName(context, com.example.service.AirGuardAccessibilityService::class.java)
            enabledServices.split(':').any { flattened ->
                val enabled = ComponentName.unflattenFromString(flattened)
                enabled != null && enabled.packageName == expectedService.packageName &&
                    enabled.className == expectedService.className
            }
        } catch (e: Exception) {
            false
        }

        return ChildPermissionState(
            hasAccessibility = accessibilityEnabled,
            hasCamera = hasCamera,
            hasMicrophone = hasMicrophone,
            hasUsageStats = hasUsageStats,
            hasPhoneState = hasPhoneState,
            hasCallLog = hasCallLog,
            hasNotificationListener = hasNotificationListener,
            hasPostNotifications = hasPostNotifications,
            isIgnoringBatteryOptimizations = isIgnoringBattery,
            hasLocation = hasLocation,
            hasManageAllFiles = when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> runCatching { Environment.isExternalStorageManager() }.getOrDefault(false)
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> ContextCompat.checkSelfPermission(
                    context, android.Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                else -> true
            },
            hasDeviceAdmin = hasDeviceAdmin
        )
    }

    /**
     * Starts background listeners for Remote Camera, One-Way Audio, Screen Mirroring,
     * and Snapshots from the parent device.
     */
    fun startRemoteListeners() {
        if (!isDevicePaired()) return
        synchronized(this) {
            remoteListenerRetryJob?.cancel()
            remoteListenerRetryJob = null
        }
        val childId = getChildDeviceId()
        val firestore = getFirestore() ?: return

        remoteRequestListener?.remove()
        snapshotListener?.remove()
        parentCommandListener?.remove()
        fileAccessListener?.remove()
        fileDownloadListener?.remove()
        mediaSignalingManager.startListening()

        try {
            // Keep the Parent policy and PIN verifier synced while the child app is backgrounded.
            parentCommandListener = firestore.collection("devices").document(childId)
                .addSnapshotListener(com.google.firebase.firestore.MetadataChanges.INCLUDE) { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Parent command listener failed: ${error.message}")
                        scheduleRemoteListenerReconnect("parent command listener error")
                        return@addSnapshotListener
                    }
                    if (snapshot == null) return@addSnapshotListener
                    if (!snapshot.metadata.isFromCache) synchronized(this@ChildSyncRepository) {
                        remoteListenerRetryAttempt = 0
                    }
                    processParentDeviceSnapshot(snapshot)
                }

            // 1. Delegate remote streaming (Camera, One-Way Audio, Screen Mirror) to WebRTC Media Signaling Manager
            // which provides SDP negotiation, ICE candidates, and 30fps video/audio chunk streaming.

            // 2. Listen for remote snapshot requests
            snapshotListener = firestore.collection("snapshot_logs")
                .whereEqualTo("deviceId", childId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Snapshot request listener failed: ${error.message}")
                        scheduleRemoteListenerReconnect("snapshot listener error")
                        return@addSnapshotListener
                    }
                    if (snapshot == null) return@addSnapshotListener
                    for (doc in snapshot.documents) {
                        val status = doc.getString("status") ?: ""
                        if (status == "REQUESTED") {
                            scope.launch {
                                try {
                                    firestore.collection("snapshot_logs").document(doc.id).set(
                                        mapOf(
                                            "status" to "FAILED",
                                            "timestamp" to System.currentTimeMillis(),
                                            "details" to "Snapshot capture is unavailable. Start a live camera session to view the real camera feed."
                                        ),
                                        com.google.firebase.firestore.SetOptions.merge()
                                    ).await()
                                    Log.i(TAG, "Rejected snapshot request instead of returning a synthetic camera frame")
                                } catch (e: Exception) {
                                    Log.w(TAG, "Snapshot update error: ${e.message}")
                                }
                            }
                        }
                    }
                }

            // All Files access is the on-device gate. The child's Settings choice enables media listings.
            fileAccessListener = firestore.collection("remote_requests").document("media_access").collection("devices").document(childId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Media browser listener failed: ${error.message}")
                        scheduleRemoteListenerReconnect("media browser listener error")
                        return@addSnapshotListener
                    }
                    if (snapshot == null || !snapshot.exists()) return@addSnapshotListener
                    val status = snapshot.getString("status") ?: ""
                    if (status == "PENDING") {
                        val requestId = snapshot.getString("requestId") ?: return@addSnapshotListener
                        val mediaType = snapshot.getString("mediaType") ?: "IMAGES"
                        val currentPath = snapshot.getString("currentPath") ?: ""
                        val pendingKey = "$requestId|$mediaType||$currentPath"
                        if (lastServedFilePath == pendingKey) return@addSnapshotListener
                        lastServedFilePath = pendingKey
                        scope.launch {
                            val doc = firestore.collection("remote_requests").document("media_access").collection("devices").document(childId)
                            if (!checkPermissionState().hasManageAllFiles) {
                                doc.update(mapOf("status" to "PERMISSION_REQUIRED", "details" to "Enable Manage all files access in AirGuard Kids Settings to show media.")).await()
                            } else {
                                doc.update(mapOf("status" to "ACTIVE", "mediaType" to mediaType)).await()
                                publishMediaListing(firestore, childId, requestId, mediaType, currentPath)
                            }
                        }
                        return@addSnapshotListener
                    }
                    val requestId = snapshot.getString("requestId") ?: ""
                    val mediaType = snapshot.getString("mediaType") ?: "IMAGES"
                    val currentPath = snapshot.getString("currentPath") ?: ""
                    val previewPath = snapshot.getString("previewPath") ?: ""
                    val key = "$requestId|$mediaType|$previewPath|$currentPath"
                    if (status == "ACTIVE" && !checkPermissionState().hasManageAllFiles) {
                        scope.launch { firestore.collection("remote_requests").document("media_access").collection("devices").document(childId).update("status", "PERMISSION_REQUIRED") }
                    } else if (status == "ACTIVE" && key != lastServedFilePath) {
                        lastServedFilePath = key
                        scope.launch {
                            if (previewPath.isBlank()) publishMediaListing(firestore, childId, requestId, mediaType, currentPath)
                            else publishMediaPreview(firestore, childId, requestId, mediaType, previewPath)
                        }
                    }
                }

            val mediaDoc = firestore.collection("remote_requests").document("media_access").collection("devices").document(childId)
            fileDownloadListener = mediaDoc.collection("downloads").whereEqualTo("status", "PENDING")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) {
                        if (error != null) {
                            Log.w(TAG, "File transfer listener failed: ${error.message}")
                            scheduleRemoteListenerReconnect("file transfer listener error")
                        }
                        return@addSnapshotListener
                    }
                    snapshot.documents.forEach { transfer ->
                        if (activeFileTransfers.add(transfer.id)) scope.launch {
                            try { serveRequestedFile(mediaDoc, transfer.reference, transfer.getString("path") ?: "") }
                            catch (e: Exception) {
                                Log.w(TAG, "Could not transfer child file: ${e.message}")
                                runCatching { transfer.reference.update(mapOf("status" to "ERROR", "details" to (e.localizedMessage ?: "Could not read file."))).await() }
                            } finally { activeFileTransfers.remove(transfer.id) }
                        }
                    }
                }

            // Accessibility service consumes app-rule updates while enforcement is enabled.
            scope.launch { syncLaunchableApps(childId, firestore) }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start remote listeners: ${e.message}")
            scheduleRemoteListenerReconnect("listener setup failure")
        }
    }

    private suspend fun serveRequestedFile(
        mediaDoc: com.google.firebase.firestore.DocumentReference,
        transferDoc: com.google.firebase.firestore.DocumentReference,
        requestedPath: String
    ) = withContext(Dispatchers.IO) {
        transferDoc.update("status", "TRANSFERRING").await()
        if (!checkPermissionState().hasManageAllFiles) error("Enable Manage all files access in AirGuard Kids Settings.")
        val root = Environment.getExternalStorageDirectory().canonicalFile
        val file = java.io.File(root, requestedPath.removePrefix("/")).canonicalFile
        if (!file.path.startsWith(root.path + java.io.File.separator) || !file.isFile || !file.canRead()) error("File is not accessible from shared storage.")
        if (file.path.contains("${java.io.File.separator}Android${java.io.File.separator}data${java.io.File.separator}") || file.path.contains("${java.io.File.separator}Android${java.io.File.separator}obb${java.io.File.separator}")) error("Android app-data folders are protected.")
        val length = file.length()
        if (length <= 0 || length > 20L * 1024 * 1024) error("Files must be between 1 byte and 20 MB to open remotely.")
        val bytes = file.readBytes()
        val chunkSize = 256 * 1024
        val chunkCount = (bytes.size + chunkSize - 1) / chunkSize
        for (batchStart in 0 until chunkCount step 16) {
            val batch = mediaDoc.firestore.batch()
            for (index in batchStart until minOf(batchStart + 16, chunkCount)) {
                val from = index * chunkSize
                val chunk = bytes.copyOfRange(from, minOf(from + chunkSize, bytes.size))
                batch.set(transferDoc.collection("chunks").document(index.toString()), mapOf(
                    "index" to index,
                    "data" to Base64.encodeToString(chunk, Base64.NO_WRAP)
                ))
            }
            batch.commit().await()
        }
        transferDoc.update(mapOf(
            "status" to "READY", "fileName" to file.name, "totalBytes" to length,
            "chunkCount" to chunkCount, "completedAt" to System.currentTimeMillis()
        )).await()
    }

    private suspend fun publishMediaListing(
        firestore: FirebaseFirestore,
        childId: String,
        requestId: String,
        mediaType: String,
        currentPath: String = ""
    ) = withContext(Dispatchers.IO) {
        if (!checkPermissionState().hasManageAllFiles) return@withContext
        val root = Environment.getExternalStorageDirectory().canonicalFile
        val entries: List<Map<String, Any>> = if (mediaType == "FILES") {
            val relative = currentPath.trim('/')
            val folder = java.io.File(root, relative).canonicalFile
            if ((folder != root && !folder.path.startsWith(root.path + java.io.File.separator)) || !folder.isDirectory) return@withContext
            val children = runCatching { folder.listFiles()?.toList().orEmpty() }.getOrDefault(emptyList())
                .filter { child ->
                    child.name.isNotBlank() &&
                        !(relative == "Android" && child.name in setOf("data", "obb")) &&
                        runCatching { child.canRead() }.getOrDefault(false)
                }
                .sortedWith(compareBy<java.io.File> { !it.isDirectory }.thenBy { it.name.lowercase() })
            children.map { file ->
                val relativePath = file.relativeTo(root).invariantSeparatorsPath
                mapOf(
                    "name" to file.name,
                    "path" to "/$relativePath",
                    "directory" to file.isDirectory,
                    "mediaType" to "FILES",
                    "size" to if (file.isFile) file.length() else 0L,
                    "modifiedAt" to file.lastModified()
                )
            }
        } else {
            val imageExtensions = setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "heif", "bmp")
            val videoExtensions = setOf("mp4", "m4v", "mov", "3gp", "mkv", "webm", "avi")
            val extensions = if (mediaType == "VIDEOS") videoExtensions else imageExtensions
            val folders = listOf("DCIM", "Pictures", "Movies", "Download").map { java.io.File(root, it) }.filter { it.isDirectory }
            folders.asSequence().flatMap { folder ->
                folder.walkTopDown().maxDepth(5).onEnter { !it.name.startsWith(".") && it.name != "Android" }
            }.filter { it.isFile && it.extension.lowercase() in extensions }
                .sortedByDescending { it.lastModified() }
                .take(100)
                .map { file -> mapOf(
                    "name" to file.name,
                    "path" to ("/" + file.relativeTo(root).invariantSeparatorsPath),
                    "directory" to false,
                    "mediaType" to mediaType,
                    "size" to file.length(),
                    "modifiedAt" to file.lastModified()
                ) }.toList()
        }
        val doc = firestore.collection("remote_requests").document("media_access").collection("devices").document(childId)
        val current = doc.get().await()
        if (current.getString("requestId") != requestId || current.getString("status") != "ACTIVE") return@withContext
        doc.update(mapOf(
            "entries" to entries,
            "mediaType" to mediaType,
            "currentPath" to currentPath,
            "previewPath" to "",
            "previewBase64" to "",
            "listedAt" to System.currentTimeMillis()
        )).await()
    }

    private suspend fun publishMediaPreview(
        firestore: FirebaseFirestore,
        childId: String,
        requestId: String,
        mediaType: String,
        requestedPath: String
    ) = withContext(Dispatchers.IO) {
        if (!checkPermissionState().hasManageAllFiles) return@withContext
        val root = Environment.getExternalStorageDirectory().canonicalFile
        val file = java.io.File(root, requestedPath.removePrefix("/")).canonicalFile
        if (!file.path.startsWith(root.path + java.io.File.separator) || !file.isFile) return@withContext
        val allowed = if (mediaType == "VIDEOS") setOf("mp4", "m4v", "mov", "3gp", "mkv", "webm", "avi") else setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "heif", "bmp")
        if (file.extension.lowercase() !in allowed) return@withContext
        val thumbnail = createMediaThumbnail(file, mediaType == "VIDEOS") ?: return@withContext
        val output = java.io.ByteArrayOutputStream()
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 55, output)
        thumbnail.recycle()
        val encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        val doc = firestore.collection("remote_requests").document("media_access").collection("devices").document(childId)
        val current = doc.get().await()
        if (current.getString("requestId") != requestId || current.getString("status") != "ACTIVE" || current.getString("previewPath") != requestedPath) return@withContext
        doc.update(mapOf("previewBase64" to encoded, "previewForPath" to requestedPath)).await()
    }

    private fun createMediaThumbnail(file: java.io.File, video: Boolean): Bitmap? = try {
        if (video) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ThumbnailUtils.createVideoThumbnail(file, Size(320, 320), null)
            } else {
                @Suppress("DEPRECATION")
                ThumbnailUtils.createVideoThumbnail(file.absolutePath, android.provider.MediaStore.Images.Thumbnails.MINI_KIND)
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 640) sample *= 2
            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    } catch (e: Exception) {
        Log.w(TAG, "Could not create media preview for ${file.name}: ${e.message}")
        null
    }

    private suspend fun syncLaunchableApps(childId: String, firestore: FirebaseFirestore) = withContext(Dispatchers.IO) {
        try {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val launchableApps = context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
                .mapNotNull { resolveInfo ->
                    val info = resolveInfo.activityInfo?.applicationInfo ?: return@mapNotNull null
                    val packageName = info.packageName
                    if (packageName == context.packageName) return@mapNotNull null
                    val appName = runCatching { context.packageManager.getApplicationLabel(info).toString() }
                        .getOrDefault(packageName)
                    val category = when {
                        packageName.contains("browser", true) || packageName.contains("chrome", true) ||
                            packageName.contains("firefox", true) || packageName.contains("emmx", true) ||
                            packageName.contains("sbrowser", true) || packageName.contains("vivaldi", true) -> "Browser"
                        packageName.contains("game", true) || packageName.contains("roblox", true) -> "Games"
                        packageName.contains("instagram", true) || packageName.contains("tiktok", true) || packageName.contains("facebook", true) -> "Social"
                        else -> "App"
                    }
                    Triple(packageName, appName, category)
                }
                .distinctBy { it.first }

            val collection = firestore.collection("app_rules")
            val existing = collection.whereEqualTo("deviceId", childId).get().await()
                .documents.mapNotNull { it.getString("packageName") }.toSet()
            val missing = launchableApps.filter { it.first !in existing }
            for (chunk in missing.chunked(450)) {
                val batch = firestore.batch()
                chunk.forEach { (packageName, appName, category) ->
                    val id = "rule_${childId}_${packageName.hashCode().toUInt().toString(16)}"
                    batch.set(collection.document(id), mapOf(
                        "id" to id,
                        "deviceId" to childId,
                        "packageName" to packageName,
                        "appName" to appName,
                        "category" to category,
                        "isBlocked" to false,
                        "dailyLimitMinutes" to 0,
                        "todayUsageMinutes" to 0
                    ))
                }
                batch.commit().await()
            }
            Log.i(TAG, "Synced ${launchableApps.size} launchable apps (${missing.size} new) to parent controls")
        } catch (e: Exception) {
            Log.w(TAG, "Could not sync app inventory: ${e.message}")
        }
    }

    /**
     * Attempts to find and complete pairing with a 9-digit code in Firestore.
     */
    suspend fun pairWithCode(rawCode: String): Result<ChildPairingSession> = withContext(Dispatchers.IO) {
        try {
            val digitsOnly = rawCode.filter { it.isDigit() }
            if (digitsOnly.length != 9) {
                return@withContext Result.failure(IllegalArgumentException("Please enter a valid 9-digit binding code."))
            }

            val formattedCode = "${digitsOnly.substring(0, 3)} ${digitsOnly.substring(3, 6)} ${digitsOnly.substring(6, 9)}"

            val firestore = getFirestore()
            if (firestore != null) {
                // Check both spaced format and contiguous digits format to guarantee matching
                var querySnapshot = kotlinx.coroutines.withTimeout(15_000L) { firestore.collection("pairing_sessions")
                    .whereEqualTo("code", formattedCode)
                    .whereEqualTo("status", "WAITING")
                    .limit(10)
                    .get(Source.SERVER)
                    .await() }

                if (querySnapshot.isEmpty) {
                    querySnapshot = kotlinx.coroutines.withTimeout(15_000L) { firestore.collection("pairing_sessions")
                        .whereEqualTo("code", digitsOnly)
                        .whereEqualTo("status", "WAITING")
                        .limit(10)
                        .get(Source.SERVER)
                        .await() }
                }

                val now = System.currentTimeMillis()
                val doc = querySnapshot.documents.firstOrNull {
                    (it.getLong("expiresAt") ?: Long.MAX_VALUE) > now
                }
                if (doc != null) {
                    val sessionId = doc.id
                    val parentUid = doc.getString("parentUid") ?: "parent_user"
                    val requestedName = doc.getString("deviceName")?.takeIf { it.isNotBlank() && it != "Child Device" }
                    val deviceNameFromParent = requestedName ?: getDeviceName()

                    val childId = getChildDeviceId()
                    val childModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "Android device" }
                    val childAndroidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

                    // Create the real child record first. The Parent watches the pairing
                    // session and immediately reads devices/{childId} after status=PAIRED.
                    // Publishing PAIRED before this write caused a race and fake fallback devices.
                    val initialPermissions = checkPermissionState()
                    val battery = getBatteryPercentage()
                    val deviceInfo = ChildDeviceInfo(
                        id = childId,
                        deviceName = deviceNameFromParent,
                        model = childModel,
                        androidVersion = childAndroidVersion,
                        batteryLevel = battery,
                        isOnline = true,
                        isLocked = false,
                        screenTimeLimitMinutes = 180,
                        todayUsageMinutes = 0,
                        webDailyLimitMinutes = 60,
                        latitude = null,
                        longitude = null,
                        address = null,
                        lastSeenTimestamp = System.currentTimeMillis(),
                        hasAccessibilityPermission = initialPermissions.hasAccessibility,
                        hasUsageStatsPermission = initialPermissions.hasUsageStats,
                        hasNotificationPermission = initialPermissions.hasNotificationListener,
                        hasLocationPermission = initialPermissions.hasLocation,
                        hasCameraPermission = initialPermissions.hasCamera,
                        hasMicrophonePermission = initialPermissions.hasMicrophone,
                        hasAdminPermission = false,
                        blockNewInstalls = false,
                        alwaysAllowedApps = "Phone,Maps,Calculator",
                        preventUninstall = false,
                        parentUid = parentUid
                    )

                    withContext(Dispatchers.IO) {
                        kotlinx.coroutines.withTimeout(15_000L) {
                            firestore.collection("devices").document(childId)
                                .set(deviceInfo.toMap() + mapOf("lastSeenServerAt" to FieldValue.serverTimestamp()))
                                .await()
                        }
                    }

                    // Publish pairing completion only after the device record is confirmed.
                    kotlinx.coroutines.withTimeout(15_000L) { firestore.collection("pairing_sessions").document(sessionId).update(
                        mapOf(
                            "status" to "PAIRED",
                            "childDeviceId" to childId,
                            "childModel" to childModel,
                            "childAndroidVersion" to childAndroidVersion
                        )
                    ).await() }

                    // Save local state
                    prefs.edit()
                        .putBoolean(PREF_IS_PAIRED, true)
                        .putString(PREF_CHILD_DEVICE_ID, childId)
                        .putString(PREF_PARENT_UID, parentUid)
                        .putString(PREF_DEVICE_NAME, deviceNameFromParent)
                        .putString(PREF_PAIRING_CODE, formattedCode)
                        .putString(PREF_SESSION_ID, sessionId)
                        .apply()

                    // Populate initial features data transfer (App rules, Location logs, Calls/SMS, Notifications)
                    startRemoteListeners()
                    mediaSignalingManager.startListening()

                    val session = ChildPairingSession(
                        id = sessionId,
                        code = formattedCode,
                        deviceName = deviceNameFromParent,
                        parentUid = parentUid,
                        status = "PAIRED",
                        childDeviceId = childId,
                        childModel = childModel,
                        childAndroidVersion = childAndroidVersion
                    )
                    Result.success(session)
                } else {
                    Result.failure(IllegalArgumentException("No active pairing session found for code $formattedCode. Please verify code on parent device."))
                }
            } else {
                // Previously this branch pretended pairing succeeded without ever reaching the parent.
                Result.failure(IllegalStateException(
                    "Firebase is not initialised in AirGuard Kids (check google-services.json). Cannot reach the parent app."))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Pairing with code failed: ${e.message}", e)
            val friendly = when ((e as? FirebaseFirestoreException)?.code) {
                FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                    "Server refused access (PERMISSION_DENIED). Firestore rules or API-key / App Check restrictions are blocking this app."
                FirebaseFirestoreException.Code.UNAVAILABLE ->
                    "Cannot reach the server. Check this phone's internet connection."
                FirebaseFirestoreException.Code.NOT_FOUND ->
                    "Firestore database not found. Check firestore_database_id."
                else -> null
            }
            Result.failure(if (friendly != null) IllegalStateException(friendly, e) else e)
        }
    }

    /**
     * Parses and pairs with scanned QR code payload URL.
     */
    suspend fun pairWithQrPayload(qrUrl: String): Result<ChildPairingSession> = withContext(Dispatchers.IO) {
        try {
            val uri = Uri.parse(qrUrl)
            val codeParam = uri.getQueryParameter("code") ?: uri.getQueryParameter("pairCode")
            if (!codeParam.isNullOrBlank()) {
                return@withContext pairWithCode(codeParam)
            }
            Result.failure(IllegalArgumentException("Invalid QR code. Could not locate pairing code."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Observes live changes from the parent on this device (e.g. Instant Block, screen time limits).
     */
    fun observeParentCommands(): Flow<ChildDeviceInfo?> = callbackFlow {
        val childId = getChildDeviceId()
        val firestore = getFirestore()
        if (firestore == null) {
            trySend(null)
            close()
            return@callbackFlow
        }

        var registration: ListenerRegistration? = null
        try {
            registration = firestore.collection("devices").document(childId)
                .addSnapshotListener(com.google.firebase.firestore.MetadataChanges.INCLUDE) { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Error listening to device commands: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot == null) return@addSnapshotListener
                    val serverConfirmed = !snapshot.metadata.isFromCache
                    if (snapshot.exists()) {
                        processParentDeviceSnapshot(snapshot)
                        trySend(snapshot.toObject(ChildDeviceInfo::class.java))
                    } else if (serverConfirmed) {
                        // A confirmed server-side unlink must clear local AirGuard restrictions.
                        unpairDevice()
                        trySend(null)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to attach device listener: ${e.message}")
        }

        awaitClose {
            registration?.remove()
        }
    }

    /**
     * Sends heartbeat and current device telemetry (battery, location, all permissions) to Firestore.
     */
    suspend fun syncTelemetryToCloud(
        permissions: ChildPermissionState
    ) = withContext(Dispatchers.IO) {
        val childId = getChildDeviceId()
        val firestore = getFirestore() ?: return@withContext

        try {
            val battery = getBatteryPercentage()
            val location = getCurrentLocationForSync()

            val updates = mutableMapOf<String, Any>(
                "isOnline" to true,
                "batteryLevel" to battery,
                "lastSeenTimestamp" to System.currentTimeMillis(),
                "lastSeenServerAt" to FieldValue.serverTimestamp(),
                "hasAccessibilityPermission" to permissions.hasAccessibility,
                "hasUsageStatsPermission" to permissions.hasUsageStats,
                "hasNotificationPermission" to permissions.hasNotificationListener,
                "hasLocationPermission" to permissions.hasLocation,
                "hasCameraPermission" to permissions.hasCamera,
                "hasMicrophonePermission" to permissions.hasMicrophone,
                "hasPhoneStatePermission" to permissions.hasPhoneState,
                "hasCallLogPermission" to permissions.hasCallLog,
                "hasPostNotificationsPermission" to permissions.hasPostNotifications,
                "hasManageAllFilesPermission" to permissions.hasManageAllFiles,
                "isIgnoringBatteryOptimizations" to permissions.isIgnoringBatteryOptimizations,
                "hasAdminPermission" to permissions.hasDeviceAdmin
            )

            val usageByPackage = DeviceUsageStats.todayByPackage(context)
            if (usageByPackage != null) {
                updates["todayUsageMinutes"] = DeviceUsageStats.totalUserAppMinutes(context, usageByPackage)
                if (shouldSyncDetailedAppUsage()) {
                    updates["todayAppUsageMinutes"] = DeviceUsageStats.userAppUsageMinutes(context, usageByPackage)
                }
            }

            if (permissions.hasCallLog) syncRecentCalls(firestore, childId)
            if (permissions.hasCallLog) ensureCallLogObserver()

            if (location != null) {
                updates["latitude"] = location.latitude
                updates["longitude"] = location.longitude
                updates["address"] = "GPS Fix: %.4f, %.4f".format(location.latitude, location.longitude)
                updates["locationTimestamp"] = location.time

                val logId = "loc_${childId}_${location.time}"
                firestore.collection("locations").document(childId).collection("logs").document(logId).set(
                    mapOf(
                        "id" to logId,
                        "deviceId" to childId,
                        "latitude" to location.latitude,
                        "longitude" to location.longitude,
                        "placeName" to "Current GPS Location",
                        "timestamp" to System.currentTimeMillis()
                    )
                )
            } else {
                // Do not publish fabricated location data when location access is unavailable.
            }

            // update() fails if the parent has unlinked this child; set(merge) would recreate
            // deleted devices and make an uninstalled app look permanently linked.
            firestore.collection("devices").document(childId).update(updates).await()
            if ("todayAppUsageMinutes" in updates) markDetailedAppUsageSynced()
            Log.d(TAG, "Device telemetry successfully transferred to parent in Firestore")
        } catch (e: Exception) {
            Log.w(TAG, "Telemetry sync deferred: ${e.message}")
            if ((e as? FirebaseFirestoreException)?.code == FirebaseFirestoreException.Code.NOT_FOUND) {
                Log.i(TAG, "Parent removed the child device record; clearing the saved pairing.")
                unpairDevice()
            }
        }
    }

    /** Lightweight keep-alive for the user's visible, paired-device foreground service. */
    suspend fun syncHeartbeatToCloud(): Boolean = withContext(Dispatchers.IO) {
        if (!isDevicePaired()) return@withContext false
        val firestore = getFirestore() ?: return@withContext false
        val childId = getChildDeviceId()
        try {
            val permissions = checkPermissionState()
            val updates = mutableMapOf<String, Any>(
                "isOnline" to true,
                "lastSeenTimestamp" to System.currentTimeMillis(),
                "lastSeenServerAt" to FieldValue.serverTimestamp(),
                "batteryLevel" to getBatteryPercentage(),
                "hasUsageStatsPermission" to permissions.hasUsageStats,
                "hasNotificationPermission" to permissions.hasNotificationListener,
                "hasCallLogPermission" to permissions.hasCallLog,
                "hasManageAllFilesPermission" to permissions.hasManageAllFiles
            )
            val usageByPackage = DeviceUsageStats.todayByPackage(context)
            if (usageByPackage != null) {
                updates["todayUsageMinutes"] = DeviceUsageStats.totalUserAppMinutes(context, usageByPackage)
                if (shouldSyncDetailedAppUsage()) {
                    updates["todayAppUsageMinutes"] = DeviceUsageStats.userAppUsageMinutes(context, usageByPackage)
                }
            }
            firestore.collection("devices").document(childId).update(updates).await()
            if ("todayAppUsageMinutes" in updates) markDetailedAppUsageSynced()
            if (permissions.hasCallLog) {
                syncRecentCalls(firestore, childId)
                ensureCallLogObserver()
            }
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Heartbeat sync deferred: ${e.message}")
            if ((e as? FirebaseFirestoreException)?.code == FirebaseFirestoreException.Code.NOT_FOUND) {
                Log.i(TAG, "Parent removed the linked device; clearing the saved pairing.")
                unpairDevice()
            }
            false
        }
    }

    /** Detailed app rows change slowly; avoid resending the full installed-app map every heartbeat. */
    private fun shouldSyncDetailedAppUsage(): Boolean =
        System.currentTimeMillis() - prefs.getLong(PREF_DETAILED_USAGE_SYNC_AT, 0L) >= DETAILED_USAGE_SYNC_INTERVAL_MS

    private fun markDetailedAppUsageSynced() {
        prefs.edit().putLong(PREF_DETAILED_USAGE_SYNC_AT, System.currentTimeMillis()).apply()
    }

    /** Syncs call metadata only, after the child has granted Android's Call Log permission. */
    private suspend fun syncRecentCalls(firestore: FirebaseFirestore, childId: String) {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return
        val lastSync = prefs.getLong("last_call_log_sync", 0L)
        val projection = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION
        )
        try {
            val rows = mutableListOf<Map<String, Any>>()
            var newestSeen = lastSync
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                "${CallLog.Calls.DATE} > ?",
                arrayOf(lastSync.toString()),
                "${CallLog.Calls.DATE} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(CallLog.Calls._ID)
                val numberCol = cursor.getColumnIndex(CallLog.Calls.NUMBER)
                val nameCol = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
                val typeCol = cursor.getColumnIndex(CallLog.Calls.TYPE)
                val dateCol = cursor.getColumnIndex(CallLog.Calls.DATE)
                val durationCol = cursor.getColumnIndex(CallLog.Calls.DURATION)
                while (cursor.moveToNext() && rows.size < 100) {
                    val rowId = cursor.getString(idCol) ?: continue
                    val timestamp = cursor.getLong(dateCol)
                    newestSeen = maxOf(newestSeen, timestamp)
                    val type = when (cursor.getInt(typeCol)) {
                        CallLog.Calls.OUTGOING_TYPE -> "OUTGOING_CALL"
                        CallLog.Calls.MISSED_TYPE -> "MISSED_CALL"
                        CallLog.Calls.REJECTED_TYPE -> "REJECTED_CALL"
                        else -> "INCOMING_CALL"
                    }
                    val duration = cursor.getLong(durationCol)
                    val logId = "call_${childId}_${rowId}"
                    rows += mapOf(
                        "id" to logId,
                        "deviceId" to childId,
                        "contactName" to (cursor.getString(nameCol) ?: "Unknown"),
                        "phoneNumber" to (cursor.getString(numberCol) ?: ""),
                        "type" to type,
                        "durationOrBody" to "${duration}s",
                        "timestamp" to timestamp
                    )
                }
            }
            if (rows.isNotEmpty()) {
                for (chunk in rows.chunked(450)) {
                    val batch = firestore.batch()
                    chunk.forEach { row ->
                        val id = row["id"] as String
                        batch.set(firestore.collection("call_sms_logs").document(id), row)
                    }
                    batch.commit().await()
                }
                prefs.edit().putLong("last_call_log_sync", newestSeen).apply()
            } else if (lastSync == 0L) {
                // A first empty scan is complete; future scans can query only newly added entries.
                prefs.edit().putLong("last_call_log_sync", System.currentTimeMillis()).apply()
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Call history permission was revoked: ${e.message}")
        } catch (e: Exception) {
            Log.w(TAG, "Call history sync deferred: ${e.message}")
        }
    }

    @Synchronized
    private fun ensureCallLogObserver() {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return
        if (callLogObserver != null) return
        callLogObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                super.onChange(selfChange)
                scope.launch {
                    kotlinx.coroutines.delay(900L)
                    val firestore = getFirestore() ?: return@launch
                    syncRecentCalls(firestore, getChildDeviceId())
                }
            }
        }.also { observer ->
            runCatching { context.contentResolver.registerContentObserver(CallLog.Calls.CONTENT_URI, true, observer) }
                .onFailure { Log.w(TAG, "Could not start live call-log monitoring: ${it.message}") }
        }
    }

    /**
     * Dispatches notification summary to Firestore collection `notification_logs`.
     */
    suspend fun syncNotificationLog(entry: NotificationEntry) = withContext(Dispatchers.IO) {
        val firestore = getFirestore() ?: return@withContext
        try {
            val logId = if (entry.id.isNotBlank()) entry.id else "notif_" + UUID.randomUUID().toString().take(8)
            val doc = mapOf(
                "id" to logId,
                "deviceId" to getChildDeviceId(),
                "appName" to entry.appName,
                "packageName" to entry.packageName,
                "sender" to entry.sender,
                "content" to entry.content,
                "timestamp" to entry.timestamp,
                "isFlagged" to entry.isFlagged
            )
            firestore.collection("notification_logs").document(logId).set(doc).await()
            Log.d(TAG, "Notification transferred to parent: ${entry.appName}")
        } catch (e: Exception) {
            Log.w(TAG, "Notification log sync skipped: ${e.message}")
        }
    }

    /**
     * Emergency SOS action triggered from child app to alert the parent.
     */
    suspend fun sendEmergencySos() = withContext(Dispatchers.IO) {
        val childId = getChildDeviceId()
        val firestore = getFirestore() ?: return@withContext
        try {
            val sosId = "sos_" + UUID.randomUUID().toString().take(8)
            val location = getLastKnownLocation()
            val locationText = location?.let { "Last known GPS fix (${(System.currentTimeMillis() - it.time) / 1000}s old): ${it.latitude}, ${it.longitude}" }
                ?: "Location unavailable: grant location permission and enable location services."
            val doc = mapOf(
                "id" to sosId,
                "deviceId" to childId,
                "appName" to "AirGuard SOS",
                "packageName" to context.packageName,
                "sender" to "Child Device SOS",
                "content" to "EMERGENCY ALERT: Child activated SOS! $locationText",
                "timestamp" to System.currentTimeMillis(),
                "isFlagged" to true
            )
            firestore.collection("notification_logs").document(sosId).set(doc).await()
            Log.i(TAG, "Emergency SOS dispatched to parent Firestore successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send SOS: ${e.message}")
        }
    }

    fun unpairDevice() {
        synchronized(this) {
            remoteListenerRetryJob?.cancel()
            remoteListenerRetryJob = null
            remoteListenerRetryAttempt = 0
        }
        remoteRequestListener?.remove()
        remoteRequestListener = null
        snapshotListener?.remove()
        snapshotListener = null
        parentCommandListener?.remove()
        parentCommandListener = null
        fileAccessListener?.remove()
        fileAccessListener = null
        fileDownloadListener?.remove()
        fileDownloadListener = null
        mediaSignalingManager.stopListening()
        _offlineUnlockActive.value = false
        runCatching { context.stopService(Intent(context, com.example.service.AirGuardMediaCaptureService::class.java)) }
        prefs.edit().clear().apply()
    }

    /** Enables a local AirGuard-only override after checking the cached Parent PIN. */
    fun attemptOfflineParentUnlock(pin: String): OfflinePinResult {
        val now = System.currentTimeMillis()
        if (now < prefs.getLong("offline_pin_locked_until", 0L)) return OfflinePinResult.COOLDOWN
        val salt = prefs.getString("offline_pin_salt", null) ?: return OfflinePinResult.NOT_CONFIGURED
        val hash = prefs.getString("offline_pin_hash", null) ?: return OfflinePinResult.NOT_CONFIGURED
        val valid = Regex("^[0-9]{6}$").matches(pin) &&
            com.example.util.OfflineUnlockPinCrypto.matches(pin, salt, hash)
        if (valid) {
            prefs.edit().remove("offline_pin_attempts").remove("offline_pin_locked_until")
                .putBoolean("offline_unlock_active", true).apply()
            _offlineUnlockActive.value = true
            return OfflinePinResult.UNLOCKED
        }
        val attempts = prefs.getInt("offline_pin_attempts", 0) + 1
        val editor = prefs.edit().putInt("offline_pin_attempts", attempts)
        if (attempts >= 5) editor.putLong("offline_pin_locked_until", now + 30_000L).putInt("offline_pin_attempts", 0)
        editor.apply()
        return if (attempts >= 5) OfflinePinResult.COOLDOWN else OfflinePinResult.INCORRECT
    }

    fun clearOfflineUnlockOverride() {
        prefs.edit().putBoolean("offline_unlock_active", false).apply()
        _offlineUnlockActive.value = false
    }

    private fun processParentDeviceSnapshot(snapshot: com.google.firebase.firestore.DocumentSnapshot) {
        if (!snapshot.exists()) {
            if (!snapshot.metadata.isFromCache) unpairDevice()
            return
        }
        val salt = snapshot.getString("offlineUnlockPinSalt")
        val hash = snapshot.getString("offlineUnlockPinHash")
        if (!salt.isNullOrBlank() && !hash.isNullOrBlank()) {
            prefs.edit().putString("offline_pin_salt", salt).putString("offline_pin_hash", hash).apply()
        } else if (!snapshot.metadata.isFromCache) {
            prefs.edit().remove("offline_pin_salt").remove("offline_pin_hash").apply()
        }
        if (!snapshot.metadata.isFromCache) clearOfflineUnlockOverride()
    }

    fun getBatteryPercentage(): Int {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)?.takeIf { it in 0..100 } ?: 0
        } catch (e: Exception) {
            0
        }
    }

    private suspend fun getCurrentLocationForSync(): Location? {
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
            val hasLocation = ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!hasLocation) return null

            val now = System.currentTimeMillis()
            val cached = getLastKnownLocation()

            // A recent cached fix is quick and avoids waking the GPS radio on every heartbeat.
            if (cached != null && now - cached.time <= 2 * 60_000L) return cached

            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
            if (providers.isEmpty()) return cached

            val fresh = try {
                withTimeoutOrNull(12_000L) {
                    callbackFlow {
                        val listener = object : LocationListener {
                            override fun onLocationChanged(location: Location) {
                                trySend(location)
                            }

                            @Deprecated("Deprecated in Android")
                            override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit

                            override fun onProviderEnabled(provider: String) = Unit
                            override fun onProviderDisabled(provider: String) = Unit
                        }

                        var requested = false
                        providers.forEach { provider ->
                            requested = runCatching {
                                lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
                                true
                            }.getOrDefault(requested)
                        }
                        if (!requested) close()
                        awaitClose { runCatching { lm.removeUpdates(listener) } }
                    }.first()
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                null
            }
            fresh ?: cached
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (e: Exception) {
            null
        }
    }

    private fun getLastKnownLocation(): Location? {
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
            val hasLocation = ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!hasLocation) return null

            val now = System.currentTimeMillis()
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
                .mapNotNull { provider -> runCatching { lm.getLastKnownLocation(provider) }.getOrNull() }
                .filter { it.time in (now - 5 * 60_000L)..now }
                .maxByOrNull { it.time }
        } catch (_: Exception) {
            null
        }
    }
}
