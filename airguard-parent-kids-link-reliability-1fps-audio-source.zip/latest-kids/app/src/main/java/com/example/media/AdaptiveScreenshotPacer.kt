package com.example.media

/** Adapts screenshot cadence to measured capture/encode/transfer time without exceeding 1 FPS. */
internal class AdaptiveScreenshotPacer(
    private val minIntervalMs: Long = 1_000L,
    private val maxIntervalMs: Long = 10_000L
) {
    var intervalMs: Long = minIntervalMs
        private set

    private var stableFrames = 0

    fun onCaptureFailure() {
        intervalMs = (intervalMs * 2).coerceAtMost(maxIntervalMs)
        stableFrames = 0
    }

    fun onFrameCompleted(workDurationMs: Long, wasCongested: Boolean) {
        val workMs = workDurationMs.coerceAtLeast(1L)
        if (wasCongested || workMs >= intervalMs * 8 / 10) {
            // Give the measured operation room to complete before requesting another frame.
            intervalMs = maxOf(intervalMs, (workMs * 5 / 4).coerceAtLeast(minIntervalMs))
                .coerceAtMost(maxIntervalMs)
            stableFrames = 0
            return
        }

        stableFrames++
        // Recover cautiously: one small step after a sustained run of fast, unbuffered frames.
        if (stableFrames >= 8) {
            intervalMs = (intervalMs * 9 / 10).coerceAtLeast(minIntervalMs)
            stableFrames = 0
        }
    }
}
