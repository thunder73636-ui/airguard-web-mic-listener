package com.example.media

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.Log

/** Torch control only. Real video capture is owned exclusively by WebRtcMediaClient. */
class ChildCameraCaptureEngine(private val context: Context) {
    private var isFlashlightOn = false

    @Synchronized
    fun toggleFlashlight(): Boolean {
        return setFlashlight(!isFlashlightOn)
    }

    @Synchronized
    fun setFlashlight(enabled: Boolean): Boolean {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return false
        return try {
            val cameras = manager.cameraIdList.mapNotNull { id ->
                val characteristics = manager.getCameraCharacteristics(id)
                if (characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) != true) return@mapNotNull null
                id to characteristics.get(CameraCharacteristics.LENS_FACING)
            }
            val torchCameraId = cameras.firstOrNull { it.second == CameraCharacteristics.LENS_FACING_BACK }?.first
                ?: cameras.firstOrNull()?.first
                ?: return false
            isFlashlightOn = enabled
            manager.setTorchMode(torchCameraId, isFlashlightOn)
            isFlashlightOn
        } catch (error: Exception) {
            Log.w("ChildCamera", "Unable to change flashlight state: ${error.message}")
            isFlashlightOn = false
            false
        }
    }

    fun release() {
        if (isFlashlightOn) toggleFlashlight()
    }
}
