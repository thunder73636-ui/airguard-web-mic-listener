package com.example.media

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.model.IceCandidatePayload
import com.example.data.model.MediaSessionState
import com.example.data.model.RemoteMediaSession
import com.example.data.model.SdpPayload
import com.example.data.repository.ChildSyncRepository
import com.example.service.AirGuardAccessibilityService
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlin.coroutines.resume

data class WebRtcPermissionPrompt(
    val session: RemoteMediaSession,
    val missingPermissions: List<String>
)

internal object MediaPermissionPolicy {
    fun missingPermissions(type: String, hasCamera: Boolean, hasMicrophone: Boolean): List<String> = buildList {
        when (type.uppercase()) {
            "CAMERA" -> {
                if (!hasCamera) add(android.Manifest.permission.CAMERA)
                if (!hasMicrophone) add(android.Manifest.permission.RECORD_AUDIO)
            }
            "ONE_WAY_AUDIO" -> if (!hasMicrophone) add(android.Manifest.permission.RECORD_AUDIO)
            "ACCESSIBILITY_SCREENSHOT" -> if (!hasMicrophone) add(android.Manifest.permission.RECORD_AUDIO)
        }
    }
}

/**
 * Child-side WebRTC signaling and media transmission manager.
 *
 * Protocol shared with the parent app (Firestore, collection `remote_requests`):
 *  - Parent creates doc `req_<device>_<type>_<millis>` with `sdpOffer` (raw SDP string), `deviceId`, `type`, `timestamp`.
 *  - Parent ICE candidates -> subcollection `candidates` (sender = "parent", field `candidate`).
 *  - Child writes `sdpAnswer` {type, sdp} + status ANSWER_SENT, then status CONNECTED once the
 *    PeerConnection is really connected (or FAILED with `details`).
 *  - Child ICE candidates -> same subcollection (sender = "child", field `candidate`).
 *  - Parent ends the call by writing status DISCONNECTED.
 */
class ChildMediaSignalingManager(
    private val context: Context,
    private val repository: ChildSyncRepository
) {
    companion object {
        private const val TAG = "ChildMediaSignaling"
        const val COLLECTION_REMOTE_REQUESTS = "remote_requests"
        // Offers older than this are leftovers from a previous run and must not turn the camera on.
        private const val MAX_OFFER_AGE_MS = 180_000L
        private const val PARENT_LEASE_TIMEOUT_MS = 60_000L
        private const val PARENT_LEASE_POLL_MS = 15_000L
        private const val MAX_SCREENSHOT_CAPTURE_FAILURES = 6
    }

    private val firestore: FirebaseFirestore? = repository.getFirestore()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var requestsListener: ListenerRegistration? = null
    @Volatile private var listeningChildId: String? = null
    private var candidatesListener: ListenerRegistration? = null
    private var parentLeaseJob: Job? = null
    private var accessibilityScreenshotJob: Job? = null
    @Volatile private var lastParentHeartbeatAt: Long = 0L

    private val _activeSession = MutableStateFlow<RemoteMediaSession?>(null)
    val activeSession: StateFlow<RemoteMediaSession?> = _activeSession.asStateFlow()

    private val _pendingPermissionPrompt = MutableStateFlow<WebRtcPermissionPrompt?>(null)
    val pendingPermissionPrompt: StateFlow<WebRtcPermissionPrompt?> = _pendingPermissionPrompt.asStateFlow()
    @Volatile var pendingScreenCaptureSession: RemoteMediaSession? = null
        private set

    // Kept only for torch control. The WebRTC client owns the real camera/mic capture;
    // opening them twice made the camera fail / go black.
    private var cameraCaptureEngine: ChildCameraCaptureEngine? = null
    private var webRtcMediaClient: WebRtcMediaClient? = null

    @Volatile private var activeSessionId: String? = null
    @Volatile private var requestedAccessibilityMicrophoneEnabled = false
    private val handledOffers: MutableSet<String> = java.util.Collections.synchronizedSet(mutableSetOf())
    private val processedIceCandidates: MutableSet<String> = java.util.Collections.synchronizedSet(mutableSetOf())
    private val processedControlCommands: MutableSet<String> = java.util.Collections.synchronizedSet(mutableSetOf())

    init {
        setupEngines()
    }

    private fun setupEngines() {
        cameraCaptureEngine = ChildCameraCaptureEngine(context)

        try {
            webRtcMediaClient = WebRtcMediaClient(
                context = context,
                onLocalIceCandidate = { candidate -> sendLocalIceCandidate(candidate) },
                onConnectionStateChanged = { state -> handleConnectionState(state) },
                onControlMessage = { message -> handleControlCommand(message) }
            )
        } catch (e: Throwable) {
            Log.w(TAG, "WebRtcMediaClient init failed: ${e.message}")
        }
    }

    /** Starts (or restarts) listening for streaming requests dispatched by the Parent device. */
    @Synchronized
    fun startListening() {
        val childId = repository.getChildDeviceId()
        val db = firestore ?: return

        if (requestsListener != null && listeningChildId == childId) {
            Log.d(TAG, "Signaling listener already active for device $childId; keeping existing connection")
            return
        }

        requestsListener?.remove()
        requestsListener = null
        listeningChildId = null
        try {
            requestsListener = db.collection(COLLECTION_REMOTE_REQUESTS)
                .whereEqualTo("deviceId", childId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) {
                        Log.w(TAG, "Error listening to remote requests: ${error?.message}")
                        return@addSnapshotListener
                    }
                    // The initial snapshot contains all pending requests; later callbacks contain
                    // only changed docs. Avoid rescanning request history on every heartbeat or
                    // control update so current commands are handled promptly.
                    for (change in snapshot.documentChanges) {
                        try {
                            handleRequestDoc(change.document)
                        } catch (e: Exception) {
                            Log.w(TAG, "Ignoring unreadable request ${change.document.id}: ${e.message}")
                        }
                    }
                }
            listeningChildId = childId
            Log.i(TAG, "ChildMediaSignalingManager listening for requests on device: $childId")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start listening to remote requests: ${e.message}")
        }
    }

    /**
     * The parent writes `sdpOffer` as a plain String; older code expected an object, which made
     * Firestore's toObject() throw and the child never saw the offer. Accept both shapes.
     */
    private fun parseSession(doc: DocumentSnapshot): RemoteMediaSession {
        val offerAny = doc.get("sdpOffer")
        val offerSdp = when (offerAny) {
            is String -> offerAny
            is Map<*, *> -> offerAny["sdp"] as? String
            else -> null
        }
        val ts = doc.getLong("timestamp") ?: 0L
        return RemoteMediaSession(
            id = doc.id,
            sessionToken = doc.getString("sessionToken") ?: doc.id,
            deviceId = doc.getString("deviceId") ?: "",
            type = doc.getString("type") ?: "CAMERA",
            status = doc.getString("status") ?: "IDLE",
            sdpOffer = offerSdp?.takeIf { it.isNotBlank() }?.let { SdpPayload("offer", it, ts) },
            details = doc.getString("details") ?: "",
            timestamp = ts,
            forceRelay = doc.getBoolean("forceRelay") ?: false,
            expiresAt = doc.getLong("expiresAt") ?: 0L,
            parentHeartbeatAt = doc.getLong("parentHeartbeatAt") ?: 0L
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun handleRequestDoc(doc: DocumentSnapshot) {
        val session = parseSession(doc)
        (doc.get("lastControlCommand") as? Map<*, *>)?.let(::handleControlCommand)
        if (session.parentHeartbeatAt > 0L) {
            if (activeSessionId == session.id) {
                lastParentHeartbeatAt = maxOf(lastParentHeartbeatAt, session.parentHeartbeatAt)
            }
            _pendingPermissionPrompt.value?.let { pending ->
                if (pending.session.id == session.id && pending.session.parentHeartbeatAt < session.parentHeartbeatAt) {
                    _pendingPermissionPrompt.value = pending.copy(
                        session = pending.session.copy(parentHeartbeatAt = session.parentHeartbeatAt)
                    )
                }
            }
        }
        val alreadyAccepted = session.status.uppercase() in setOf("ANSWER_SENT", "CONNECTED", "ACTIVE", "STREAMING")
        if (session.expiresAt > 0L && System.currentTimeMillis() >= session.expiresAt && !alreadyAccepted) {
            clearPendingConsent(session.id)
            if (session.status.uppercase() !in setOf("FAILED", "DISCONNECTED", "COMPLETED")) {
                updateSessionDoc(session.id, mapOf(
                    "status" to MediaSessionState.FAILED.name,
                    "details" to "This media request expired before it was approved."
                ))
            }
            return
        }
        when (session.status.uppercase()) {
            "OFFER_SENT", "PENDING_CONSENT", "CONNECTING", "REQUESTED", "CHILD_CLIENT_REQUIRED" -> {
                val offer = session.sdpOffer?.sdp
                if (offer.isNullOrBlank()) return // no real WebRTC offer yet - never fake an answer
                if (System.currentTimeMillis() - session.timestamp > MAX_OFFER_AGE_MS) return // stale
                if (!handledOffers.add(session.id + ":" + offer.hashCode())) return // already handled
                evaluateAndHandleOffer(session)
            }
            "DISCONNECTED", "COMPLETED", "FAILED" -> {
                clearPendingConsent(session.id)
                if (activeSessionId == session.id) handleSessionClosed(session)
            }
        }

    }

    private fun handleControlCommand(fields: Map<*, *>) {
        val action = fields["action"] as? String ?: return
        val timestamp = (fields["timestamp"] as? Number)?.toLong() ?: 0L
        val signature = "$timestamp:$action:${fields["facing"]}:${fields["enabled"]}"
        if (timestamp > 0L && !processedControlCommands.add(signature)) return
        if (processedControlCommands.size > 128) processedControlCommands.clear()

        when (action) {
            "SWITCH_CAMERA" -> webRtcMediaClient?.switchCamera((fields["facing"] as? String) == "FRONT")
            "TOGGLE_FLASH" -> cameraCaptureEngine?.setFlashlight(fields["enabled"] as? Boolean ?: false)
            "SET_MICROPHONE" -> {
                val enabled = fields["enabled"] as? Boolean ?: false
                requestedAccessibilityMicrophoneEnabled = enabled
                if (_activeSession.value?.type.equals("ACCESSIBILITY_SCREENSHOT", ignoreCase = true)) {
                    webRtcMediaClient?.setAccessibilityMicrophoneEnabled(enabled)
                }
            }
            "CAPTURE_SNAPSHOT" -> _activeSession.value
                ?.takeIf { it.type.equals("ACCESSIBILITY_SCREENSHOT", ignoreCase = true) }
                ?.let(::startAccessibilityScreenshotStream)
            else -> Log.d(TAG, "Ignoring unknown parent control: $action")
        }
    }

    @Synchronized
    private fun startAccessibilityScreenshotStream(session: RemoteMediaSession) {
        if (!session.type.equals("ACCESSIBILITY_SCREENSHOT", ignoreCase = true)) return
        if (accessibilityScreenshotJob?.isActive == true) return
        accessibilityScreenshotJob = scope.launch(Dispatchers.IO) {
            var frameNumber = 0L
            val pacer = AdaptiveScreenshotPacer()
            var lastFrameStartAt = 0L
            var consecutiveCaptureFailures = 0
            while (isActive && activeSessionId == session.id && AirGuardAccessibilityService.isServiceRunning) {
                val readyClient = webRtcMediaClient ?: break
                // Wait for the prior frame's SCTP data to drain before taking another screenshot.
                var wasCongested = false
                val initialDrainStartedAt = android.os.SystemClock.elapsedRealtime()
                while (isActive && activeSessionId == session.id && !readyClient.canSendControlMessage()) {
                    delay(10)
                }
                if (!isActive || activeSessionId != session.id) break
                if (android.os.SystemClock.elapsedRealtime() - initialDrainStartedAt >= 100L) wasCongested = true
                // 1,000 ms is a hard 1 FPS ceiling. Capture/encode/transfer time and channel
                // backpressure are measured each frame; the pacer lowers the rate when needed.
                val now = android.os.SystemClock.elapsedRealtime()
                val earliestNextFrameAt = lastFrameStartAt + pacer.intervalMs
                if (lastFrameStartAt != 0L && now < earliestNextFrameAt) {
                    delay(earliestNextFrameAt - now)
                }
                if (!isActive || activeSessionId != session.id) break
                val frameStartAt = android.os.SystemClock.elapsedRealtime()
                lastFrameStartAt = frameStartAt
                val capture = kotlinx.coroutines.suspendCancellableCoroutine<AirGuardAccessibilityService.ScreenshotCaptureResult> { continuation ->
                    AirGuardAccessibilityService.captureCurrentScreen { result ->
                        if (continuation.isActive) continuation.resume(result)
                    }
                }
                val jpeg = capture.jpeg
                if (jpeg == null) {
                    consecutiveCaptureFailures++
                    pacer.onCaptureFailure()
                    if (consecutiveCaptureFailures < MAX_SCREENSHOT_CAPTURE_FAILURES) {
                        Log.w(TAG, "Accessibility screenshot failed; retrying at ${pacer.intervalMs}ms (${capture.errorMessage ?: "unknown error"})")
                        continue
                    }
                    webRtcMediaClient?.sendControlMessage(org.json.JSONObject(mapOf(
                        "type" to "SCREEN_FRAME_ERROR",
                        "message" to (capture.errorMessage ?: "Accessibility screenshot capture failed on the child device.")
                    )).toString())
                    break
                }
                consecutiveCaptureFailures = 0

                val client = webRtcMediaClient ?: break
                val frameId = "${session.id}_$frameNumber"
                val encoded = android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP)
                val chunkSize = 18_000
                val total = (encoded.length + chunkSize - 1) / chunkSize
                var sentAllChunks = true
                for (index in 0 until total) {
                    if (!isActive || activeSessionId != session.id) {
                        sentAllChunks = false
                        break
                    }
                    val chunkDrainStartedAt = android.os.SystemClock.elapsedRealtime()
                    while (isActive && activeSessionId == session.id && !client.canSendControlMessage()) {
                        delay(10)
                    }
                    if (android.os.SystemClock.elapsedRealtime() - chunkDrainStartedAt >= 100L) wasCongested = true
                    if (!isActive || activeSessionId != session.id) {
                        sentAllChunks = false
                        break
                    }
                    val start = index * chunkSize
                    val packet = org.json.JSONObject().apply {
                        put("type", "SCREEN_FRAME_CHUNK")
                        put("frameId", frameId)
                        put("index", index)
                        put("total", total)
                        put("data", encoded.substring(start, minOf(encoded.length, start + chunkSize)))
                    }
                    if (!client.sendControlMessage(packet.toString())) {
                        sentAllChunks = false
                        break
                    }
                }
                if (sentAllChunks) {
                    client.sendControlMessage(org.json.JSONObject(mapOf(
                        "type" to "SCREEN_FRAME_COMPLETE", "frameId" to frameId
                    )).toString())
                    frameNumber++
                    val workDuration = android.os.SystemClock.elapsedRealtime() - frameStartAt
                    pacer.onFrameCompleted(workDuration, wasCongested)
                    if (frameNumber % 30L == 0L) {
                        val estimatedFps = 1_000f / maxOf(pacer.intervalMs, workDuration).coerceAtLeast(1L)
                        Log.i(TAG, "Accessibility screenshot pacing: ${"%.1f".format(java.util.Locale.US, estimatedFps)} FPS estimated; target interval ${pacer.intervalMs}ms, frame work ${workDuration}ms")
                    }
                } else {
                    pacer.onCaptureFailure()
                    delay(pacer.intervalMs)
                }
            }
        }
    }

    private fun handleControlCommand(raw: String) {
        try {
            val json = org.json.JSONObject(raw)
            val fields = mutableMapOf<String, Any>("action" to json.optString("action"))
            if (json.has("timestamp")) fields["timestamp"] = json.optLong("timestamp")
            if (json.has("facing")) fields["facing"] = json.optString("facing")
            if (json.has("enabled")) fields["enabled"] = json.optBoolean("enabled")
            if (json.has("screenshotId")) fields["screenshotId"] = json.optString("screenshotId")
            handleControlCommand(fields)
        } catch (e: Exception) {
            Log.w(TAG, "Ignoring malformed parent control message: ${e.message}")
        }
    }

    /** Reuse Android permissions already granted on the child phone for later parent requests. */
    fun evaluateAndHandleOffer(session: RemoteMediaSession) {
        if (session.type.equals("ACCESSIBILITY_SCREENSHOT", ignoreCase = true)) {
            if (!AirGuardAccessibilityService.isServiceRunning || android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) {
                updateSessionDoc(session.id, mapOf(
                    "status" to MediaSessionState.FAILED.name,
                    "details" to "Enable AirGuard Kids Accessibility and use Android 11 or newer for screenshots."
                ))
                return
            }
        }
        if (session.type.equals("SCREEN_MIRROR", ignoreCase = true)) {
            _pendingPermissionPrompt.value = WebRtcPermissionPrompt(session, emptyList())
            updateSessionDoc(session.id, mapOf(
                "status" to MediaSessionState.PENDING_CONSENT.name,
                "details" to "Waiting for the child to approve screen sharing in Android's screen-capture dialog."
            ))
            return
        }

        val hasCam = androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.CAMERA
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        val missing = MediaPermissionPolicy.missingPermissions(session.type, hasCam, hasMic)
        if (missing.isEmpty() && session.type.uppercase() in setOf("CAMERA", "ONE_WAY_AUDIO", "ACCESSIBILITY_SCREENSHOT")) {
            Log.i(TAG, "Starting ${session.type} for ${session.id} using permissions already granted on the child device")
            updateSessionDoc(session.id, mapOf(
                "status" to "CONNECTING",
                "details" to "Starting with previously granted Android permissions; the child device shows live camera/microphone indicators and an ongoing notification."
            ))
            handleIncomingOffer(session)
            return
        }

        // Only ask the child when Android has not granted a permission required by this request.
        Log.i(TAG, "Waiting for required Android permission on session ${session.id}; missing: $missing")
        _pendingPermissionPrompt.value = WebRtcPermissionPrompt(session, missing)
        updateSessionDoc(session.id, mapOf(
            "status" to MediaSessionState.PENDING_CONSENT.name,
            "details" to "Waiting for the required camera or microphone permission on the child phone"
        ))
    }

    fun onPermissionsGranted(session: RemoteMediaSession) {
        if (_pendingPermissionPrompt.value?.session?.id != session.id) {
            Log.w(TAG, "Ignoring approval callback for a session that is no longer awaiting consent")
            return
        }
        _pendingPermissionPrompt.value = null
        if (session.expiresAt > 0L && System.currentTimeMillis() >= session.expiresAt) {
            updateSessionDoc(session.id, mapOf(
                "status" to MediaSessionState.FAILED.name,
                "details" to "This media request expired. Waiting for a fresh parent request."
            ))
            return
        }
        if (session.type.equals("SCREEN_MIRROR", ignoreCase = true)) {
            pendingScreenCaptureSession = session
            updateSessionDoc(session.id, mapOf(
                "status" to MediaSessionState.PENDING_CONSENT.name,
                "details" to "Waiting for Android screen-capture approval on the child device."
            ))
            return
        }
        handleIncomingOffer(session)
    }

    /** Called by the foreground service only after Android has granted MediaProjection consent. */
    fun onScreenCaptureGranted(resultCode: Int, projectionData: Intent?) {
        val session = pendingScreenCaptureSession ?: return
        pendingScreenCaptureSession = null
        // Activity.RESULT_OK is -1. Do not compare this value as though it were a positive code.
        if (resultCode != -1 || projectionData == null) {
            onScreenCaptureDenied(session)
            return
        }
        if (session.expiresAt > 0L && System.currentTimeMillis() >= session.expiresAt) {
            updateSessionDoc(session.id, mapOf("status" to MediaSessionState.FAILED.name,
                "details" to "Screen-share request expired before Android capture approval."))
            return
        }
        updateSessionDoc(session.id, mapOf("status" to "CONNECTING", "details" to "Android approved screen sharing; starting the live screen stream."))
        handleIncomingOffer(session, resultCode, projectionData)
    }

    fun onScreenCaptureDenied() {
        pendingScreenCaptureSession?.let(::onScreenCaptureDenied)
    }

    fun onScreenCaptureStartFailed(reason: String) {
        val session = pendingScreenCaptureSession ?: return
        pendingScreenCaptureSession = null
        updateSessionDoc(session.id, mapOf(
            "status" to MediaSessionState.FAILED.name,
            "details" to "Android could not start the visible screen-sharing service: $reason"
        ))
    }

    private fun onScreenCaptureDenied(session: RemoteMediaSession) {
        pendingScreenCaptureSession = null
        updateSessionDoc(session.id, mapOf(
            "status" to MediaSessionState.PERMISSION_DENIED.name,
            "details" to "Screen sharing was declined in Android's screen-capture dialog."
        ))
    }

    fun onPermissionsDenied(session: RemoteMediaSession) {
        _pendingPermissionPrompt.value = null
        updateSessionDoc(session.id, mapOf(
            "status" to MediaSessionState.PERMISSION_DENIED.name,
            "details" to "Camera or Microphone permission was denied by child user"
        ))
    }

    private fun clearPendingConsent(sessionId: String) {
        if (_pendingPermissionPrompt.value?.session?.id == sessionId) {
            _pendingPermissionPrompt.value = null
        }
        if (pendingScreenCaptureSession?.id == sessionId) pendingScreenCaptureSession = null
    }

    private fun updateSessionDoc(sessionId: String, fields: Map<String, Any>) {
        val db = firestore ?: return
        scope.launch {
            try {
                db.collection(COLLECTION_REMOTE_REQUESTS).document(sessionId)
                    .set(fields, SetOptions.merge()).await()
            } catch (e: Exception) {
                Log.w(TAG, "Session update deferred: ${e.message}")
            }
        }
    }

    private fun ingestRemoteIceCandidates(candidates: List<Map<String, Any>>) {
        for (cand in candidates) {
            val sdp = cand["sdpCandidate"] as? String ?: cand["candidate"] as? String ?: continue
            if (sdp.isBlank() || !processedIceCandidates.add(sdp)) continue

            webRtcMediaClient?.addRemoteIceCandidate(
                IceCandidatePayload(
                    sdpMid = cand["sdpMid"] as? String ?: "0",
                    sdpMLineIndex = (cand["sdpMLineIndex"] as? Number)?.toInt() ?: 0,
                    sdpCandidate = sdp,
                    serverUrl = cand["serverUrl"] as? String ?: ""
                )
            )
        }
    }

    private fun attachParentCandidatesListener(sessionId: String) {
        val db = firestore ?: return
        candidatesListener?.remove()
        try {
            candidatesListener = db.collection(COLLECTION_REMOTE_REQUESTS).document(sessionId)
                .collection("candidates")
                .addSnapshotListener { snap, err ->
                    if (err != null || snap == null) {
                        Log.w(TAG, "Candidate listener notice: ${err?.message}")
                        return@addSnapshotListener
                    }
                    val list = snap.documents
                        .filter { it.getString("sender") != "child" }
                        .mapNotNull { it.data }
                    ingestRemoteIceCandidates(list)
                }
        } catch (e: Exception) {
            Log.w(TAG, "Failed attaching candidate listener: ${e.message}")
        }
    }

    private fun handleIncomingOffer(session: RemoteMediaSession, projectionResultCode: Int? = null, projectionData: Intent? = null) {
        val offerSdp = session.sdpOffer?.sdp
        if (offerSdp.isNullOrBlank()) {
            failSession(session, "Parent sent no SDP offer")
            return
        }
        val client = webRtcMediaClient
        if (client == null) {
            failSession(session, "WebRTC engine is unavailable on the child phone")
            return
        }
        if (ParentLeasePolicy.isExpired(session.parentHeartbeatAt, System.currentTimeMillis(), PARENT_LEASE_TIMEOUT_MS)) {
            failSession(session, "Parent session expired before media startup; camera and microphone were not started")
            return
        }

        // Tear down any previous call before starting a new one
        if (activeSessionId != null) {
            client.close()
            processedIceCandidates.clear()
        }
        // Register the session BEFORE answering so ICE candidates generated during the handshake are not dropped
        activeSessionId = session.id
        if (session.type.equals("ACCESSIBILITY_SCREENSHOT", ignoreCase = true)) {
            client.setAccessibilityMicrophoneEnabled(requestedAccessibilityMicrophoneEnabled)
        }
        lastParentHeartbeatAt = session.parentHeartbeatAt
        _activeSession.value = session.copy(status = MediaSessionState.OFFER_RECEIVED.name)
        attachParentCandidatesListener(session.id)
        startParentLeaseWatchdog(session)

        scope.launch {
            val db = firestore
            val childId = repository.getChildDeviceId()
            val hasCam = androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.CAMERA
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.RECORD_AUDIO
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            try {
                db?.collection("devices")?.document(childId)?.set(
                    mapOf(
                        "isOnline" to true,
                        "hasCameraPermission" to hasCam,
                        "hasMicrophonePermission" to hasMic,
                        "lastSeenTimestamp" to System.currentTimeMillis(),
                        "lastSeenServerAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                )
            } catch (e: Exception) {
                Log.w(TAG, "Device status refresh deferred: ${e.message}")
            }

            client.handleOfferAndCreateAnswer(
                offerSdp = offerSdp,
                sessionType = session.type,
                forceRelay = session.forceRelay,
                projectionResultCode = projectionResultCode,
                projectionData = projectionData,
                onAnswerCreated = { answer -> sendAnswer(session, answer) },
                onError = { msg -> failSession(session, msg) }
            )
        }
    }

    /** Stop capture when the parent disappears without sending a normal session-close signal. */
    private fun startParentLeaseWatchdog(session: RemoteMediaSession) {
        parentLeaseJob?.cancel()
        if (session.parentHeartbeatAt <= 0L) return // Older parent builds do not publish leases.
        parentLeaseJob = scope.launch {
            while (activeSessionId == session.id) {
                delay(PARENT_LEASE_POLL_MS)
                if (activeSessionId != session.id) break
                val heartbeat = lastParentHeartbeatAt
                if (ParentLeasePolicy.isExpired(heartbeat, System.currentTimeMillis(), PARENT_LEASE_TIMEOUT_MS)) {
                    Log.w(TAG, "Parent lease expired; stopping media capture for ${session.id}")
                    updateSessionDoc(session.id, mapOf(
                        "status" to MediaSessionState.DISCONNECTED.name,
                        "details" to "Parent session lease expired; media capture stopped on child device."
                    ))
                    handleSessionClosed(session)
                    break
                }
            }
        }
    }

    private fun sendAnswer(session: RemoteMediaSession, answer: SdpPayload) {
        val db = firestore ?: return
        scope.launch {
            try {
                db.collection(COLLECTION_REMOTE_REQUESTS).document(session.id).set(
                    mapOf(
                        "status" to MediaSessionState.ANSWER_SENT.name,
                        "sdpAnswer" to mapOf(
                            "type" to answer.type,
                            "sdp" to answer.sdp,
                            "timestamp" to answer.timestamp
                        ),
                        "details" to "Child answered, establishing ${session.type} media link",
                        "lastHandshake" to System.currentTimeMillis()
                    ),
                    SetOptions.merge()
                ).await()
                Log.i(TAG, "SDP answer sent for ${session.id} (${session.type})")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to send SDP answer: ${e.message}")
            }
        }
    }

    private fun handleConnectionState(state: org.webrtc.PeerConnection.PeerConnectionState) {
        val session = _activeSession.value ?: return
        when (state) {
            org.webrtc.PeerConnection.PeerConnectionState.CONNECTED -> {
                _activeSession.value = session.copy(status = MediaSessionState.CONNECTED.name)
                updateSessionDoc(session.id, mapOf(
                    "status" to MediaSessionState.CONNECTED.name,
                    "details" to "WebRTC media stream established (${session.type})"
                ))
                if (session.type.equals("ACCESSIBILITY_SCREENSHOT", ignoreCase = true)) {
                    startAccessibilityScreenshotStream(session)
                }
            }
            org.webrtc.PeerConnection.PeerConnectionState.FAILED ->
                failSession(session, "WebRTC connection failed (network/firewall between the two phones)")
            else -> Unit
        }
    }

    /** Reports a REAL failure to the parent instead of faking a connected stream. */
    private fun failSession(session: RemoteMediaSession, reason: String) {
        Log.w(TAG, "Session ${session.id} failed: $reason")
        updateSessionDoc(session.id, mapOf(
            "status" to MediaSessionState.FAILED.name,
            "details" to reason
        ))
        if (activeSessionId == session.id) handleSessionClosed(session)
    }

    private fun sendLocalIceCandidate(candidate: IceCandidatePayload) {
        val sid = activeSessionId ?: return
        val db = firestore ?: return
        try {
            db.collection(COLLECTION_REMOTE_REQUESTS).document(sid).collection("candidates").add(
                mapOf(
                    "sdpMid" to candidate.sdpMid,
                    "sdpMLineIndex" to candidate.sdpMLineIndex,
                    "candidate" to candidate.sdpCandidate,
                    "sdpCandidate" to candidate.sdpCandidate,
                    "sender" to "child",
                    "timestamp" to System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed to send local ICE candidate: ${e.message}")
        }
    }

    private fun handleSessionClosed(session: RemoteMediaSession) {
        Log.i(TAG, "Remote session ${session.id} closed")
        candidatesListener?.remove()
        candidatesListener = null
        parentLeaseJob?.cancel()
        parentLeaseJob = null
        accessibilityScreenshotJob?.cancel()
        accessibilityScreenshotJob = null
        webRtcMediaClient?.close()
        if (session.type.equals("ACCESSIBILITY_SCREENSHOT", ignoreCase = true)) {
            requestedAccessibilityMicrophoneEnabled = false
        }
        processedIceCandidates.clear()
        activeSessionId = null
        _activeSession.value = null
        if (session.type.equals("SCREEN_MIRROR", ignoreCase = true)) {
            com.example.service.AirGuardMediaCaptureService.stopScreenCaptureMode(context)
        }
    }

    fun flipCamera() {
        webRtcMediaClient?.flipCamera()
    }

    fun toggleFlashlight(): Boolean {
        return cameraCaptureEngine?.toggleFlashlight() ?: false
    }

    fun setFlashlight(enabled: Boolean): Boolean = cameraCaptureEngine?.setFlashlight(enabled) ?: false

    fun stopSession() {
        val active = _activeSession.value
        candidatesListener?.remove()
        candidatesListener = null
        parentLeaseJob?.cancel()
        parentLeaseJob = null
        webRtcMediaClient?.close()
        requestedAccessibilityMicrophoneEnabled = false
        activeSessionId = null
        _activeSession.value = null
        if (active?.type.equals("SCREEN_MIRROR", ignoreCase = true)) {
            com.example.service.AirGuardMediaCaptureService.stopScreenCaptureMode(context)
        }
        if (active != null) {
            updateSessionDoc(active.id, mapOf(
                "status" to MediaSessionState.DISCONNECTED.name,
                "details" to "Session terminated by child device"
            ))
        }
        lastParentHeartbeatAt = 0L
    }

    /** Stops cloud listeners without destroying the process-wide engine, so a later re-pair works. */
    @Synchronized
    fun stopListening() {
        requestsListener?.remove()
        requestsListener = null
        listeningChildId = null
        candidatesListener?.remove()
        candidatesListener = null
        stopSession()
    }

    fun release() {
        stopSession()
        requestsListener?.remove()
        cameraCaptureEngine?.release()
        webRtcMediaClient?.release()
        scope.cancel()
    }

}
