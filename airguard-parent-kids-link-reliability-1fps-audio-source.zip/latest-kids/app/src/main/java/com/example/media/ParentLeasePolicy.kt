package com.example.media

internal object ParentLeasePolicy {
    fun isExpired(lastHeartbeatAt: Long, now: Long, timeoutMs: Long): Boolean =
        lastHeartbeatAt > 0L && now - lastHeartbeatAt > timeoutMs
}
