package com.example.media

/** Parses build-time TURN settings without logging credentials. */
internal object TurnServerConfig {
    fun urls(raw: String): List<String> = raw
        .split(',', ';', '\n', '\r')
        .map(String::trim)
        .filter(String::isNotEmpty)
        .distinct()

    fun isTurnUrl(url: String): Boolean {
        val normalized = url.trim().lowercase()
        return (normalized.startsWith("turn:") || normalized.startsWith("turns:")) &&
            normalized.substringAfter(':').isNotBlank()
    }

    fun isIceServerUrl(url: String): Boolean {
        val normalized = url.trim().lowercase()
        return (normalized.startsWith("stun:") || normalized.startsWith("stuns:") || isTurnUrl(normalized)) &&
            normalized.substringAfter(':').isNotBlank()
    }

    fun isConfigured(rawUrls: String, username: String, credential: String): Boolean =
        urls(rawUrls).any(::isTurnUrl) && username.isNotBlank() && credential.isNotBlank()
}
