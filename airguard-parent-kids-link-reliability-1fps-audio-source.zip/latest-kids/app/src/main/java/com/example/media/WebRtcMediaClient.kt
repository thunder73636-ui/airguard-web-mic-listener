package com.example.media

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjection
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.model.IceCandidatePayload
import com.example.data.model.SdpPayload
import org.webrtc.*
import kotlin.math.abs
import java.util.concurrent.atomic.AtomicBoolean

/**
 * WebRTC media client encapsulating Google WebRTC Android SDK (org.webrtc.*).
 * Initializes audio/video tracks, camera capturer, and handles PeerConnection SDP offer/answer negotiation.
 */
class WebRtcMediaClient(
    private val context: Context,
    private val onLocalIceCandidate: (IceCandidatePayload) -> Unit,
    private val onConnectionStateChanged: (PeerConnection.PeerConnectionState) -> Unit,
    private val onControlMessage: (String) -> Unit = {}
) {
    companion object {
        private const val TAG = "WebRtcMediaClient"
        private const val VIDEO_WIDTH = 1280
        private const val VIDEO_HEIGHT = 720
        private const val VIDEO_FPS = 24
        private val isInitialized = AtomicBoolean(false)
    }

    private var eglBase: EglBase? = null
    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    @Volatile private var remoteControlChannel: DataChannel? = null
    @Volatile private var peerConnectionGeneration = 0L

    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    @Volatile private var accessibilityMicrophoneEnabled = false

    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var videoCapturer: VideoCapturer? = null
    @Volatile private var frontCameraActive = false
    private var captureWidth = VIDEO_WIDTH
    private var captureHeight = VIDEO_HEIGHT
    private var captureFps = VIDEO_FPS
    private var surfaceTextureHelper: SurfaceTextureHelper? = null

    private val queuedRemoteCandidates = mutableListOf<IceCandidate>()
    private var isRemoteDescriptionSet = false

    val isConnected: Boolean
        get() = peerConnection?.connectionState() == PeerConnection.PeerConnectionState.CONNECTED

    init {
        initializeFactory()
    }

    private fun initializeFactory() {
        try {
            if (isInitialized.compareAndSet(false, true)) {
                val initOptions = PeerConnectionFactory.InitializationOptions.builder(context)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
                PeerConnectionFactory.initialize(initOptions)
            }

            eglBase = EglBase.create()
            val encoderFactory = DefaultVideoEncoderFactory(
                eglBase?.eglBaseContext,
                true,
                true
            )
            val decoderFactory = DefaultVideoDecoderFactory(eglBase?.eglBaseContext)

            val options = PeerConnectionFactory.Options()
            peerConnectionFactory = PeerConnectionFactory.builder()
                .setOptions(options)
                .setVideoEncoderFactory(encoderFactory)
                .setVideoDecoderFactory(decoderFactory)
                .createPeerConnectionFactory()

            Log.i(TAG, "PeerConnectionFactory initialized successfully with hardware codec factories")
        } catch (e: Throwable) {
            Log.w(TAG, "WebRTC factory initialization deferred or native lib unavailable: ${e.message}")
        }
    }

    /**
     * Creates and starts the microphone audio track.
     */
    fun createAudioTrack(): AudioTrack? {
        val hasMic = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasMic) {
            Log.w(TAG, "RECORD_AUDIO permission not granted, skipping WebRTC AudioTrack creation")
            return null
        }

        val factory = peerConnectionFactory ?: return null
        if (audioTrack == null) {
            try {
                val audioConstraints = MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
                }
                audioSource = factory.createAudioSource(audioConstraints)
                audioTrack = factory.createAudioTrack("ARDAMSa0", audioSource)
                audioTrack?.setEnabled(true)
                Log.i(TAG, "Local WebRTC AudioTrack created successfully")
            } catch (e: Throwable) {
                Log.w(TAG, "Failed to create WebRTC AudioTrack: ${e.message}")
            }
        }
        return audioTrack
    }

    /** Starts/stops the Accessibility View microphone track without ending its screenshot session. */
    fun setAccessibilityMicrophoneEnabled(enabled: Boolean) {
        accessibilityMicrophoneEnabled = enabled
        val pc = peerConnection ?: return
        val audioTransceiver = pc.transceivers
            .firstOrNull { it.mediaType == MediaStreamTrack.MediaType.MEDIA_TYPE_AUDIO } ?: return
        val sender = audioTransceiver.sender

        if (enabled) {
            val track = createAudioTrack() ?: return
            track.setEnabled(true)
            if (!sender.setTrack(track, false)) {
                Log.w(TAG, "Could not attach the microphone track to the Accessibility View session")
            } else {
                Log.i(TAG, "Accessibility View microphone capture enabled")
            }
        } else {
            sender.setTrack(null, false)
            audioTrack?.dispose()
            audioTrack = null
            audioSource?.dispose()
            audioSource = null
            Log.i(TAG, "Accessibility View microphone capture stopped")
        }
    }

    /**
     * Creates and starts the camera video track at 30 FPS.
     */
    fun createVideoTrack(useFrontCamera: Boolean = false): VideoTrack? {
        val hasCam = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasCam) {
            Log.w(TAG, "CAMERA permission not granted, skipping WebRTC VideoTrack creation")
            return null
        }

        if (videoTrack == null) {
            try {
                videoCapturer = createCameraCapturer(useFrontCamera)
                frontCameraActive = useFrontCamera
                startVideoTrack()
            } catch (e: Throwable) {
                Log.w(TAG, "Failed to create WebRTC VideoTrack: ${e.message}")
            }
        }
        return videoTrack
    }

    private fun startVideoTrack(): VideoTrack? {
        val capturer = videoCapturer ?: return null
        val factory = peerConnectionFactory ?: return null
        val egl = eglBase ?: return null
        surfaceTextureHelper = SurfaceTextureHelper.create("WebRtcCaptureThread", egl.eglBaseContext)
        videoSource = factory.createVideoSource(capturer.isScreencast)
        capturer.initialize(surfaceTextureHelper, context, videoSource?.capturerObserver)
        capturer.startCapture(captureWidth, captureHeight, captureFps)
        videoTrack = factory.createVideoTrack("ARDAMSv0", videoSource)
        videoTrack?.setEnabled(true)
        Log.i(TAG, "Local WebRTC ${if (capturer.isScreencast) "screen" else "camera"} track started at ${captureWidth}x${captureHeight}@${captureFps}fps")
        return videoTrack
    }

    private fun createScreenVideoTrack(projectionData: Intent): VideoTrack? {
        if (videoTrack != null) return videoTrack
        val metrics = context.resources.displayMetrics
        val sourceWidth = metrics.widthPixels.coerceAtLeast(1)
        val sourceHeight = metrics.heightPixels.coerceAtLeast(1)
        val longestEdgeScale = VIDEO_WIDTH.toFloat() / maxOf(sourceWidth, sourceHeight)
        val shortestEdgeScale = VIDEO_HEIGHT.toFloat() / minOf(sourceWidth, sourceHeight)
        val scale = minOf(1f, longestEdgeScale, shortestEdgeScale)
        captureWidth = (sourceWidth * scale).toInt().coerceAtLeast(2).let { it - it % 2 }
        captureHeight = (sourceHeight * scale).toInt().coerceAtLeast(2).let { it - it % 2 }
        videoCapturer = ScreenCapturerAndroid(projectionData, object : MediaProjection.Callback() {
            override fun onStop() {
                Log.i(TAG, "Android stopped the screen-capture projection")
            }
        })
        return startVideoTrack()
    }

    private fun createCameraCapturer(useFrontCamera: Boolean): VideoCapturer? {
        return try {
            val enumerator = if (Camera2Enumerator.isSupported(context)) {
                Camera2Enumerator(context)
            } else {
                Camera1Enumerator(true)
            }

            val deviceNames = enumerator.deviceNames
            val preferredName = deviceNames.firstOrNull { name ->
                if (useFrontCamera) enumerator.isFrontFacing(name) else enumerator.isBackFacing(name)
            } ?: deviceNames.firstOrNull()
            val deviceName = preferredName ?: return null
            val capturer = enumerator.createCapturer(deviceName, null) ?: return null

            // Pick an actual sensor mode near 720p, preferring the largest mode at or below
            // that target. Older/low-end phones fall back to their best supported format.
            val formats = enumerator.getSupportedFormats(deviceName)
            val atOrBelowTarget = formats.filter { it.width <= VIDEO_WIDTH && it.height <= VIDEO_HEIGHT }
            val chosen = atOrBelowTarget.maxByOrNull { it.width.toLong() * it.height }
                ?: formats.minByOrNull { abs(it.width - VIDEO_WIDTH) + abs(it.height - VIDEO_HEIGHT) }
            captureWidth = chosen?.width ?: 640
            captureHeight = chosen?.height ?: 480
            captureFps = VIDEO_FPS
            capturer
        } catch (e: Throwable) {
            Log.w(TAG, "Could not create camera capturer: ${e.message}")
            null
        }
    }

    /**
     * Initializes PeerConnection with standard Google STUN servers.
     */
    fun createPeerConnection(forceRelay: Boolean = false): PeerConnection? {
        val factory = peerConnectionFactory ?: return null

        val configuredIceUrls = TurnServerConfig.urls(com.example.BuildConfig.TURN_SERVER_URL)
            .filter(TurnServerConfig::isIceServerUrl)
        val iceServers = buildList {
            add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
            configuredIceUrls.forEach { url ->
                val builder = PeerConnection.IceServer.builder(url)
                if (TurnServerConfig.isTurnUrl(url)) {
                    builder.setUsername(com.example.BuildConfig.TURN_USERNAME)
                        .setPassword(com.example.BuildConfig.TURN_CREDENTIAL)
                }
                add(builder.createIceServer())
            }
        }

        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            if (forceRelay) iceTransportsType = PeerConnection.IceTransportsType.RELAY
        }

        val generation = ++peerConnectionGeneration
        val observer = object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate?) {
                if (generation != peerConnectionGeneration) return
                if (candidate != null) {
                    val payload = IceCandidatePayload(
                        sdpMid = candidate.sdpMid ?: "0",
                        sdpMLineIndex = candidate.sdpMLineIndex,
                        sdpCandidate = candidate.sdp,
                        serverUrl = candidate.serverUrl ?: ""
                    )
                    onLocalIceCandidate(payload)
                }
            }

            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {
                if (generation != peerConnectionGeneration) return
                if (newState != null) {
                    Log.i(TAG, "WebRTC PeerConnectionState changed: $newState")
                    onConnectionStateChanged(newState)
                }
            }

            override fun onSignalingChange(state: PeerConnection.SignalingState?) {
                Log.d(TAG, "SignalingState: $state")
            }

            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                if (generation != peerConnectionGeneration) return
                Log.d(TAG, "IceConnectionState: $state")
            }

            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: MediaStream?) {}
            override fun onRemoveStream(stream: MediaStream?) {}
            override fun onDataChannel(channel: DataChannel?) {
                if (generation != peerConnectionGeneration) return
                val remoteChannel = channel ?: return
                remoteControlChannel = remoteChannel
                Log.i(TAG, "Received parent control DataChannel: ${remoteChannel.label()}")
                remoteChannel.registerObserver(object : DataChannel.Observer {
                    override fun onBufferedAmountChange(previousAmount: Long) = Unit
                    override fun onStateChange() {
                        Log.d(TAG, "Control DataChannel state: ${remoteChannel.state()}")
                    }
                    override fun onMessage(buffer: DataChannel.Buffer?) {
                        if (buffer == null || buffer.binary) return
                        val bytes = ByteArray(buffer.data.remaining())
                        buffer.data.get(bytes)
                        onControlMessage(String(bytes, Charsets.UTF_8))
                    }
                })
            }
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}
        }

        peerConnection = factory.createPeerConnection(rtcConfig, observer)
        return peerConnection
    }

    /**
     * Processes incoming Parent SDP Offer, attaches local tracks, and generates matching SDP Answer.
     */
    fun handleOfferAndCreateAnswer(
        offerSdp: String,
        sessionType: String,
        forceRelay: Boolean = false,
        projectionResultCode: Int? = null,
        projectionData: Intent? = null,
        onAnswerCreated: (SdpPayload) -> Unit,
        onError: (String) -> Unit
    ) {
        if (offerSdp.isBlank()) {
            onError("Offer SDP is blank or invalid")
            return
        }
        if (forceRelay && !TurnServerConfig.isConfigured(
                com.example.BuildConfig.TURN_SERVER_URL,
                com.example.BuildConfig.TURN_USERNAME,
                com.example.BuildConfig.TURN_CREDENTIAL
            )
        ) {
            onError("Parent requested a TURN-only session, but this Kids build has no valid TURN server configuration")
            return
        }

        // Clean up previous peerConnection if any before re-negotiating
        if (peerConnection != null) {
            peerConnectionGeneration++
            try {
                peerConnection?.close()
                peerConnection?.dispose()
            } catch (e: Throwable) {
                Log.w(TAG, "Cleanup previous PeerConnection: ${e.message}")
            }
            peerConnection = null
            isRemoteDescriptionSet = false
            queuedRemoteCandidates.clear()
        }

        val pc = createPeerConnection(forceRelay)
        if (pc == null) {
            onError("PeerConnection could not be initialized")
            return
        }

        try {
            // Attach media tracks based on session type
            if (sessionType == "ONE_WAY_AUDIO" || sessionType == "CAMERA") {
                val aTrack = createAudioTrack()
                if (aTrack != null && pc.senders.none { it.track()?.id() == aTrack.id() }) {
                    pc.addTrack(aTrack, listOf("ARDAMS"))
                }
            }

            if (sessionType == "CAMERA" || sessionType == "SCREEN_MIRROR") {
                val vTrack = if (sessionType == "SCREEN_MIRROR") {
                    if (projectionResultCode == null || projectionData == null) {
                        onError("Android screen-capture approval is missing")
                        close()
                        return
                    }
                    createScreenVideoTrack(projectionData)
                } else createVideoTrack(useFrontCamera = false)
                if (vTrack == null) {
                    onError(if (sessionType == "SCREEN_MIRROR") "Could not start Android screen capture" else "Could not start camera capture")
                    close()
                    return
                }
                if (pc.senders.none { it.track()?.id() == vTrack.id() }) {
                    val sender = pc.addTrack(vTrack, listOf("ARDAMS"))
                    runCatching {
                        val parameters = sender.parameters
                        parameters.encodings?.forEach { encoding ->
                            encoding.maxBitrateBps = 1_500_000
                            encoding.maxFramerate = VIDEO_FPS
                        }
                        if (!sender.setParameters(parameters)) Log.w(TAG, "WebRTC encoder rejected the 720p bitrate hint")
                    }.onFailure { Log.w(TAG, "Could not set adaptive video sender quality: ${it.message}") }
                }
            }

            val sessionDescription = SessionDescription(SessionDescription.Type.OFFER, offerSdp)
            pc.setRemoteDescription(object : SdpObserver {
                override fun onSetSuccess() {
                    Log.i(TAG, "Remote SDP Offer set successfully. Processing queued ICE candidates...")
                    isRemoteDescriptionSet = true

                    if (sessionType == "ACCESSIBILITY_SCREENSHOT") {
                        pc.transceivers
                            .firstOrNull { it.mediaType == MediaStreamTrack.MediaType.MEDIA_TYPE_AUDIO }
                            ?.setDirection(RtpTransceiver.RtpTransceiverDirection.SEND_ONLY)
                        if (accessibilityMicrophoneEnabled) setAccessibilityMicrophoneEnabled(true)
                    }

                    // Drain all queued remote ICE candidates
                    synchronized(queuedRemoteCandidates) {
                        for (candidate in queuedRemoteCandidates) {
                            try {
                                pc.addIceCandidate(candidate)
                            } catch (e: Throwable) {
                                Log.w(TAG, "Error adding queued ICE candidate: ${e.message}")
                            }
                        }
                        queuedRemoteCandidates.clear()
                    }

                    val sdpConstraints = MediaConstraints().apply {
                        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
                        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
                    }

                    pc.createAnswer(object : SdpObserver {
                        override fun onCreateSuccess(desc: SessionDescription?) {
                            if (desc != null) {
                                pc.setLocalDescription(object : SdpObserver {
                                    override fun onSetSuccess() {
                                        Log.i(TAG, "Local SDP Answer set successfully. Ready to transmit answer.")
                                        val answerPayload = SdpPayload(
                                            type = "answer",
                                            sdp = desc.description,
                                            timestamp = System.currentTimeMillis()
                                        )
                                        onAnswerCreated(answerPayload)
                                    }

                                    override fun onSetFailure(error: String?) {
                                        onError("Failed to set local description: $error")
                                    }

                                    override fun onCreateSuccess(p0: SessionDescription?) {}
                                    override fun onCreateFailure(p0: String?) {}
                                }, desc)
                            }
                        }

                        override fun onCreateFailure(error: String?) {
                            onError("Failed to create SDP answer: $error")
                        }

                        override fun onSetSuccess() {}
                        override fun onSetFailure(p0: String?) {}
                    }, sdpConstraints)
                }

                override fun onSetFailure(error: String?) {
                    onError("Failed to set remote description: $error")
                }

                override fun onCreateSuccess(p0: SessionDescription?) {}
                override fun onCreateFailure(p0: String?) {}
            }, sessionDescription)
        } catch (e: Throwable) {
            onError("WebRTC exception processing offer: ${e.message}")
        }
    }

    /**
     * Ingests remote ICE candidates sent by the Parent device.
     */
    fun addRemoteIceCandidate(candidate: IceCandidatePayload) {
        try {
            val iceCandidate = IceCandidate(candidate.sdpMid, candidate.sdpMLineIndex, candidate.sdpCandidate)
            val pc = peerConnection
            if (pc != null && isRemoteDescriptionSet) {
                pc.addIceCandidate(iceCandidate)
            } else {
                synchronized(queuedRemoteCandidates) {
                    queuedRemoteCandidates.add(iceCandidate)
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Failed to add remote ICE candidate: ${e.message}")
        }
    }

    fun switchCamera(useFrontCamera: Boolean) {
        val camera = videoCapturer as? CameraVideoCapturer ?: run {
            Log.w(TAG, "Camera switch requested but no switchable camera capturer is active")
            return
        }
        if (frontCameraActive == useFrontCamera) return
        camera.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
                override fun onCameraSwitchDone(isFrontCamera: Boolean) {
                    frontCameraActive = isFrontCamera
                    Log.i(TAG, "WebRTC Camera switched. Is front: $isFrontCamera")
                }

                override fun onCameraSwitchError(errorDescription: String?) {
                    Log.w(TAG, "WebRTC Camera switch error: $errorDescription")
                }
            })
    }

    fun flipCamera() = switchCamera(!frontCameraActive)

    fun sendControlMessage(message: String): Boolean {
        val channel = remoteControlChannel ?: return false
        if (channel.state() != DataChannel.State.OPEN) return false
        return runCatching {
            channel.send(DataChannel.Buffer(java.nio.ByteBuffer.wrap(message.toByteArray(Charsets.UTF_8)), false))
        }.getOrDefault(false)
    }

    /** Keep screenshot streaming responsive without building an unbounded SCTP send queue. */
    fun canSendControlMessage(maxBufferedBytes: Long = 256 * 1024): Boolean {
        val channel = remoteControlChannel ?: return false
        return channel.state() == DataChannel.State.OPEN && channel.bufferedAmount() < maxBufferedBytes
    }

    fun close() {
        peerConnectionGeneration++
        isRemoteDescriptionSet = false
        synchronized(queuedRemoteCandidates) {
            queuedRemoteCandidates.clear()
        }

        try {
            videoCapturer?.stopCapture()
        } catch (_: Exception) {}
        videoCapturer?.dispose()
        videoCapturer = null

        surfaceTextureHelper?.dispose()
        surfaceTextureHelper = null

        videoTrack?.dispose()
        videoTrack = null

        videoSource?.dispose()
        videoSource = null

        audioTrack?.dispose()
        audioTrack = null

        audioSource?.dispose()
        audioSource = null
        accessibilityMicrophoneEnabled = false

        peerConnection?.close()
        peerConnection?.dispose()
        peerConnection = null
        remoteControlChannel?.close()
        remoteControlChannel = null
    }

    fun release() {
        close()
        peerConnectionFactory?.dispose()
        peerConnectionFactory = null
        eglBase?.release()
        eglBase = null
    }
}
