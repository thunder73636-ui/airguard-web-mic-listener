package com.example.monitoring

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import java.util.Calendar

/** Real, on-device foreground usage. Values are minutes accumulated since local midnight. */
object DeviceUsageStats {
    private fun todayForegroundMillisByPackage(context: Context): Map<String, Long>? {
        if (!hasUsageAccess(context)) return null
        val manager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val stats = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, System.currentTimeMillis())
        if (stats.isNullOrEmpty()) return emptyMap()
        return stats.groupBy { it.packageName }.mapValues { (_, entries) ->
            entries.sumOf { it.totalTimeInForeground }
        }
    }

    fun todayByPackage(context: Context): Map<String, Int>? =
        todayForegroundMillisByPackage(context)?.mapValues { (_, millis) -> (millis / 60_000L).toInt() }

    /** Current-day minutes for every launchable third-party app, including zero-use apps. */
    fun todayUserAppUsageMinutes(context: Context): Map<String, Int>? {
        val usage = todayByPackage(context) ?: return null
        return userAppUsageMinutes(context, usage)
    }

    /** Filters a previously queried usage map so callers can reuse one system query per sync. */
    fun userAppUsageMinutes(context: Context, usage: Map<String, Int>): Map<String, Int> {
        val launchers = launcherPackages(context)
        return launchers.asSequence()
            .filter { isCountedUserApp(it, launchers, context.packageName) }
            .sorted()
            .associateWith { usage[it] ?: 0 }
    }

    fun hasUsageAccess(context: Context): Boolean = try {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
        false
    }

    fun totalUserAppMinutes(context: Context, usage: Map<String, Int>): Int {
        val launchers = launcherPackages(context)
        return totalUserAppMinutesFromMinutes(usage.filter { (pkg, _) -> isCountedUserApp(pkg, launchers, context.packageName) }.values)
    }

    /** Sum raw foreground milliseconds before rounding, avoiding one lost minute per app. */
    fun todayTotalUserAppMinutes(context: Context): Int? {
        val usage = todayForegroundMillisByPackage(context) ?: return null
        val launchers = launcherPackages(context)
        val millis = usage.filter { (pkg, _) -> isCountedUserApp(pkg, launchers, context.packageName) }.values
        return totalMinutesFromMillis(millis)
    }

    internal fun totalUserAppMinutesFromMinutes(minutes: Collection<Int>): Int =
        minutes.sumOf { it.coerceAtLeast(0) }

    internal fun totalMinutesFromMillis(millisByApp: Collection<Long>): Int =
        (millisByApp.sumOf { it.coerceAtLeast(0L) } / 60_000L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()

    private fun launcherPackages(context: Context): Set<String> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return context.packageManager
            .queryIntentActivities(launcherIntent, 0)
            .mapNotNull { it.activityInfo?.packageName }
            .toSet()
    }

    private fun isCountedUserApp(pkg: String, launchers: Set<String>, ownPackage: String) =
        pkg in launchers && pkg != ownPackage && pkg != "com.android.systemui" && pkg != "com.android.settings"
}
