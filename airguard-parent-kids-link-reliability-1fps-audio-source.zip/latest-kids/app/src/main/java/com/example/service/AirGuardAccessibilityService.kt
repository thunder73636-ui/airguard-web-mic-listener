package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.Bitmap
import android.graphics.Typeface
import android.text.InputType
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.data.model.ChildAppRule
import com.example.data.repository.ChildSyncRepository
import com.example.monitoring.DeviceUsageStats
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import java.util.Calendar
import java.io.ByteArrayOutputStream

/**
 * Enforces parent-selected app and time rules on-device. Restrictions are always visible to the
 * child; the overlay explains why an app is unavailable and does not read app screen contents.
 */
class AirGuardAccessibilityService : AccessibilityService() {
    data class ScreenshotCaptureResult(val jpeg: ByteArray?, val errorMessage: String? = null)

    companion object {
        private const val TAG = "AirGuardAccessibility"
        private const val RECHECK_MS = 15_000L
        private const val USAGE_REFRESH_MS = 15_000L
        var isServiceRunning = false
            private set
        @Volatile private var activeService: AirGuardAccessibilityService? = null
        @Volatile var currentForegroundPackage: String = ""
            private set

        private const val MAX_SCREENSHOT_BYTES = 450_000

        fun captureCurrentScreen(onResult: (ScreenshotCaptureResult) -> Unit) {
            val service = activeService
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || service == null) {
                onResult(ScreenshotCaptureResult(null, "Accessibility screenshot service is unavailable."))
                return
            }
            service.takeScreenshot(
                android.view.Display.DEFAULT_DISPLAY,
                service.mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        var source: Bitmap? = null
                        var working: Bitmap? = null
                        var jpeg: ByteArray? = null
                        var failure: String? = null
                        try {
                            source = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, false)
                            val captured = source ?: throw IllegalStateException("Could not read captured display buffer.")
                            val scale = minOf(1f, 960f / maxOf(captured.width, captured.height))
                            working = if (scale < 1f) Bitmap.createScaledBitmap(
                                captured, (captured.width * scale).toInt(), (captured.height * scale).toInt(), true
                            ) else captured

                            var quality = 42
                            var encoded = compressScreenshot(working!!, quality)
                            while (encoded.size > MAX_SCREENSHOT_BYTES && quality > 22) {
                                quality = (quality - 8).coerceAtLeast(22)
                                encoded = compressScreenshot(working!!, quality)
                            }
                            while (encoded.size > MAX_SCREENSHOT_BYTES && maxOf(working!!.width, working!!.height) > 480) {
                                val previous = working!!
                                working = Bitmap.createScaledBitmap(
                                    previous,
                                    (previous.width * 0.8f).toInt().coerceAtLeast(1),
                                    (previous.height * 0.8f).toInt().coerceAtLeast(1),
                                    true
                                )
                                if (previous !== captured) previous.recycle()
                                quality = 30
                                encoded = compressScreenshot(working!!, quality)
                            }
                            if (encoded.size <= MAX_SCREENSHOT_BYTES) jpeg = encoded
                            else failure = "Screenshot frame is too large to transfer after compression."
                        } catch (e: Exception) {
                            failure = "Screenshot capture or compression failed: ${e.message ?: e.javaClass.simpleName}."
                        } finally {
                            if (working !== source) working?.recycle()
                            source?.recycle()
                            runCatching { result.hardwareBuffer.close() }
                        }
                        onResult(ScreenshotCaptureResult(jpeg, failure))
                    }

                    override fun onFailure(errorCode: Int) {
                        Log.w(TAG, "Accessibility screenshot request failed with Android error $errorCode")
                        onResult(ScreenshotCaptureResult(null, "Android screenshot capture failed (error $errorCode)."))
                    }
                }
            )
        }

        private fun compressScreenshot(bitmap: Bitmap, quality: Int): ByteArray {
            val output = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)
            return output.toByteArray()
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var deviceListener: ListenerRegistration? = null
    private var rulesListener: ListenerRegistration? = null
    private var deviceFields: Map<String, Any> = emptyMap()
    private var appRules: List<ChildAppRule> = emptyList()
    private var usageByPackage: Map<String, Int>? = null
    private var totalUsageMinutes: Int? = null
    private var lastUsageRefresh = 0L
    private var lastRulesUsageWrite = 0L
    private var lastEnforceAt = 0L
    private var overlay: FrameLayout? = null
    private var ringtone: Ringtone? = null
    private var lastRingStart = 0L
    private var screenOnReceiverRegistered = false
    private val screenOnReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != Intent.ACTION_SCREEN_ON) return
            val now = System.currentTimeMillis()
            // Paint an already-known Instant Block overlay before doing the usage query.
            if (deviceFields["isLocked"] == true) enforceCurrentApp(force = true)
            refreshAndPublishUsage(now)
            enforceCurrentApp(force = true)

            // The realtime listener may have been paused by Android while the display was off.
            val repository = ChildSyncRepository.getInstance(applicationContext)
            val firestore = repository.getFirestore() ?: return
            val childId = repository.getChildDeviceId()
            scope.launch {
                try {
                    val snapshot = firestore.collection("devices").document(childId).get().await()
                    if (snapshot.exists()) {
                        withContext(Dispatchers.Main.immediate) {
                            deviceFields = snapshot.data ?: deviceFields
                            updatePhoneRing(
                                snapshot.getLong("ringRequestedAt") ?: 0L,
                                snapshot.getLong("ringStopRequestedAt") ?: 0L
                            )
                            enforceCurrentApp(force = true)
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Could not refresh parent lock on screen-on: ${e.message}")
                }
            }
        }
    }
    private val quotaMonitor = object : Runnable {
        override fun run() {
            if (!isServiceRunning) return
            val now = System.currentTimeMillis()
            if (now - lastUsageRefresh >= USAGE_REFRESH_MS) refreshAndPublishUsage(now)
            enforceCurrentApp(force = true)
            mainHandler.postDelayed(this, RECHECK_MS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
        isServiceRunning = true
        attachCloudControls()
        registerScreenOnReceiver()
        refreshAndPublishUsage(System.currentTimeMillis())
        mainHandler.removeCallbacks(quotaMonitor)
        mainHandler.post(quotaMonitor)
        Log.i(TAG, "Accessibility control service connected")
    }

    private fun attachCloudControls() {
        val repository = ChildSyncRepository.getInstance(applicationContext)
        val firestore = repository.getFirestore() ?: return
        val childId = repository.getChildDeviceId()

        deviceListener?.remove()
        deviceListener = firestore.collection("devices").document(childId)
            .addSnapshotListener(com.google.firebase.firestore.MetadataChanges.INCLUDE) { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Could not receive parent device settings: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot == null) return@addSnapshotListener
                if (!snapshot.exists()) {
                    if (!snapshot.metadata.isFromCache) {
                        deviceFields = emptyMap()
                        appRules = emptyList()
                        repository.unpairDevice()
                        showRestriction(null)
                    }
                    return@addSnapshotListener
                }
                if (!snapshot.metadata.isFromCache) repository.clearOfflineUnlockOverride()
                deviceFields = snapshot.data ?: emptyMap()
                updatePhoneRing(
                    ringRequestedAt = snapshot.getLong("ringRequestedAt") ?: 0L,
                    ringStopRequestedAt = snapshot.getLong("ringStopRequestedAt") ?: 0L
                )
                enforceCurrentApp(force = true)
            }

        rulesListener?.remove()
        rulesListener = firestore.collection("app_rules")
            .whereEqualTo("deviceId", childId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Could not receive app rules: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot == null) return@addSnapshotListener
                appRules = snapshot.documents.mapNotNull { doc ->
                    val pkg = doc.getString("packageName") ?: return@mapNotNull null
                    ChildAppRule(
                        id = doc.id,
                        deviceId = childId,
                        packageName = pkg,
                        appName = doc.getString("appName") ?: pkg,
                        category = doc.getString("category") ?: "App",
                        isBlocked = doc.getBoolean("isBlocked") ?: false,
                        dailyLimitMinutes = (doc.getLong("dailyLimitMinutes")?.toInt()) ?: 0,
                        todayUsageMinutes = (doc.getLong("todayUsageMinutes")?.toInt()) ?: 0
                    )
                }
                enforceCurrentApp(force = true)
            }
    }

    private fun registerScreenOnReceiver() {
        if (screenOnReceiverRegistered) return
        val filter = IntentFilter(Intent.ACTION_SCREEN_ON)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(screenOnReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(screenOnReceiver, filter)
            }
            screenOnReceiverRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "Could not register screen-on lock refresh: ${e.message}")
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString() ?: return
            currentForegroundPackage = pkg
        }
        val pkg = event.packageName?.toString()?.takeIf { it.isNotBlank() } ?: currentForegroundPackage
        if (pkg.isBlank()) return

        val now = System.currentTimeMillis()
        if (now - lastUsageRefresh >= USAGE_REFRESH_MS) refreshAndPublishUsage(now)
        enforcePackage(pkg, force = now - lastEnforceAt >= RECHECK_MS)
    }

    private fun refreshAndPublishUsage(now: Long) {
        lastUsageRefresh = now
        usageByPackage = DeviceUsageStats.todayByPackage(applicationContext)
        totalUsageMinutes = DeviceUsageStats.todayTotalUserAppMinutes(applicationContext)
        publishUsage()
    }

    private fun enforceCurrentApp(force: Boolean) {
        val windowPackage = if (force) rootInActiveWindow?.packageName?.toString() else null
        val pkg = windowPackage?.takeIf { it.isNotBlank() }
            ?: currentForegroundPackage.takeIf { it.isNotBlank() }
            ?: rootInActiveWindow?.packageName?.toString()?.takeIf { it.isNotBlank() }
            ?: packageName
        currentForegroundPackage = pkg
        if (pkg.isNotBlank()) enforcePackage(pkg, force)
    }

    private fun enforcePackage(pkg: String, force: Boolean) {
        val repository = ChildSyncRepository.getInstance(applicationContext)
        if (!repository.isDevicePaired() || repository.offlineUnlockActive.value) {
            showRestriction(null)
            return
        }
        val now = System.currentTimeMillis()
        if (!force && now - lastEnforceAt < RECHECK_MS) return
        lastEnforceAt = now

        val label = appLabel(pkg)
        val allowedLabels = (deviceFields["alwaysAllowedApps"] as? String)
            .orEmpty().split(',').map { it.trim() }.filter { it.isNotBlank() }
        val isParentAllowed = allowedLabels.any { it.equals(label, ignoreCase = true) }

        val usage = usageByPackage
        val rule = appRules.firstOrNull { it.packageName == pkg }
        val appUsed = usage?.get(pkg) ?: rule?.todayUsageMinutes ?: 0
        val appLimit = rule?.dailyLimitMinutes ?: 0
        val isAppBlocked = rule?.isBlocked == true || (appLimit > 0 && appUsed >= appLimit)

        val overallUsed = totalUsageMinutes
        val totalLimit = (deviceFields["screenTimeLimitMinutes"] as? Number)?.toInt() ?: 180
        val extensionActive = (deviceFields["extraTimeUntil"] as? Number)?.toLong()?.let { it > now } == true
        val totalLimitReached = overallUsed != null && totalLimit > 0 && overallUsed >= totalLimit && !extensionActive
        val browsers = appRules.filter { it.category.equals("Browser", true) }.map { it.packageName }.toSet()
        val isBrowser = pkg in browsers || looksLikeBrowser(pkg)
        val webUsed = usage?.filterKeys { it in browsers || looksLikeBrowser(it) }?.values?.sum() ?: 0
        val webLimit = (deviceFields["webDailyLimitMinutes"] as? Number)?.toInt() ?: 60
        val webLimitReached = isBrowser && usage != null && webLimit > 0 && webUsed >= webLimit
        val isDevicePaused = deviceFields["isLocked"] == true || isDowntimeActive(deviceFields) || totalLimitReached

        // Instant Block and the daily quota must show the existing lock overlay immediately,
        // even if the foreground app is AirGuard, Settings, or System UI.
        if (deviceFields["isLocked"] == true || totalLimitReached) {
            if (isEssentialDuringDevicePause(pkg)) {
                showRestriction(null)
            } else {
                val message = "This device is paused by your parent. Emergency calling remains available."
                showRestriction(message, "Locked")
            }
            return
        }

        // Only phone/emergency calling and Android Settings bypass a full-device pause.
        // AirGuard itself and System UI must not dismiss the pause overlay.
        if (isEssentialDuringDevicePause(pkg)) {
            showRestriction(null)
            return
        }
        val isLauncher = pkg.contains("launcher", true)
        if (!isDevicePaused && (pkg == packageName || isParentAllowed || isLauncher)) {
            showRestriction(null)
            return
        }

        val reason = when {
            isDevicePaused && isParentAllowed -> null
            isDevicePaused -> "This device is paused by your parent. Emergency calling remains available."
            isAppBlocked -> if (appLimit > 0 && appUsed >= appLimit) "$label reached its daily app limit." else "$label is blocked by your parent."
            webLimitReached -> "The daily browser time limit has been reached."
            else -> null
        }
        showRestriction(reason, "Locked")
    }

    private fun publishUsage() {
        val usage = usageByPackage ?: return
        val childId = ChildSyncRepository.getInstance(applicationContext).getChildDeviceId()
        val firestore = ChildSyncRepository.getInstance(applicationContext).getFirestore() ?: return
        val now = System.currentTimeMillis()
        if (now - lastRulesUsageWrite < 60_000L) return
        lastRulesUsageWrite = now
        scope.launch {
            try {
                val batch = firestore.batch()
                var writes = 0
                appRules.forEach { rule ->
                    val minutes = usage[rule.packageName] ?: 0
                    if (minutes != rule.todayUsageMinutes) {
                        batch.update(firestore.collection("app_rules").document(rule.id), "todayUsageMinutes", minutes)
                        writes++
                    }
                }
                if (writes > 0) batch.commit().await()
                val total = totalUsageMinutes
                if (total != null) firestore.collection("devices").document(childId).update("todayUsageMinutes", total).await()
            } catch (e: Exception) {
                Log.w(TAG, "Usage update deferred: ${e.message}")
            }
        }
    }

    private fun showRestriction(reason: String?, title: String = "Locked") {
        mainHandler.post {
            if (reason == null) {
                overlay?.let { view ->
                    runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(view) }
                }
                overlay = null
                return@post
            }
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val existing = overlay
            if (existing != null) {
                (existing.getChildAt(0) as? TextView)?.text = "$title\n\n$reason\n\nAsk your parent to change this limit."
                return@post
            }

            val root = FrameLayout(this).apply {
                setBackgroundColor(0xF20F172A.toInt())
                isClickable = true
                isFocusable = true
            }
            val message = TextView(this).apply {
                tag = "restriction_message"
                text = "$title\n\n$reason\n\nAsk your parent to change this limit."
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 22f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity = Gravity.CENTER
                setPadding(36, 36, 36, 36)
                setLineSpacing(8f, 1.05f)
            }
            root.addView(message, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            val pinButton = Button(this).apply {
                text = "Parent PIN"
                setOnClickListener { showOfflinePinPrompt() }
            }
            root.addView(pinButton, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
                leftMargin = 36; rightMargin = 36; bottomMargin = 48
            })
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.CENTER }
            try {
                wm.addView(root, params)
                overlay = root
            } catch (e: Exception) {
                Log.w(TAG, "Could not display restriction overlay: ${e.message}")
            }
        }
    }

    private fun showOfflinePinPrompt() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
            hint = "6-digit PIN"
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Parent PIN")
            .setMessage("Unlocks AirGuard restrictions only; it cannot unlock Android's phone lock screen.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Unlock AirGuard") { _, _ ->
                val result = ChildSyncRepository.getInstance(applicationContext)
                    .attemptOfflineParentUnlock(input.text.toString())
                when (result) {
                    ChildSyncRepository.OfflinePinResult.UNLOCKED -> showRestriction(null)
                    ChildSyncRepository.OfflinePinResult.INCORRECT -> android.widget.Toast.makeText(this, "Incorrect PIN", android.widget.Toast.LENGTH_SHORT).show()
                    ChildSyncRepository.OfflinePinResult.NOT_CONFIGURED -> android.widget.Toast.makeText(this, "No Parent PIN is set.", android.widget.Toast.LENGTH_LONG).show()
                    ChildSyncRepository.OfflinePinResult.COOLDOWN -> android.widget.Toast.makeText(this, "Too many attempts. Wait 30 seconds.", android.widget.Toast.LENGTH_LONG).show()
                }
            }
            .create()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        dialog.show()
    }

    private fun updatePhoneRing(ringRequestedAt: Long, ringStopRequestedAt: Long) {
        if (ringRequestedAt <= ringStopRequestedAt || ringRequestedAt == lastRingStart ||
            System.currentTimeMillis() - ringRequestedAt > 60_000L
        ) {
            if (ringStopRequestedAt >= ringRequestedAt) stopPhoneRing()
            return
        }
        lastRingStart = ringRequestedAt
        try {
            stopPhoneRing()
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: return
            ringtone = RingtoneManager.getRingtone(applicationContext, uri)?.apply {
                audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) isLooping = true
                play()
            }
            mainHandler.postDelayed({ stopPhoneRing() }, 60_000L)
        } catch (e: Exception) {
            Log.w(TAG, "Could not start phone locator sound: ${e.message}")
        }
    }

    private fun stopPhoneRing() {
        runCatching { ringtone?.stop() }
        ringtone = null
    }

    private fun isDowntimeActive(fields: Map<String, Any>): Boolean {
        if (fields["downtimeEnabled"] != true) return false
        val now = Calendar.getInstance()
        val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val start = ((fields["downtimeStartHour"] as? Number)?.toInt() ?: 21) * 60 +
            ((fields["downtimeStartMinute"] as? Number)?.toInt() ?: 30)
        val end = ((fields["downtimeEndHour"] as? Number)?.toInt() ?: 7) * 60 +
            ((fields["downtimeEndMinute"] as? Number)?.toInt() ?: 0)
        val days = (fields["downtimeDays"] as? String).orEmpty().split(',').toSet()
        val dayNames = arrayOf("", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        val today = dayNames[now.get(Calendar.DAY_OF_WEEK)]
        val yesterdayIndex = if (now.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) Calendar.SATURDAY else now.get(Calendar.DAY_OF_WEEK) - 1
        val yesterday = dayNames[yesterdayIndex]
        return if (start <= end) {
            currentMinutes in start until end && today in days
        } else {
            (currentMinutes >= start && today in days) || (currentMinutes < end && yesterday in days)
        }
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun looksLikeBrowser(pkg: String): Boolean = listOf(
        "browser", "chrome", "firefox", "edge", "emmx", "opera", "brave", "samsung.internet",
        "sbrowser", "vivaldi", "duckduckgo", "ucbrowser", "miui.browser"
    ).any { pkg.contains(it, ignoreCase = true) }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(quotaMonitor)
        if (screenOnReceiverRegistered) {
            runCatching { unregisterReceiver(screenOnReceiver) }
            screenOnReceiverRegistered = false
        }
        deviceListener?.remove()
        rulesListener?.remove()
        stopPhoneRing()
        showRestriction(null)
        isServiceRunning = false
        if (activeService === this) activeService = null
        super.onDestroy()
    }
}
