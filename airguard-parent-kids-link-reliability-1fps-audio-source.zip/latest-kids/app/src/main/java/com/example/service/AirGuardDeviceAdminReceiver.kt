package com.example.service

import android.app.admin.DeviceAdminReceiver

class AirGuardDeviceAdminReceiver : DeviceAdminReceiver()
