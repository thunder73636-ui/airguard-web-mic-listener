package com.example.service

import android.app.*
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.data.repository.ChildSyncRepository
import com.example.media.ChildMediaSignalingManager
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Foreground Android Service for real-time WebRTC media capture.
 * Listens for signaling requests from Firestore to start streaming camera and microphone data
 * even when the child device is locked or running other apps in the background.
 */
class AirGuardMediaCaptureService : Service() {

    companion object {
        private const val TAG = "AirGuardMediaCapture"
        const val CHANNEL_ID = "airguard_media_capture_channel"
        private const val LINK_CHANNEL_ID = "airguard_link_service_channel"
        const val NOTIFICATION_ID = 2048

        const val ACTION_START_STREAMING = "com.example.action.START_MEDIA_CAPTURE"
        const val ACTION_START_LINK_ONLY = "com.example.action.START_LINK_ONLY"
        const val ACTION_STOP_STREAMING = "com.example.action.STOP_MEDIA_CAPTURE"
        const val ACTION_STOP_CURRENT_SESSION = "com.example.action.STOP_CURRENT_MEDIA_SESSION"
        const val ACTION_START_SCREEN_CAPTURE = "com.example.action.START_SCREEN_CAPTURE"
        const val ACTION_STOP_SCREEN_CAPTURE_MODE = "com.example.action.STOP_SCREEN_CAPTURE_MODE"
        private const val EXTRA_PROJECTION_RESULT_CODE = "projection_result_code"
        private const val EXTRA_PROJECTION_DATA = "projection_result_data"

        var isServiceRunning = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, AirGuardMediaCaptureService::class.java).apply {
                action = ACTION_START_STREAMING
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun startLinkAfterBoot(context: Context) {
            val intent = Intent(context, AirGuardMediaCaptureService::class.java).apply {
                action = ACTION_START_LINK_ONLY
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, AirGuardMediaCaptureService::class.java).apply {
                action = ACTION_STOP_STREAMING
            }
            context.startService(intent)
        }

        fun startScreenCapture(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, AirGuardMediaCaptureService::class.java).apply {
                action = ACTION_START_SCREEN_CAPTURE
                putExtra(EXTRA_PROJECTION_RESULT_CODE, resultCode)
                putExtra(EXTRA_PROJECTION_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stopScreenCaptureMode(context: Context) {
            val intent = Intent(context, AirGuardMediaCaptureService::class.java).apply {
                action = ACTION_STOP_SCREEN_CAPTURE_MODE
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
                else context.startService(intent)
            }.onFailure { Log.w(TAG, "Could not refresh foreground service after screen sharing: ${it.message}") }
        }
    }

    private lateinit var repository: ChildSyncRepository
    private var signalingManager: ChildMediaSignalingManager? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var heartbeatJob: Job? = null
    private var sessionNotificationJob: Job? = null
    private var ringListenerRetryJob: Job? = null
    private var ringListenerRetryAttempt = 0
    private var ringCommandListener: ListenerRegistration? = null
    private var locatorRingtone: Ringtone? = null
    private var lastRingRequestAt = 0L
    private var lastFlashlightRequestAt = 0L
    private var lastScreenLockRequestedAt = 0L
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var lastNetworkRecoverySyncAt = 0L

    override fun onCreate() {
        super.onCreate()
        repository = ChildSyncRepository.getInstance(applicationContext)
        lastScreenLockRequestedAt = getSharedPreferences("airguard_child_prefs", Context.MODE_PRIVATE)
            .getLong("screen_lock_request_at", 0L)
        registerConnectivityCallback()
        signalingManager = repository.mediaSignalingManager
        createNotificationChannel()
        observeActiveSessionNotifications()
        isServiceRunning = true
        Log.i(TAG, "AirGuardMediaCaptureService created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_LINK_ONLY

        if (action == ACTION_STOP_CURRENT_SESSION) {
            signalingManager?.stopSession()
            return START_STICKY
        }

        if (action == ACTION_STOP_STREAMING) {
            Log.i(TAG, "Stopping AirGuardMediaCaptureService")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        if (action == ACTION_STOP_SCREEN_CAPTURE_MODE) {
            val notification = buildForegroundNotification("Linked · waiting for parent requests")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            } else startForeground(NOTIFICATION_ID, notification)
            return START_STICKY
        }

        val isScreenCaptureStart = action == ACTION_START_SCREEN_CAPTURE
        val notification = buildForegroundNotification(
            if (isScreenCaptureStart) "Screen sharing is active · visible in Android's screen-sharing indicator"
            else "Linked · waiting for parent requests"
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            if (isScreenCaptureStart) serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            val allowMedia = action == ACTION_START_STREAMING
            if (allowMedia && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val hasCam = androidx.core.content.ContextCompat.checkSelfPermission(
                    this, android.Manifest.permission.CAMERA
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                    this, android.Manifest.permission.RECORD_AUDIO
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                if (hasCam) serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                if (hasMic) serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            // Keep the paired-device service classified as a connected-device interaction. This
            // avoids treating the persistent link as a long-running dataSync job on Android 15+.
            try {
                startForeground(NOTIFICATION_ID, notification, serviceType)
            } catch (e: Exception) {
                Log.w(TAG, "Foreground start with type $serviceType failed: ${e.message}")
                if (isScreenCaptureStart) {
                    signalingManager?.onScreenCaptureStartFailed(e.message ?: "foreground service permission was unavailable")
                    try {
                        startForeground(NOTIFICATION_ID, buildForegroundNotification("Linked · screen sharing could not start"), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
                    } catch (e2: Exception) {
                        Log.e(TAG, "Could not retain the linked foreground service: ${e2.message}")
                        stopSelf()
                        return START_NOT_STICKY
                    }
                    signalingManager?.startListening()
                    return START_STICKY
                }
                try {
                    startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
                } catch (e2: Exception) {
                    Log.e(TAG, "Foreground start failed, stopping service: ${e2.message}")
                    stopSelf()
                    return START_NOT_STICKY
                }
            }
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (isScreenCaptureStart) {
            val resultCode = intent?.getIntExtra(EXTRA_PROJECTION_RESULT_CODE, 0) ?: 0
            val projectionData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent?.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent?.getParcelableExtra(EXTRA_PROJECTION_DATA) as? Intent
            }
            signalingManager?.onScreenCaptureGranted(resultCode, projectionData)
        }

        // Start listening for Firestore signaling requests
        signalingManager?.startListening()
        listenForRingCommands()
        startHeartbeatLoop()
        Log.i(TAG, "AirGuardMediaCaptureService listening for Firestore remote requests")

        return START_STICKY
    }

    /** Find Ring must keep working even when the optional accessibility service is disabled. */
    private fun listenForRingCommands() {
        ringListenerRetryJob?.cancel()
        ringListenerRetryJob = null
        ringCommandListener?.remove()
        val firestore = repository.getFirestore() ?: return
        val childId = repository.getChildDeviceId()
        ringCommandListener = firestore.collection("devices").document(childId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Could not listen for child commands: ${error.message}")
                    scheduleRingListenerRecovery("Firestore listener error")
                    return@addSnapshotListener
                }
                if (snapshot == null) return@addSnapshotListener
                if (!snapshot.exists()) {
                    if (!snapshot.metadata.isFromCache) repository.unpairDevice()
                    return@addSnapshotListener
                }
                if (!snapshot.metadata.isFromCache) ringListenerRetryAttempt = 0
                handleScreenLockRequest(snapshot)
                val requestedAt = snapshot.getLong("ringRequestedAt") ?: 0L
                val stoppedAt = snapshot.getLong("ringStopRequestedAt") ?: 0L
                // The accessibility service owns sound playback when it is active to prevent two
                // simultaneous ringtone players in the same process.
                if (!AirGuardAccessibilityService.isServiceRunning) {
                    updateLocatorRing(requestedAt, stoppedAt)
                }
                val flashlightRequestedAt = snapshot.getLong("flashlightRequestedAt") ?: 0L
                if (flashlightRequestedAt > lastFlashlightRequestAt) {
                    lastFlashlightRequestAt = flashlightRequestedAt
                    if (System.currentTimeMillis() - flashlightRequestedAt in 0..60_000L) {
                        val enabled = snapshot.getBoolean("flashlightEnabled") ?: false
                        if (enabled) {
                            val applied = applyFlashlightCommand(true)
                            if (!applied) {
                                Log.w(TAG, "Child flashlight ON command could not be applied; check camera permission, flash hardware, or whether another app is using the camera")
                            }
                        } else {
                            // Parent's reconnect nudge deliberately reuses the harmless flash-OFF
                            // command. Refresh presence without creating or restarting a media session.
                            applyFlashlightCommand(false)
                            serviceScope.launch {
                                try {
                                    repository.syncHeartbeatToCloud()
                                } catch (e: Exception) {
                                    Log.w(TAG, "Could not refresh child presence after reconnect nudge: ${e.message}")
                                }
                            }
                        }
                    }
                }
            }
    }

    private fun handleScreenLockRequest(snapshot: com.google.firebase.firestore.DocumentSnapshot) {
        val requestedAt = snapshot.getLong("screenLockRequestedAt") ?: return
        if (requestedAt <= lastScreenLockRequestedAt) return
        lastScreenLockRequestedAt = requestedAt
        getSharedPreferences("airguard_child_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("screen_lock_request_at", requestedAt)
            .apply()

        if (System.currentTimeMillis() - requestedAt !in 0..120_000L) return
        val adminComponent = ComponentName(this, AirGuardDeviceAdminReceiver::class.java)
        val devicePolicyManager = getSystemService(DevicePolicyManager::class.java)
        if (devicePolicyManager?.isAdminActive(adminComponent) != true) {
            Log.w(TAG, "Screen lock command ignored because Device Admin is not enabled")
            return
        }
        runCatching { devicePolicyManager.lockNow() }
            .onFailure { Log.w(TAG, "Could not lock child screen: ${it.message}") }
    }

    private fun applyFlashlightCommand(enabled: Boolean): Boolean {
        if (runCatching { signalingManager?.setFlashlight(enabled) == true }.getOrDefault(false)) return true
        return runCatching {
            val cameraManager = getSystemService(CameraManager::class.java) ?: return false
            val cameraId = cameraManager.cameraIdList
                .firstOrNull { id ->
                    val characteristics = cameraManager.getCameraCharacteristics(id)
                    characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                }
                ?: cameraManager.cameraIdList.firstOrNull { id ->
                    cameraManager.getCameraCharacteristics(id)
                        .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                ?: return false
            cameraManager.setTorchMode(cameraId, enabled)
            true
        }.onFailure { error ->
            Log.w(TAG, "Could not apply child flashlight command: ${error.message}")
        }.getOrDefault(false)
    }

    private fun updateLocatorRing(requestedAt: Long, stoppedAt: Long) {
        if (requestedAt <= stoppedAt || requestedAt == lastRingRequestAt ||
            System.currentTimeMillis() - requestedAt !in 0..60_000L
        ) {
            if (stoppedAt >= requestedAt) stopLocatorRing()
            return
        }
        lastRingRequestAt = requestedAt
        stopLocatorRing()
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: return
            locatorRingtone = RingtoneManager.getRingtone(applicationContext, uri)?.apply {
                audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) isLooping = true
                play()
            }
            mainHandler.postDelayed({ stopLocatorRing() }, 60_000L)
        } catch (e: Exception) {
            Log.w(TAG, "Could not play Find Ring sound: ${e.message}")
        }
    }

    private fun stopLocatorRing() {
        mainHandler.removeCallbacksAndMessages(null)
        runCatching { locatorRingtone?.stop() }
        locatorRingtone = null
    }

    private fun startHeartbeatLoop() {
        if (heartbeatJob?.isActive == true) return
        heartbeatJob = serviceScope.launch {
            while (isActive && repository.isDevicePaired()) {
                val synced = try {
                    withTimeoutOrNull(15_000L) { syncHeartbeatWithShortWakeLock() } == true
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "Heartbeat loop will retry: ${e.message}")
                    false
                }
                try {
                    if (!repository.isDevicePaired()) {
                        stopSelf()
                        break
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Could not confirm child pairing state: ${e.message}")
                }
                // A failed write gets a quick bounded retry; healthy presence writes stay
                // on a 30-second cadence to avoid keeping the device awake unnecessarily.
                delay(if (synced) 30_000L else 10_000L)
            }
        }
    }

    /** Keep brief presence writes reliable during Doze without holding a permanent wake lock. */
    private suspend fun syncHeartbeatWithShortWakeLock(): Boolean {
        val powerManager = getSystemService(android.os.PowerManager::class.java) ?: run {
            return repository.syncHeartbeatToCloud()
        }
        val wakeLock = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "$packageName:presence")
        try {
            wakeLock.acquire(20_000L)
            return repository.syncHeartbeatToCloud()
        } finally {
            if (wakeLock.isHeld) wakeLock.release()
        }
    }

    /** An internet route returning should refresh presence immediately instead of waiting for the next tick. */
    private fun registerConnectivityCallback() {
        val manager = getSystemService(ConnectivityManager::class.java) ?: return
        connectivityManager = manager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                refreshHeartbeatIfInternetAvailable(manager, network)
                scheduleRingListenerRecovery("network restored", immediate = true)
            }

            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                if (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                    refreshHeartbeatIfInternetAvailable(manager, network)
                    scheduleRingListenerRecovery("validated network restored", immediate = true)
                }
            }
        }
        networkCallback = callback
        runCatching { manager.registerDefaultNetworkCallback(callback) }
            .onFailure { Log.w(TAG, "Could not monitor network recovery: ${it.message}") }
    }

    @Synchronized
    private fun scheduleRingListenerRecovery(reason: String, immediate: Boolean = false) {
        if (!::repository.isInitialized || !repository.isDevicePaired()) return
        if (ringListenerRetryJob?.isActive == true) {
            if (!immediate) return
            ringListenerRetryJob?.cancel()
        }
        val attempt = ringListenerRetryAttempt.coerceAtMost(5)
        val waitMs = if (immediate) 300L else (1_000L shl attempt).coerceAtMost(30_000L)
        ringListenerRetryAttempt = (ringListenerRetryAttempt + 1).coerceAtMost(6)
        ringListenerRetryJob = serviceScope.launch {
            delay(waitMs)
            synchronized(this@AirGuardMediaCaptureService) { ringListenerRetryJob = null }
            if (repository.isDevicePaired()) {
                Log.i(TAG, "Restoring child command listener after $reason")
                listenForRingCommands()
            }
        }
    }

    private fun refreshHeartbeatIfInternetAvailable(manager: ConnectivityManager, network: Network) {
        val capabilities = runCatching { manager.getNetworkCapabilities(network) }.getOrNull() ?: return
        if (!capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
            !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        ) return
        val now = android.os.SystemClock.elapsedRealtime()
        synchronized(this) {
            if (now - lastNetworkRecoverySyncAt < 10_000L) return
            lastNetworkRecoverySyncAt = now
        }
        serviceScope.launch {
            runCatching { withTimeoutOrNull(15_000L) { syncHeartbeatWithShortWakeLock() } }
                .onFailure { Log.w(TAG, "Could not refresh child presence after network recovery: ${it.message}") }
        }
    }

    private fun observeActiveSessionNotifications() {
        if (sessionNotificationJob?.isActive == true) return
        sessionNotificationJob = serviceScope.launch {
            signalingManager?.activeSession?.collect { session ->
                val statusText = if (session == null) {
                    "Linked · waiting for parent requests"
                } else {
                    val media = when (session.type.uppercase()) {
                        "CAMERA" -> "Camera"
                        "ONE_WAY_AUDIO" -> "Microphone"
                        "SCREEN_MIRROR" -> "Screen sharing"
                        else -> "Media"
                    }
                    val state = if (session.status.equals("CONNECTED", ignoreCase = true)) "active" else "starting"
                    "Parent $media $state · live access is visible here"
                }
                getSystemService(NotificationManager::class.java)?.notify(
                    NOTIFICATION_ID,
                    buildForegroundNotification(statusText, showStopAction = session != null)
                )
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AirGuard Kids Media Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors Firestore signaling requests for parent camera and microphone streaming."
                setShowBadge(false)
            }
            val linkChannel = NotificationChannel(
                LINK_CHANNEL_ID,
                "AirGuard Kids Background Link",
                NotificationManager.IMPORTANCE_NONE
            ).apply {
                description = "Keeps the paired device link running in the background."
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
            manager?.createNotificationChannel(linkChannel)
        }
    }

    private fun buildForegroundNotification(
        statusText: String,
        showStopAction: Boolean = false
    ): Notification {
        val builder = NotificationCompat.Builder(this, LINK_CHANNEL_ID)
            .setContentTitle("AirGuard Kids Protection")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (showStopAction) {
            val stopIntent = Intent(this, AirGuardMediaCaptureService::class.java).apply {
                action = ACTION_STOP_CURRENT_SESSION
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
            val stopPendingIntent = PendingIntent.getService(this, NOTIFICATION_ID, stopIntent, flags)
            builder.addAction(
                NotificationCompat.Action.Builder(
                    android.R.drawable.ic_media_pause,
                    "Stop live access",
                    stopPendingIntent
                ).build()
            )
        }
        return builder.build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        ringCommandListener?.remove()
        networkCallback?.let { callback -> runCatching { connectivityManager?.unregisterNetworkCallback(callback) } }
        networkCallback = null
        connectivityManager = null
        ringCommandListener = null
        stopLocatorRing()
        serviceScope.cancel()
        signalingManager?.stopSession()
        Log.i(TAG, "AirGuardMediaCaptureService destroyed")
    }
}
