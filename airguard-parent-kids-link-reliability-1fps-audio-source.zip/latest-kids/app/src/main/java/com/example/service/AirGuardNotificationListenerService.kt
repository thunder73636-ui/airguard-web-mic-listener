package com.example.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.data.model.NotificationEntry
import com.example.data.repository.ChildSyncRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AirGuardNotificationListenerService : NotificationListenerService() {

    private lateinit var repository: ChildSyncRepository
    private val scope = CoroutineScope(Dispatchers.IO)

    companion object {
        private const val TAG = "NotificationListener"
        var isListenerActive = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        repository = ChildSyncRepository.getInstance(applicationContext)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        isListenerActive = true
        Log.i(TAG, "Notification access connected; syncing currently active notifications")
        runCatching { activeNotifications?.forEach(::syncNotification) }
            .onFailure { Log.w(TAG, "Could not read active notifications: ${it.message}") }
    }

    override fun onListenerDisconnected() {
        isListenerActive = false
        Log.w(TAG, "Notification access disconnected; requesting system rebind")
        requestRebind(android.content.ComponentName(this, AirGuardNotificationListenerService::class.java))
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn != null) syncNotification(sbn)
    }

    private fun syncNotification(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return // Skip self

        try {
            val extras = sbn.notification.extras
            val title = extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()
                ?.takeIf { it.isNotBlank() }
                ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
                ?.takeIf { it.isNotBlank() }
                ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
                    ?.takeIf { it.isNotBlank() }
                ?: extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString("\n") { it.toString() }.orEmpty()

            if (title.isBlank() && text.isBlank()) return

            val appName = try {
                val pm = packageManager
                val appInfo = pm.getApplicationInfo(pkg, 0)
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                pkg
            }

            val entry = NotificationEntry(
                id = "notif_" + (sbn.key.hashCode().toUInt().toString(16)) + "_" + sbn.postTime,
                deviceId = repository.getChildDeviceId(),
                appName = appName,
                packageName = pkg,
                sender = title.ifBlank { "System" },
                content = text,
                timestamp = System.currentTimeMillis()
            )

            scope.launch {
                repository.syncNotificationLog(entry)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to parse notification: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isListenerActive = false
    }
}
