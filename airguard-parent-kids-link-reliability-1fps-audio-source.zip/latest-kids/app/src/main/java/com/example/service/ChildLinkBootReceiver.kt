package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.repository.ChildSyncRepository

/** Resumes the already-paired, user-visible link after a device reboot. */
class ChildLinkBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED &&
            intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return
        if (!ChildSyncRepository.getInstance(context).isDevicePaired()) return
        try {
            AirGuardMediaCaptureService.startLinkAfterBoot(context)
        } catch (e: Exception) {
            Log.w("AirGuardBoot", "Could not resume paired link after reboot: ${e.message}")
        }
    }
}
