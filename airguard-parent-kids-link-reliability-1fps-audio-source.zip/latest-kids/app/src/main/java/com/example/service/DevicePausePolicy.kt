package com.example.service

/** Emergency calling remains reachable even when a parent pause overlay is active. */
internal fun isEssentialDuringDevicePause(packageName: String): Boolean {
    val pkg = packageName.lowercase()
    return pkg.startsWith("com.android.phone") ||
        pkg.startsWith("com.android.incallui") ||
        pkg.startsWith("com.google.android.dialer") ||
        pkg.contains("emergency")
}
