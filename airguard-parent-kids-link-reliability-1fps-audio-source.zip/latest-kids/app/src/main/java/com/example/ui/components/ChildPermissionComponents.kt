package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

/**
 * Top illustration matching screenshot 2:29 & 12:45:
 * Phone with colorful toggle switches and confetti ribbons with vivid colors.
 */
@Composable
fun PermissionHeaderIllustration(
    modifier: Modifier = Modifier,
    size: Dp = 120.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Background vibrant circular halo
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFDBEAFE), Color(0xFFEFF6FF), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.5f),
                radius = w * 0.48f
            ),
            radius = w * 0.48f,
            center = Offset(w * 0.5f, h * 0.5f)
        )

        // Yellow floating ribbon (top left)
        val ribbonPath = Path().apply {
            moveTo(w * 0.20f, h * 0.30f)
            cubicTo(w * 0.14f, h * 0.36f, w * 0.24f, h * 0.42f, w * 0.18f, h * 0.48f)
        }
        drawPath(ribbonPath, color = KidsAmber, style = Stroke(width = 3.5.dp.toPx()))

        // Confetti dots
        drawCircle(color = KidsGreen, radius = 3.5.dp.toPx(), center = Offset(w * 0.28f, h * 0.20f))
        drawCircle(color = KidsBluePrimary, radius = 4.dp.toPx(), center = Offset(w * 0.74f, h * 0.18f))
        drawCircle(color = KidsRed, radius = 3.dp.toPx(), center = Offset(w * 0.80f, h * 0.65f))

        // Center smartphone screen frame (Deep Navy Blue)
        drawRoundRect(
            color = Color(0xFF1E3A8A),
            topLeft = Offset(w * 0.30f, h * 0.16f),
            size = Size(w * 0.40f, h * 0.68f),
            cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx())
        )

        // Screen bezel / white face
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(w * 0.33f, h * 0.20f),
            size = Size(w * 0.34f, h * 0.60f),
            cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
        )

        // Top toggle switch (Navy Blue)
        drawRoundRect(
            color = Color(0xFF334155),
            topLeft = Offset(w * 0.37f, h * 0.28f),
            size = Size(w * 0.26f, h * 0.13f),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.05f,
            center = Offset(w * 0.56f, h * 0.345f)
        )

        // Bottom toggle switch (Vivid Emerald Green - ON)
        drawRoundRect(
            color = KidsGreen,
            topLeft = Offset(w * 0.37f, h * 0.50f),
            size = Size(w * 0.26f, h * 0.13f),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.05f,
            center = Offset(w * 0.56f, h * 0.565f)
        )
        // Checkmark inside green toggle
        drawCircle(
            color = KidsGreen,
            radius = w * 0.025f,
            center = Offset(w * 0.44f, h * 0.565f)
        )

        // Pointing Hand cartoon on bottom-right toggle
        val handColor = Color(0xFFF87171)
        drawCircle(color = handColor, radius = w * 0.055f, center = Offset(w * 0.66f, h * 0.63f))
        val fingerPath = Path().apply {
            moveTo(w * 0.66f, h * 0.63f)
            lineTo(w * 0.58f, h * 0.58f)
        }
        drawPath(fingerPath, color = handColor, style = Stroke(width = 4.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
    }
}

/**
 * Feature Permission Group Card matching screenshot 2:29 with rich elevated styling:
 * Displays icon, title, description, and permission toggle rows with vibrant visual feedback.
 */
@Composable
fun PermissionFeatureCard(
    icon: ImageVector,
    iconBackgroundColor: Color,
    title: String,
    description: String,
    toggles: List<PermissionToggleItem>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, KidsCardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Surface(
                    shape = CircleShape,
                    color = iconBackgroundColor,
                    shadowElevation = 3.dp,
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = KidsTextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = description,
                        fontSize = 13.sp,
                        color = KidsTextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color(0xFFF1F5F9))
            Spacer(modifier = Modifier.height(6.dp))

            // Individual toggle rows under the feature
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                toggles.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { item.onToggleChange(!item.isGranted) }
                            .padding(vertical = 6.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(if (item.isGranted) KidsGreen else Color(0xFF94A3B8), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item.label,
                                fontSize = 15.sp,
                                color = if (item.isGranted) KidsTextPrimary else Color(0xFF334155),
                                fontWeight = if (item.isGranted) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }

                        Switch(
                            checked = item.isGranted,
                            onCheckedChange = item.onToggleChange,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = KidsBluePrimary,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = Color(0xFFCBD5E1)
                            )
                        )
                    }
                }
            }
        }
    }
}

data class PermissionToggleItem(
    val label: String,
    val isGranted: Boolean,
    val onToggleChange: (Boolean) -> Unit
)

/**
 * Visual Accessibility Guidance Dialog (Matching Screenshot 12:46).
 */
@Composable
fun AccessibilityGuidanceDialog(
    onDismiss: () -> Unit,
    onConfirmGoToSettings: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            border = BorderStroke(1.5.dp, KidsBluePrimary),
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Enable Accessibility Service",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = KidsTextPrimary
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Step 1
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Surface(
                        shape = CircleShape,
                        color = KidsBluePrimary,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("1", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Locate AirGuard Kids under the \"Downloaded apps\" section",
                        fontSize = 14.sp,
                        color = KidsTextPrimary,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 20.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = KidsBackground,
                    border = BorderStroke(1.5.dp, KidsBlueContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Downloaded services", fontSize = 11.sp, color = KidsTextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, KidsAmber),
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Security, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("AirGuard Kids", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = KidsTextPrimary)
                            }
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Step 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Surface(
                        shape = CircleShape,
                        color = KidsBluePrimary,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("2", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Turn on the toggle to enable screen time limits",
                        fontSize = 14.sp,
                        color = KidsTextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = KidsBackground,
                    border = BorderStroke(1.5.dp, KidsBlueContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("AirGuard Kids", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = KidsTextPrimary)

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = KidsBluePrimary,
                            modifier = Modifier.size(width = 46.dp, height = 26.dp)
                        ) {
                            Box(contentAlignment = Alignment.CenterEnd) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color.White,
                                    modifier = Modifier.padding(2.dp).size(22.dp)
                                ) {}
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onConfirmGoToSettings,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("OK • Open Accessibility Settings", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

/**
 * Background Battery Optimization Dialog (Matching Screenshot 12:48).
 */
@Composable
fun BackgroundBatteryOptimizationDialog(
    onDeny: () -> Unit,
    onAllow: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDeny,
        title = {
            Text(
                "Let app always run in background?",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = KidsTextPrimary
            )
        },
        text = {
            Text(
                "Allowing AirGuard Kids to always run in the background ensures uninterrupted parental monitoring, live GPS tracking, and safety alerts.",
                fontSize = 14.sp,
                color = KidsTextSecondary,
                lineHeight = 20.sp
            )
        },
        confirmButton = {
            Button(
                onClick = onAllow,
                colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Allow", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDeny) {
                Text("Deny", color = KidsTextSecondary, fontSize = 14.sp)
            }
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(20.dp)
    )
}

/**
 * Customer Support floating button & speech bubble matching screenshot 2:29.
 */
@Composable
fun SupportAgentWidget(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.Start,
        modifier = modifier.clickable { onClick() }
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = KidsBluePrimary,
            shadowElevation = 4.dp
        ) {
            Text(
                "Need more help?",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Surface(
            shape = CircleShape,
            color = Color.White,
            border = BorderStroke(2.dp, KidsBluePrimary),
            shadowElevation = 5.dp,
            modifier = Modifier.size(46.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Default.SupportAgent,
                    contentDescription = "Support",
                    tint = KidsBluePrimary,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}

/**
 * Per-session approval dialog for Camera and Microphone WebRTC streaming.
 */
@Composable
fun WebRtcHardwarePermissionDialog(
    prompt: com.example.media.WebRtcPermissionPrompt,
    onGrant: () -> Unit,
    onDeny: () -> Unit
) {
    val isScreenShare = prompt.session.type == "SCREEN_MIRROR"
    val isCameraRequired = !isScreenShare && (prompt.missingPermissions.contains(android.Manifest.permission.CAMERA) ||
            prompt.session.type == "CAMERA" || prompt.session.type == "SCREEN_MIRROR"
            )
    val isMicRequired = prompt.missingPermissions.contains(android.Manifest.permission.RECORD_AUDIO) ||
            prompt.session.type == "ONE_WAY_AUDIO" || prompt.session.type == "CAMERA" || prompt.session.type == "ACCESSIBILITY_AUDIO"

    val sessionTitle = when (prompt.session.type) {
        "ONE_WAY_AUDIO" -> "One-Way Audio Stream"
        "ACCESSIBILITY_SCREENSHOT" -> "Accessibility View with Microphone Audio"
        "SCREEN_MIRROR" -> "Remote Screen Mirror"
        else -> "Live Camera Viewfinder"
    }

    Dialog(onDismissRequest = onDeny) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = Color.White,
            border = BorderStroke(1.5.dp, KidsBluePrimary),
            shadowElevation = 10.dp,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header badge icon
                Surface(
                    shape = CircleShape,
                    color = KidsBlueContainer,
                    modifier = Modifier.size(68.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            if (isCameraRequired) Icons.Default.Videocam else Icons.Default.Mic,
                            contentDescription = null,
                            tint = KidsBluePrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Live Media Request",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = KidsTextPrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (isScreenShare) {
                        "Your parent is requesting to view this device's screen. If you allow, Android will show a second system dialog before sharing starts. You can decline either request."
                    } else {
                        "Your parent is requesting a $sessionTitle. Your camera or microphone will stream only if you allow this session. You can decline this request."
                    },
                    fontSize = 13.sp,
                    color = KidsTextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Explanatory items
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = KidsBackground,
                    border = BorderStroke(1.dp, KidsCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (isScreenShare) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = CircleShape, color = KidsBluePrimary.copy(alpha = 0.15f), modifier = Modifier.size(32.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.ScreenShare, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(18.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Entire screen", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = KidsTextPrimary)
                                    Text("Android will show its screen-sharing indicator while active", fontSize = 11.sp, color = KidsTextSecondary)
                                }
                            }
                        }

                        if (isCameraRequired) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = KidsBluePrimary.copy(alpha = 0.15f),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(18.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                    Text("Camera", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = KidsTextPrimary)
                    Text("Live video is shared for this session", fontSize = 11.sp, color = KidsTextSecondary)
                                }
                            }
                        }

                        if (isMicRequired) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = KidsGreen.copy(alpha = 0.15f),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Mic, contentDescription = null, tint = KidsGreen, modifier = Modifier.size(18.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                    Text("Microphone", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = KidsTextPrimary)
                    Text("Live audio is shared for this session", fontSize = 11.sp, color = KidsTextSecondary)
                                }
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = KidsAmber.copy(alpha = 0.15f),
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = KidsAmber, modifier = Modifier.size(18.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                    Text("Encrypted WebRTC session", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = KidsTextPrimary)
                            Text(if (isScreenShare) "The screen stream ends when you stop sharing or the session closes" else "The stream ends when this session is closed", fontSize = 11.sp, color = KidsTextSecondary)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                Button(
                    onClick = onGrant,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Allow This Session", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(
                    onClick = onDeny,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Decline Request", color = KidsTextSecondary, fontSize = 14.sp)
                }
            }
        }
    }
}
