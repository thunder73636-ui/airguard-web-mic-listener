package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.ChildDeviceInfo
import com.example.data.repository.ChildSyncRepository
import com.example.ui.components.hoverLift
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChildDashboardScreen(
    repository: ChildSyncRepository,
    onNavigateToPermissions: () -> Unit,
    onUnpair: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isRefreshing by remember { mutableStateOf(false) }
    var showSosConfirmationDialog by remember { mutableStateOf(false) }
    var showUnpairDialog by remember { mutableStateOf(false) }
    var isSosSending by remember { mutableStateOf(false) }
    var showOfflinePinDialog by remember { mutableStateOf(false) }
    var offlinePin by remember { mutableStateOf("") }
    var offlinePinMessage by remember { mutableStateOf<String?>(null) }

    var permissions by remember { mutableStateOf(repository.checkPermissionState()) }
    var hasAllFilesAccess by remember {
        mutableStateOf(Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager())
    }
    var backgroundServiceRunning by remember {
        mutableStateOf(com.example.service.AirGuardMediaCaptureService.isServiceRunning)
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasAllFilesAccess = Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()
                backgroundServiceRunning = com.example.service.AirGuardMediaCaptureService.isServiceRunning
                permissions = repository.checkPermissionState()
                coroutineScope.launch {
                    repository.syncTelemetryToCloud(repository.checkPermissionState())
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val parentSettings by repository.observeParentCommands().collectAsState(initial = null)
    val offlineUnlockActive by repository.offlineUnlockActive.collectAsState()
    val activeMediaSession by repository.mediaSignalingManager.activeSession.collectAsState()
    val pendingPermissionPrompt by repository.mediaSignalingManager.pendingPermissionPrompt.collectAsState()
    val heartbeatAge = System.currentTimeMillis() - (parentSettings?.lastSeenTimestamp ?: 0L)
    val cloudConnected = parentSettings?.isOnline == true && heartbeatAge in 0..120_000L

    fun refreshPermissions() {
        permissions = repository.checkPermissionState()
        backgroundServiceRunning = com.example.service.AirGuardMediaCaptureService.isServiceRunning
    }

    val hardwarePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        refreshPermissions()
        coroutineScope.launch {
            repository.syncTelemetryToCloud(permissions)
        }
        com.example.service.AirGuardMediaCaptureService.start(context)

        val prompt = pendingPermissionPrompt
        if (prompt != null) {
            val hasRequired = prompt.missingPermissions.all { perm ->
                results[perm] == true || androidx.core.content.ContextCompat.checkSelfPermission(
                    context, perm
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            }
            if (hasRequired) {
                repository.mediaSignalingManager.onPermissionsGranted(prompt.session)
                Toast.makeText(context, "Hardware permissions granted! Live WebRTC stream connected.", Toast.LENGTH_SHORT).show()
            } else {
                repository.mediaSignalingManager.onPermissionsDenied(prompt.session)
                Toast.makeText(context, "Hardware permissions denied for stream.", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Hardware permissions updated for WebRTC streaming", Toast.LENGTH_SHORT).show()
        }
    }

    val deviceName = repository.getDeviceName()
    val battery = repository.getBatteryPercentage()

    // The foreground service maintains the lightweight heartbeat; this screen syncs richer
    // telemetry at a slower interval while the child app is visible.
    LaunchedEffect(Unit) {
        com.example.service.AirGuardMediaCaptureService.start(context)
        delay(500L)
        while (true) {
            refreshPermissions()
            repository.syncTelemetryToCloud(permissions)
            delay(120_000L)
        }
    }

    // Full-Screen Lockout Overlay if Parent activates Instant Block or Downtime
    val isLockedByParent = parentSettings?.isLocked == true && !offlineUnlockActive
    if (isLockedByParent) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = CircleShape,
                    color = KidsRed.copy(alpha = 0.2f),
                    modifier = Modifier.size(110.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = "Locked",
                            tint = KidsRed,
                            modifier = Modifier.size(58.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(26.dp))

                Text(
                    text = "Device Paused by Parent",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Your parent has paused device access via AirGuard Instant Block or Downtime schedule.",
                    fontSize = 15.sp,
                    color = Color(0xFFCBD5E1),
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(36.dp))

                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:911"))
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KidsRed),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp).hoverLift()
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Emergency Calls Only", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(modifier = Modifier.height(10.dp))
                TextButton(onClick = { showOfflinePinDialog = true }) {
                    Text("Parent PIN", color = Color.White)
                }
            }
        }
        if (showOfflinePinDialog) {
            AlertDialog(
                onDismissRequest = { showOfflinePinDialog = false },
                title = { Text("Parent PIN") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("This PIN dismisses AirGuard restrictions only. It cannot unlock the Android phone lock screen.")
                        OutlinedTextField(
                            value = offlinePin,
                            onValueChange = { offlinePin = it.filter(Char::isDigit).take(6) },
                            label = { Text("6-digit PIN") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                        )
                        offlinePinMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                },
                confirmButton = {
                    TextButton(enabled = offlinePin.length == 6, onClick = {
                        coroutineScope.launch {
                            val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                repository.attemptOfflineParentUnlock(offlinePin)
                            }
                            when (result) {
                                ChildSyncRepository.OfflinePinResult.UNLOCKED -> {
                                    showOfflinePinDialog = false
                                    offlinePin = ""
                                    offlinePinMessage = null
                                }
                                ChildSyncRepository.OfflinePinResult.INCORRECT -> offlinePinMessage = "Incorrect PIN."
                                ChildSyncRepository.OfflinePinResult.NOT_CONFIGURED -> offlinePinMessage = "No PIN is set. Set it in Parent app first."
                                ChildSyncRepository.OfflinePinResult.COOLDOWN -> offlinePinMessage = "Too many attempts. Wait 30 seconds and try again."
                            }
                        }
                    }) { Text("Unlock AirGuard") }
                },
                dismissButton = { TextButton(onClick = { showOfflinePinDialog = false }) { Text("Cancel") } }
            )
        }
        return
    }

    if (showSosConfirmationDialog) {
        AlertDialog(
            onDismissRequest = { showSosConfirmationDialog = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = KidsRed, modifier = Modifier.size(40.dp)) },
            title = { Text("Send Emergency SOS Alert?", fontWeight = FontWeight.Bold, color = KidsTextPrimary) },
            text = {
                Text(
                    "This will immediately transmit an emergency notification alert and your real-time GPS coordinates to your parent's phone.",
                    color = KidsTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSosConfirmationDialog = false
                        isSosSending = true
                        coroutineScope.launch {
                            repository.sendEmergencySos()
                            isSosSending = false
                            Toast.makeText(context, "Emergency SOS alert transmitted to parent device!", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KidsRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Send SOS Now", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSosConfirmationDialog = false }) { Text("Cancel") }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }

    if (showUnpairDialog) {
        AlertDialog(
            onDismissRequest = { showUnpairDialog = false },
            title = { Text("Unpair Companion Device?", fontWeight = FontWeight.Bold, color = KidsTextPrimary) },
            text = {
                Text("This will disconnect this child phone from the parent AirGuard controller.", color = KidsTextSecondary)
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnpairDialog = false
                        repository.unpairDevice()
                        com.example.service.AirGuardMediaCaptureService.stop(context)
                        onUnpair()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KidsRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Unpair")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnpairDialog = false }) { Text("Cancel") }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }


    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = if (cloudConnected) KidsGreenContainer else Color(0xFFFEF3C7),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = if (cloudConnected) KidsGreen else KidsAmber, modifier = Modifier.size(20.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("AirGuard Kids", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color.White)
                            Text(
                                when {
                                    cloudConnected -> "Connected with parent"
                                    repository.isDevicePaired() -> "Linked · reconnecting"
                                    else -> "Waiting to link"
                                },
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(modifier = Modifier.hoverLift(), onClick = {
                        coroutineScope.launch {
                            isRefreshing = true
                            repository.syncTelemetryToCloud(permissions)
                            delay(600)
                            isRefreshing = false
                            Toast.makeText(context, "Sync requested. Check the cloud status above.", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        if (isRefreshing) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Sync, contentDescription = "Sync Now", tint = Color.White)
                        }
                    }
                    IconButton(modifier = Modifier.hoverLift(), onClick = { showUnpairDialog = true }) {
                        Icon(Icons.Outlined.LinkOff, contentDescription = "Unpair", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KidsBlueDark)
            )
        },
        containerColor = KidsBackground,
        contentWindowInsets = WindowInsets.statusBars
    ) { padding ->
      BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(padding)) {
        val expanded = maxWidth >= 840.dp
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .wrapContentWidth(Alignment.CenterHorizontally)
                .widthIn(max = if (expanded) 840.dp else 640.dp)
                .navigationBarsPadding()
                .padding(horizontal = if (expanded) 24.dp else 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hardware Permission Alert Banner (if Camera or Microphone not yet granted)
            if (!permissions.hasCamera || !permissions.hasMicrophone) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().animateContentSize(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                        border = BorderStroke(1.5.dp, KidsRed.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = KidsRed.copy(alpha = 0.15f),
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.VideocamOff, contentDescription = null, tint = KidsRed, modifier = Modifier.size(20.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("WebRTC Hardware Access Required", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = KidsTextPrimary)
                                Text("Camera & Mic permissions needed for parent live stream", fontSize = 11.sp, color = KidsTextSecondary)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Button(
                                onClick = {
                                    val needed = mutableListOf<String>()
                                    if (!permissions.hasCamera) needed.add(android.Manifest.permission.CAMERA)
                                    if (!permissions.hasMicrophone) needed.add(android.Manifest.permission.RECORD_AUDIO)
                                    hardwarePermissionsLauncher.launch(needed.toTypedArray())
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Grant", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, KidsCardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Manage all files access", fontWeight = FontWeight.Bold, color = KidsTextPrimary)
                                Text(
                                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) "Not needed on this Android version" else if (hasAllFilesAccess) "Enabled in Android settings" else "Not enabled",
                                    fontSize = 12.sp,
                                    color = if (hasAllFilesAccess) KidsGreen else KidsTextSecondary
                                )
                            }
                            Button(
                                enabled = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R,
                                onClick = {
                                    val appSettings = Intent(
                                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    try {
                                        context.startActivity(appSettings)
                                    } catch (_: Exception) {
                                        context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(if (hasAllFilesAccess) "Settings" else "Allow access")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Warning: This gives AirGuard Kids broad access to files stored on this phone. It does not add file-access controls to AirGuard Parent. Android will ask you to enable it in Settings; you can turn it off there at any time.",
                            fontSize = 11.sp,
                            color = KidsTextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            // Live Stream HUD Indicator (Shows active hardware camera/mic data transmission)
            if (activeMediaSession != null) {
                val session = activeMediaSession!!
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (session.type == "CAMERA") KidsBlueContainer else KidsGreenContainer
                        ),
                        border = BorderStroke(1.5.dp, if (session.type == "CAMERA") KidsBluePrimary else KidsGreen)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (session.type == "CAMERA") KidsBluePrimary else KidsGreen,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            if (session.type == "CAMERA") Icons.Default.Videocam else Icons.Default.Mic,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        if (session.type == "CAMERA") "LIVE: Camera Stream Active" else "LIVE: One-Way Audio Streaming",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = KidsTextPrimary
                                    )
                                    Text(
                                        "Parent device is currently receiving live hardware media",
                                        fontSize = 11.sp,
                                        color = KidsTextSecondary
                                    )
                                }
                            }
                            if (session.type == "CAMERA") {
                                IconButton(onClick = { repository.mediaSignalingManager.flipCamera() }) {
                                    Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Flip Lens", tint = KidsBluePrimary)
                                }
                            }
                        }
                    }
                }
            }

            // 1. Connection Status Banner Card (Rich Royal Gradient)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.5.dp, KidsCardBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(KidsBlueDark, KidsBluePrimary, KidsBlueVibrant)
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color.White.copy(alpha = 0.2f),
                                        modifier = Modifier.size(46.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(deviceName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                        Text("Linked to Parent Device", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (cloudConnected) KidsGreen else KidsAmber
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    ) {
                                        Box(modifier = Modifier.size(6.dp).background(Color.White, CircleShape))
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(
                                            if (cloudConnected) "ONLINE" else "OFFLINE",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = Color.White.copy(alpha = 0.25f))
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text("Battery $battery%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.GpsFixed, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(5.dp))
                                    val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
                                    Text("Synced: $time", color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // 2. Live feature and permission status. Only report what this device can verify.
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.5.dp, KidsCardBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Data Transfer to Parent Device",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = KidsTextPrimary
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (cloudConnected) KidsGreenContainer else Color(0xFFFEF3C7)
                            ) {
                                Text(
                                    if (cloudConnected) "Cloud connected" else "Waiting for sync",
                                    color = if (cloudConnected) KidsGreen else KidsAmber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        FeatureTransmissionRow(
                            icon = Icons.Default.Screenshot,
                            iconColor = KidsIndigo,
                            feature = "Accessibility controls & screenshots",
                            status = if (permissions.hasAccessibility) {
                                "Enabled; screenshots adapt to this phone's stable capture and network speed"
                            } else {
                                "Off; enable AirGuard Accessibility in Android Settings to use app rules and screenshots"
                            },
                            synced = permissions.hasAccessibility
                        )
                        if (!permissions.hasAccessibility) {
                            TextButton(onClick = onNavigateToPermissions) {
                                Text("Open permission setup")
                            }
                        }
                        FeatureTransmissionRow(
                            icon = Icons.Default.BatteryChargingFull,
                            iconColor = KidsAmber,
                            feature = "Background link service",
                            status = when {
                                !backgroundServiceRunning -> "Not active; reopen setup to restart the paired background link"
                                permissions.isIgnoringBatteryOptimizations -> "Foreground link active; battery optimization exemption is enabled"
                                else -> "Foreground link active; battery optimization may pause it on this phone"
                            },
                            synced = backgroundServiceRunning && permissions.isIgnoringBatteryOptimizations
                        )
                        if (!backgroundServiceRunning || !permissions.isIgnoringBatteryOptimizations) {
                            TextButton(onClick = onNavigateToPermissions) {
                                Text("Improve background reliability")
                            }
                        }
                        FeatureTransmissionRow(
                            icon = Icons.Default.CameraAlt,
                            iconColor = KidsBluePrimary,
                            feature = "Remote Camera Live Stream",
                            status = if (permissions.hasCamera) "Available on parent request; Android camera indicator is shown while active" else "Camera permission needed",
                            synced = permissions.hasCamera
                        )
                        FeatureTransmissionRow(
                            icon = Icons.Default.Mic,
                            iconColor = KidsGreen,
                            feature = "One-Way Audio Stream",
                            status = if (permissions.hasMicrophone) "Available on parent request; Android microphone indicator is shown while active" else "Microphone permission needed",
                            synced = permissions.hasMicrophone
                        )
                        FeatureTransmissionRow(
                            icon = Icons.Default.ScreenShare,
                            iconColor = KidsIndigo,
                            feature = "Screen Mirroring Stream",
                            status = "Not available in this build: screen capture consent is not implemented",
                            synced = false
                        )
                        FeatureTransmissionRow(
                            icon = Icons.Default.Place,
                            iconColor = KidsAmber,
                            feature = "GPS Location Breadcrumbs",
                            status = if (permissions.hasLocation) "Location sync available when a fresh GPS fix is present" else "Location permission needed",
                            synced = permissions.hasLocation
                        )
                        FeatureTransmissionRow(
                            icon = Icons.Default.Chat,
                            iconColor = KidsPurple,
                            feature = "Notifications & Calls",
                            status = when {
                                !permissions.hasNotificationListener && !permissions.hasCallLog -> "Notification and call-log access are off"
                                else -> "Notification previews and call metadata sync only with their separate permissions; SMS bodies are not collected"
                            },
                            synced = permissions.hasNotificationListener || permissions.hasCallLog
                        )
                    }
                }
            }

            // 3. Parental Screen Time Rules Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.5.dp, KidsCardBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Parental Screen Time Rules",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = KidsTextPrimary
                            )
                            TextButton(onClick = onNavigateToPermissions) {
                                Text("Permissions >", fontSize = 12.sp, color = KidsBluePrimary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val limitMins = (parentSettings?.screenTimeLimitMinutes ?: 180).coerceAtLeast(0)
                        val usedMins = parentSettings?.todayUsageMinutes ?: 0
                        val remainingMins = (limitMins - usedMins).coerceAtLeast(0)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Daily Quota:", color = KidsTextSecondary, fontSize = 13.sp)
                            Text(if (limitMins > 0) "${limitMins / 60}h ${limitMins % 60}m limit" else "No daily limit", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = KidsBluePrimary)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { if (limitMins > 0) (usedMins.toFloat() / limitMins.toFloat()).coerceIn(0f, 1f) else 0f },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = KidsBluePrimary,
                            trackColor = Color(0xFFE2E8F0)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            if (limitMins <= 0) "Daily screen-time limit is off" else if (remainingMins > 0) "$remainingMins minutes remaining today" else "Daily screen-time limit reached",
                            fontSize = 12.sp,
                            color = if (limitMins <= 0 || remainingMins > 0) KidsGreen else KidsRed,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (limitMins > 0 && remainingMins == 0) {
                            val requestPending = (parentSettings?.extraTimeRequestAt ?: 0L) > (parentSettings?.extraTimeRequestHandledAt ?: 0L)
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    coroutineScope.launch {
                                        try {
                                            repository.requestExtraTime()
                                            Toast.makeText(context, "Request sent to your parent", Toast.LENGTH_SHORT).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, e.message ?: "Could not send request", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                enabled = !requestPending,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (requestPending) "Waiting for parent approval…" else "Ask parent for 15 more minutes")
                            }
                        }
                    }
                }
            }

            // 5. Emergency SOS Button
            item {
                Button(
                    onClick = { showSosConfirmationDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = KidsRed),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Sos, contentDescription = null, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Emergency SOS • Alert Parent", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
      }
    }
}

@Composable
private fun FeatureTransmissionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    feature: String,
    status: String,
    synced: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = CircleShape,
            color = iconColor.copy(alpha = 0.15f),
            modifier = Modifier.size(34.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(feature, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = KidsTextPrimary)
            Text(status, fontSize = 11.sp, color = KidsTextSecondary)
        }
        Icon(
            if (synced) Icons.Default.CloudDone else Icons.Default.Info,
            contentDescription = if (synced) "Available" else "Unavailable",
            tint = if (synced) KidsGreen else KidsAmber,
            modifier = Modifier.size(18.dp)
        )
    }
}
