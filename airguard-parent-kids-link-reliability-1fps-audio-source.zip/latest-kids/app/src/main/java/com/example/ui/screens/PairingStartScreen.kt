package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.ChildSyncRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PairingStartScreen(
    repository: ChildSyncRepository,
    onPairingSuccess: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    var codeDigit1 by remember { mutableStateOf("") }
    var codeDigit2 by remember { mutableStateOf("") }
    var codeDigit3 by remember { mutableStateOf("") }
    var deviceNickname by remember { mutableStateOf(repository.getDeviceName()) }

    var isPairingLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showQrDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }

    val focusRequester1 = remember { FocusRequester() }
    val focusRequester2 = remember { FocusRequester() }
    val focusRequester3 = remember { FocusRequester() }

    val fullCode = (codeDigit1 + codeDigit2 + codeDigit3).filter { it.isDigit() }
    val isCodeComplete = fullCode.length == 9

    fun submitPairing(code: String) {
        if (code.length != 9) {
            errorMessage = "Please enter all 9 digits of the pairing code."
            return
        }

        focusManager.clearFocus()

        isPairingLoading = true
        errorMessage = null

        coroutineScope.launch {
            repository.setDeviceName(deviceNickname)
            val result = repository.pairWithCode(code)
            isPairingLoading = false

            result.onSuccess { session ->
                com.example.service.AirGuardMediaCaptureService.start(context)
                Toast.makeText(
                    context,
                    "Code verified! Please grant safety permissions.",
                    Toast.LENGTH_SHORT
                ).show()

                onPairingSuccess()
            }.onFailure { err ->
                errorMessage = err.localizedMessage ?: "Invalid code. Please check code on parent AirGuard app."
            }
        }
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("Where to find the 9-digit code?", fontWeight = FontWeight.Bold, color = KidsTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1. Open the AirGuard Parent app on the parent phone.", color = KidsTextSecondary)
                    Text("2. Tap \"+\" or \"Bind New Device\" on the main dashboard.", color = KidsTextSecondary)
                    Text("3. Enter the 9-digit binding code displayed on the parent's screen.", color = KidsTextSecondary)
                }
            },
            confirmButton = {
                Button(
                    onClick = { showHelpDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary)
                ) {
                    Text("Got It")
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }

    if (showQrDialog) {
        var scannedUrlInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showQrDialog = false },
            title = { Text("Scan Parent QR Code", fontWeight = FontWeight.Bold, color = KidsTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Enter the 9-digit code from the parent's phone or paste the full QR link:",
                        fontSize = 13.sp,
                        color = KidsTextSecondary
                    )

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = KidsBlueContainer,
                        border = BorderStroke(1.5.dp, KidsBluePrimary.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().height(130.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(46.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Paste the QR link or enter the code below", fontSize = 12.sp, color = KidsBluePrimary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = scannedUrlInput,
                        onValueChange = { scannedUrlInput = it },
                        label = { Text("QR Link / Code") },
                        placeholder = { Text("https://apps.airdroid.com/kids?code=492817305") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        keyboardController?.hide()
                        focusManager.clearFocus()
                        if (scannedUrlInput.isNotBlank()) {
                            showQrDialog = false
                            coroutineScope.launch {
                                isPairingLoading = true
                                val res = repository.pairWithQrPayload(scannedUrlInput)
                                isPairingLoading = false
                                res.onSuccess {
                                    com.example.service.AirGuardMediaCaptureService.start(context)
                                    Toast.makeText(context, "QR verified! Setting up permissions...", Toast.LENGTH_SHORT).show()
                                    onPairingSuccess()
                                }.onFailure {
                                    errorMessage = "Invalid QR code: ${it.localizedMessage}"
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary)
                ) {
                    Text("Verify & Connect")
                }
            },
            dismissButton = {
                TextButton(onClick = { showQrDialog = false }) { Text("Cancel") }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }

    Scaffold(
        containerColor = KidsBackground,
        contentWindowInsets = WindowInsets.statusBars
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(scrollState)
        ) {
            // Rich Top Gradient Banner (Bold & High Contrast)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(KidsBlueDark, KidsBluePrimary, KidsBlueVibrant)
                        )
                    )
                    .padding(horizontal = 24.dp, vertical = 28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = CircleShape,
                        color = Color.White,
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(76.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "AirGuard Kids Emblem",
                                tint = KidsBluePrimary,
                                modifier = Modifier.size(42.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "AirGuard Kids",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Child Companion & Monitoring Service",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Main Content Area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Step 1: Code Card with Auto-Push Focus
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.5.dp, KidsCardBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Enter 9-Digit Binding Code",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = KidsTextPrimary
                                )
                                Text(
                                    text = "Shown on parent AirGuard app",
                                    fontSize = 12.sp,
                                    color = KidsTextSecondary
                                )
                            }
                            IconButton(onClick = { showHelpDialog = true }) {
                                Icon(Icons.Outlined.HelpOutline, contentDescription = "Help", tint = KidsBluePrimary)
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // 3 Segmented Input boxes with automatic focus jumping & paste distribution
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Box 1
                            OutlinedTextField(
                                value = codeDigit1,
                                onValueChange = { input ->
                                    val digits = input.filter { it.isDigit() }
                                    errorMessage = null
                                    if (digits.length >= 9) {
                                        // Pasted full 9 digits into Box 1
                                        codeDigit1 = digits.substring(0, 3)
                                        codeDigit2 = digits.substring(3, 6)
                                        codeDigit3 = digits.substring(6, 9)
                                        submitPairing(digits.substring(0, 9))
                                    } else if (digits.length > 3) {
                                        codeDigit1 = digits.substring(0, 3)
                                        val remaining = digits.substring(3)
                                        if (remaining.length <= 3) {
                                            codeDigit2 = remaining
                                            if (remaining.length == 3) {
                                                focusRequester3.requestFocus()
                                            } else {
                                                focusRequester2.requestFocus()
                                            }
                                        } else {
                                            codeDigit2 = remaining.substring(0, 3)
                                            val rest = remaining.substring(3)
                                            codeDigit3 = rest.take(3)
                                            if (codeDigit3.length == 3) {
                                                submitPairing(codeDigit1 + codeDigit2 + codeDigit3)
                                            } else {
                                                focusRequester3.requestFocus()
                                            }
                                        }
                                    } else {
                                        codeDigit1 = digits
                                        if (digits.length == 3) {
                                            focusRequester2.requestFocus()
                                        }
                                    }
                                },
                                placeholder = { Text("000", color = Color(0xFF94A3B8), textAlign = TextAlign.Center) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Next
                                ),
                                textStyle = LocalTextStyle.current.copy(
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = KidsTextPrimary
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = KidsBluePrimary,
                                    unfocusedBorderColor = if (codeDigit1.length == 3) KidsBluePrimary else KidsCardBorder,
                                    focusedContainerColor = if (codeDigit1.length == 3) KidsBlueContainer.copy(alpha = 0.35f) else Color.White,
                                    unfocusedContainerColor = if (codeDigit1.length == 3) KidsBlueContainer.copy(alpha = 0.25f) else Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .focusRequester(focusRequester1),
                                shape = RoundedCornerShape(14.dp)
                            )

                            Text("•", fontWeight = FontWeight.Bold, color = KidsBluePrimary, fontSize = 20.sp)

                            // Box 2
                            OutlinedTextField(
                                value = codeDigit2,
                                onValueChange = { input ->
                                    val digits = input.filter { it.isDigit() }
                                    errorMessage = null
                                    if (digits.length >= 6) {
                                        codeDigit2 = digits.substring(0, 3)
                                        codeDigit3 = digits.substring(3, minOf(6, digits.length))
                                        if (codeDigit3.length == 3 && codeDigit1.length == 3) {
                                            submitPairing(codeDigit1 + codeDigit2 + codeDigit3)
                                        } else {
                                            focusRequester3.requestFocus()
                                        }
                                    } else if (digits.length > 3) {
                                        codeDigit2 = digits.substring(0, 3)
                                        codeDigit3 = digits.substring(3)
                                        focusRequester3.requestFocus()
                                    } else {
                                        codeDigit2 = digits
                                        if (digits.length == 3) {
                                            focusRequester3.requestFocus()
                                        } else if (digits.isEmpty()) {
                                            focusRequester1.requestFocus()
                                        }
                                    }
                                },
                                placeholder = { Text("000", color = Color(0xFF94A3B8), textAlign = TextAlign.Center) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Next
                                ),
                                textStyle = LocalTextStyle.current.copy(
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = KidsTextPrimary
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = KidsBluePrimary,
                                    unfocusedBorderColor = if (codeDigit2.length == 3) KidsBluePrimary else KidsCardBorder,
                                    focusedContainerColor = if (codeDigit2.length == 3) KidsBlueContainer.copy(alpha = 0.35f) else Color.White,
                                    unfocusedContainerColor = if (codeDigit2.length == 3) KidsBlueContainer.copy(alpha = 0.25f) else Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .focusRequester(focusRequester2),
                                shape = RoundedCornerShape(14.dp)
                            )

                            Text("•", fontWeight = FontWeight.Bold, color = KidsBluePrimary, fontSize = 20.sp)

                            // Box 3
                            OutlinedTextField(
                                value = codeDigit3,
                                onValueChange = { input ->
                                    val digits = input.filter { it.isDigit() }
                                    errorMessage = null
                                    if (digits.isEmpty()) {
                                        codeDigit3 = ""
                                        focusRequester2.requestFocus()
                                    } else {
                                        codeDigit3 = digits.take(3)
                                        if (codeDigit3.length == 3 && codeDigit1.length == 3 && codeDigit2.length == 3) {
                                            submitPairing(codeDigit1 + codeDigit2 + codeDigit3)
                                        }
                                    }
                                },
                                placeholder = { Text("000", color = Color(0xFF94A3B8), textAlign = TextAlign.Center) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                                textStyle = LocalTextStyle.current.copy(
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = KidsTextPrimary
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = KidsBluePrimary,
                                    unfocusedBorderColor = if (codeDigit3.length == 3) KidsBluePrimary else KidsCardBorder,
                                    focusedContainerColor = if (codeDigit3.length == 3) KidsBlueContainer.copy(alpha = 0.4f) else Color.White,
                                    unfocusedContainerColor = if (codeDigit3.length == 3) KidsBlueContainer.copy(alpha = 0.3f) else Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .focusRequester(focusRequester3),
                                shape = RoundedCornerShape(14.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        OutlinedTextField(
                            value = deviceNickname,
                            onValueChange = { deviceNickname = it },
                            label = { Text("Child Device Nickname") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = KidsRedContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = KidsRed, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = errorMessage ?: "",
                                        color = KidsRed,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = { submitPairing(fullCode) },
                            enabled = isCodeComplete && !isPairingLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            if (isPairingLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Verifying Code in Firebase...")
                            } else {
                                Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Connect & Verify Code", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Scan QR Alternative Button
                OutlinedButton(
                    onClick = {
                        keyboardController?.hide()
                        focusManager.clearFocus()
                        showQrDialog = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.5.dp, KidsBluePrimary)
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Scan Parent QR Code Instead",
                        color = KidsBluePrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, KidsCardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = KidsGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "Encrypted End-to-End Real-Time Firebase Sync",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = KidsTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
