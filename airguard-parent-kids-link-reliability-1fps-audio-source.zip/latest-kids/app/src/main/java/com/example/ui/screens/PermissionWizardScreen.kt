package com.example.ui.screens

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChildPermissionState
import com.example.data.repository.ChildSyncRepository
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionWizardScreen(
    repository: ChildSyncRepository,
    onComplete: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val notificationListenerUnsupported = Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q &&
        (context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.isLowRamDevice == true

    var permissions by remember { mutableStateOf(repository.checkPermissionState()) }

    var showBatteryOptimizationDialog by remember { mutableStateOf(false) }
    var showNotificationGuideDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }

    // Dialog prompts matching user screenshots
    var showCameraPermissionMockDialog by remember { mutableStateOf(false) }
    var showMicPermissionMockDialog by remember { mutableStateOf(false) }
    var showPhonePermissionMockDialog by remember { mutableStateOf(false) }
    var showCallLogPermissionMockDialog by remember { mutableStateOf(false) }

    fun refreshPermissions() {
        permissions = repository.checkPermissionState()
        coroutineScope.launch {
            repository.syncTelemetryToCloud(permissions)
        }
    }

    // Real system permission request launchers
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        refreshPermissions()
        if (isGranted) {
            Toast.makeText(context, "Camera permission granted for Remote Camera", Toast.LENGTH_SHORT).show()
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        refreshPermissions()
        if (isGranted) {
            Toast.makeText(context, "Microphone permission granted for One-Way Audio", Toast.LENGTH_SHORT).show()
        }
    }

    val legacyStoragePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { refreshPermissions() }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { map ->
        refreshPermissions()
        if (map.values.any { it }) {
            Toast.makeText(context, "Location GPS permission granted", Toast.LENGTH_SHORT).show()
        }
    }

    val phonePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { map ->
        refreshPermissions()
        if (map.values.any { it }) {
            Toast.makeText(context, "Phone and Call Logs permissions granted", Toast.LENGTH_SHORT).show()
        }
    }

    val settingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { refreshPermissions() }

    // Publish the latest state when setup opens. Standard runtime prompts are launched by the
    // root activity so they also appear before pairing; special access stays user-enabled here.
    LaunchedEffect(Unit) {
        refreshPermissions()
        com.example.service.AirGuardMediaCaptureService.start(context)
    }

    // 1. Background Battery Optimization Dialog (Matching Screenshot 12:48)
    if (showBatteryOptimizationDialog) {
        BackgroundBatteryOptimizationDialog(
            onDeny = {
                showBatteryOptimizationDialog = false
            },
            onAllow = {
                showBatteryOptimizationDialog = false
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        settingsLauncher.launch(intent)
                    }
                } catch (e: Exception) {
                    try {
                        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        settingsLauncher.launch(intent)
                    } catch (ex: Exception) {
                        Toast.makeText(context, "Please disable battery optimization for AirGuard Kids", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }

    // 3. Notification Access Guidance Dialog (Matching Screenshot 12:47)
    if (showNotificationGuideDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationGuideDialog = false },
            icon = { Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(36.dp)) },
            title = { Text("Allow Notification Access", fontWeight = FontWeight.Bold, color = KidsTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                            when {
                                notificationListenerUnsupported -> "Android does not support notification listeners on low-RAM devices running Android 10 or older. This feature will remain unavailable on this device."
                                else -> "When enabled, AirGuard Kids can read notification titles and preview text and sync them to the paired parent app. You can leave this off and revoke access in Android Settings at any time."
                            },
                        fontSize = 13.sp,
                        color = KidsTextSecondary
                    )
                    Text("1. Locate AirGuard Kids in the list of notification listeners.", color = KidsTextSecondary)
                    Text("2. Turn on the switch to grant access.", color = KidsTextSecondary)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showNotificationGuideDialog = false
                        try {
                            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                            settingsLauncher.launch(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Open Settings > Notification Access", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary)
                ) {
                    Text("Open Notification Settings")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNotificationGuideDialog = false }) { Text("Cancel") }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }

    // 4. Interactive Call Logs Permission Dialog (Matching Screenshot 12:45 - 1)
    if (showCallLogPermissionMockDialog) {
        AlertDialog(
            onDismissRequest = { showCallLogPermissionMockDialog = false },
            icon = {
                Icon(Icons.Default.PhoneCallback, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(40.dp))
            },
            title = {
                Text("Allow AirGuard Kids to access your phone call logs?", fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center, color = KidsTextPrimary)
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCallLogPermissionMockDialog = false
                        phonePermissionsLauncher.launch(
                            arrayOf(
                                android.Manifest.permission.READ_CALL_LOG,
                                android.Manifest.permission.READ_PHONE_STATE
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Allow", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCallLogPermissionMockDialog = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Don't allow", color = KidsTextSecondary, fontWeight = FontWeight.Medium)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }

    // 5. Interactive Camera Permission Dialog (Matching Screenshot 12:45 - 2)
    if (showCameraPermissionMockDialog) {
        AlertDialog(
            onDismissRequest = { showCameraPermissionMockDialog = false },
            icon = {
                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(40.dp))
            },
            title = {
                Text("Allow AirGuard Kids to take pictures and record video?", fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center, color = KidsTextPrimary)
            },
            confirmButton = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            showCameraPermissionMockDialog = false
                            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("While using the app", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            showCameraPermissionMockDialog = false
                            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Only this time", color = KidsTextPrimary, fontWeight = FontWeight.Medium)
                    }

                    TextButton(
                        onClick = { showCameraPermissionMockDialog = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Don't allow", color = KidsTextSecondary, fontWeight = FontWeight.Medium)
                    }
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }

    // 6. Interactive Microphone Permission Dialog (Matching Screenshot 12:45 - 3)
    if (showMicPermissionMockDialog) {
        AlertDialog(
            onDismissRequest = { showMicPermissionMockDialog = false },
            icon = {
                Icon(Icons.Default.Mic, contentDescription = null, tint = KidsGreen, modifier = Modifier.size(40.dp))
            },
            title = {
                Text("Allow AirGuard Kids to record audio?", fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center, color = KidsTextPrimary)
            },
            confirmButton = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            showMicPermissionMockDialog = false
                            micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("While using the app", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            showMicPermissionMockDialog = false
                            micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Only this time", color = KidsTextPrimary, fontWeight = FontWeight.Medium)
                    }

                    TextButton(
                        onClick = { showMicPermissionMockDialog = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Don't allow", color = KidsTextSecondary, fontWeight = FontWeight.Medium)
                    }
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }

    // 7. Interactive Manage Phone Calls Dialog (Matching Screenshot 12:45 - 4)
    if (showPhonePermissionMockDialog) {
        AlertDialog(
            onDismissRequest = { showPhonePermissionMockDialog = false },
            icon = {
                Icon(Icons.Default.Phone, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(40.dp))
            },
            title = {
                Text("Allow AirGuard Kids to make and manage phone calls?", fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center, color = KidsTextPrimary)
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPhonePermissionMockDialog = false
                        phonePermissionsLauncher.launch(
                            arrayOf(
                                android.Manifest.permission.READ_PHONE_STATE,
                                android.Manifest.permission.READ_CALL_LOG
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Allow", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showPhonePermissionMockDialog = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Don't allow", color = KidsTextSecondary, fontWeight = FontWeight.Medium)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("Permissions & Child Privacy", fontWeight = FontWeight.Bold, color = KidsTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Why are these permissions needed?", fontWeight = FontWeight.Bold, color = KidsTextPrimary)
                    Text("• Accessibility: Enforces daily screen time schedules and limits.", color = KidsTextSecondary)
                    Text("• Camera & Microphone: Enables parent remote camera check-ins and one-way audio.", color = KidsTextSecondary)
                    Text("• Usage Access: Accurately counts how long each app is used.", color = KidsTextSecondary)
                    Text("• Notifications: Syncs alerts for safety and detection.", color = KidsTextSecondary)
                    Text("All data is securely synced to your family's private Firebase project.", color = KidsTextSecondary)
                }
            },
            confirmButton = {
                Button(onClick = { showHelpDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary)) {
                    Text("Understood")
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Permission Setup", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                        Text("Authorizing device features", fontSize = 12.sp, color = Color.White.copy(alpha = 0.85f))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { refreshPermissions() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh Status", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KidsBlueDark)
            )
        },
        containerColor = KidsBackground,
        contentWindowInsets = WindowInsets.statusBars
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding).navigationBarsPadding()) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Verified Banner Header (answering user's "after code verifyed ask for permissions")
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = KidsGreenContainer),
                        border = BorderStroke(1.dp, KidsGreen)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = KidsGreen, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Binding Code Verified!", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = KidsGreen)
                                Text("Permissions are optional. Choose only the features you want below.", fontSize = 12.sp, color = Color(0xFF065F46))
                            }
                        }
                    }

                    if (!permissions.hasCamera || !permissions.hasMicrophone || !permissions.hasLocation || !permissions.hasPhoneState || !permissions.hasCallLog) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = KidsBlueContainer.copy(alpha = 0.6f)),
                            border = BorderStroke(1.5.dp, KidsBluePrimary)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = KidsBluePrimary, modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Optional feature permissions", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = KidsBlueDark)
                                    Text("Camera, microphone, location, and call access are requested from their related feature controls.", fontSize = 12.sp, color = KidsTextSecondary)
                                }
                            }
                        }
                    }
                }

                // Top phone illustration with toggles
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        PermissionHeaderIllustration(size = 115.dp)
                    }
                }

                // Subtitle
                item {
                    Text(
                        text = "To ensure AirGuard Kids functions properly, please grant the following permissions",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = KidsTextPrimary,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                    )
                }

                // 1. Usage Limits (Red Shield icon)
                item {
                    PermissionFeatureCard(
                        icon = Icons.Default.Shield,
                        iconBackgroundColor = KidsRed,
                        title = "Usage Limits",
                        description = "Limit app usage and screen time on this device",
                        toggles = listOf(
                            PermissionToggleItem(
                                label = "Accessibility Permission",
                                isGranted = permissions.hasAccessibility,
                                onToggleChange = {
                                    try {
                                        settingsLauncher.launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Open Android Settings > Accessibility to enable AirGuard Kids", Toast.LENGTH_LONG).show()
                                    }
                                }
                            ),
                        )
                    )
                }

                // 2. Screen Mirroring (Indigo icon)
                item {
                    PermissionFeatureCard(
                        icon = Icons.Default.Search,
                        iconBackgroundColor = KidsIndigo,
                        title = "App & Screen-Time Controls",
                        description = "Accessibility applies parent app blocks and time limits. Screen mirroring is unavailable in this build.",
                        toggles = listOf(
                            PermissionToggleItem(
                                label = "Accessibility Permission",
                                isGranted = permissions.hasAccessibility,
                                onToggleChange = {
                                    try {
                                        settingsLauncher.launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Open Android Settings > Accessibility to enable AirGuard Kids", Toast.LENGTH_LONG).show()
                                    }
                                }
                            )
                        )
                    )
                }

                // 3. Remote Camera (Vibrant Blue icon)
                item {
                    PermissionFeatureCard(
                        icon = Icons.Default.CameraAlt,
                        iconBackgroundColor = KidsBluePrimary,
                        title = "Remote Camera",
                        description = "Granting this lets your paired parent start a live camera session without another prompt. Android shows its camera indicator and AirGuard's live-access notification while active.",
                        toggles = listOf(
                            PermissionToggleItem(
                                label = "Camera Permission",
                                isGranted = permissions.hasCamera,
                                onToggleChange = {
                                    if (!permissions.hasCamera) {
                                        showCameraPermissionMockDialog = true
                                    } else {
                                        Toast.makeText(context, "Camera permission already granted", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        )
                    )
                }

                // 4. One-Way Audio (Vibrant Green icon)
                item {
                    PermissionFeatureCard(
                        icon = Icons.Default.VolumeUp,
                        iconBackgroundColor = KidsGreen,
                        title = "One-Way Audio",
                        description = "Granting this lets your paired parent start live microphone audio without another prompt. Android shows its microphone indicator and AirGuard's live-access notification while active.",
                        toggles = listOf(
                            PermissionToggleItem(
                                label = "Microphone Permission",
                                isGranted = permissions.hasMicrophone,
                                onToggleChange = {
                                    if (!permissions.hasMicrophone) {
                                        showMicPermissionMockDialog = true
                                    } else {
                                        Toast.makeText(context, "Microphone permission already granted", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        )
                    )
                }

                // 5. App Insights (Purple icon)
                item {
                    PermissionFeatureCard(
                        icon = Icons.Default.Assignment,
                        iconBackgroundColor = KidsPurple,
                        title = "App Insights",
                        description = "Gain insights into your child's app usage and screen time",
                        toggles = listOf(
                            PermissionToggleItem(
                                label = "User Usage Permission",
                                isGranted = permissions.hasUsageStats,
                                onToggleChange = {
                                    try {
                                        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                        settingsLauncher.launch(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Open Settings > Usage Access", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ),
                            PermissionToggleItem(
                                label = "Phone & Call Logs Permission",
                                isGranted = permissions.hasPhoneState && permissions.hasCallLog,
                                onToggleChange = {
                                    if (!permissions.hasPhoneState) {
                                        showPhonePermissionMockDialog = true
                                    } else if (!permissions.hasCallLog) {
                                        showCallLogPermissionMockDialog = true
                                    } else {
                                        Toast.makeText(context, "Phone permissions already granted", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        )
                    )
                }

                // 6. Device & App Notifications (Purple icon)
                item {
                    PermissionFeatureCard(
                        icon = Icons.Default.Notifications,
                        iconBackgroundColor = KidsPurple,
                        title = "Device & App Notifications",
                        description = "Stream notifications to parent device for safety alerts",
                        toggles = listOf(
                            PermissionToggleItem(
                                label = "Notification Access",
                                isGranted = permissions.hasNotificationListener,
                            onToggleChange = {
                                if (notificationListenerUnsupported) {
                                    Toast.makeText(context, "Notification access is unavailable on low-RAM Android 10 and older devices", Toast.LENGTH_LONG).show()
                                } else {
                                    showNotificationGuideDialog = true
                                }
                            }
                            )
                        )
                    )
                }

                // 7. Background Reliability & Location GPS (Amber icon)
                item {
                    PermissionFeatureCard(
                        icon = Icons.Default.BatteryChargingFull,
                        iconBackgroundColor = KidsAmber,
                        title = "Background Running & GPS",
                        description = "Keep real-time GPS tracking and sync alive in background",
                        toggles = listOf(
                            PermissionToggleItem(
                                label = "Always Run in Background",
                                isGranted = permissions.isIgnoringBatteryOptimizations,
                                onToggleChange = {
                                    showBatteryOptimizationDialog = true
                                }
                            ),
                            PermissionToggleItem(
                                label = "Location (GPS Tracking)",
                                isGranted = permissions.hasLocation,
                                onToggleChange = {
                                    if (!permissions.hasLocation) {
                                        locationPermissionLauncher.launch(
                                            arrayOf(
                                                android.Manifest.permission.ACCESS_FINE_LOCATION,
                                                android.Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    }
                                }
                            )
                        )
                    )
                }

                item {
                    PermissionFeatureCard(
                        icon = Icons.Default.FolderOpen,
                        iconBackgroundColor = KidsBluePrimary,
                        title = "Parent File Listing",
                        description = "Optional media access for the Images & Videos section in the parent app. On Android 11+, enable Manage all files in Settings; older versions use Android's storage permission.",
                        toggles = listOf(
                            PermissionToggleItem(
                                label = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) "Manage all files access" else "Photos and media access",
                                isGranted = permissions.hasManageAllFiles,
                                onToggleChange = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !permissions.hasManageAllFiles) {
                                        try {
                                            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                                                data = Uri.parse("package:${context.packageName}")
                                            }
                                            settingsLauncher.launch(intent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Open Settings > Special app access > All files access", Toast.LENGTH_LONG).show()
                                        }
                                    } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R && !permissions.hasManageAllFiles) {
                                        legacyStoragePermissionLauncher.launch(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                                    } else {
                                        Toast.makeText(context, "This Android version does not require All files access", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        )
                    )
                }

                item {
                    PermissionFeatureCard(
                        icon = Icons.Default.Lock,
                        iconBackgroundColor = KidsBluePrimary,
                        title = "Device Admin Screen Lock",
                        description = "Allows Parent to lock the phone screen without Accessibility. The child can unlock it with the device PIN.",
                        toggles = listOf(
                            PermissionToggleItem(
                                label = if (permissions.hasDeviceAdmin) "Device Admin enabled" else "Enable Device Admin",
                                isGranted = permissions.hasDeviceAdmin,
                                onToggleChange = {
                                    if (!permissions.hasDeviceAdmin) {
                                        val component = android.content.ComponentName(
                                            context,
                                            com.example.service.AirGuardDeviceAdminReceiver::class.java
                                        )
                                        val intent = Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                            putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
                                            putExtra(
                                                android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                                "Allow AirGuard Parent to lock this phone's screen when requested."
                                            )
                                        }
                                        settingsLauncher.launch(intent)
                                    }
                                }
                            )
                        )
                    )
                }

                // Bottom Action Buttons
                item {
                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                repository.syncTelemetryToCloud(permissions)
                                Toast.makeText(context, "Permissions authorized & transferring data to parent!", Toast.LENGTH_SHORT).show()
                                onComplete()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = KidsBluePrimary),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Finish & Enable Active Monitoring (${permissions.totalGranted}/${permissions.totalCount})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(110.dp))
                }
            }

            // Customer Support Widget
            SupportAgentWidget(
                onClick = { showHelpDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 20.dp, bottom = 24.dp)
            )
        }
    }
}
