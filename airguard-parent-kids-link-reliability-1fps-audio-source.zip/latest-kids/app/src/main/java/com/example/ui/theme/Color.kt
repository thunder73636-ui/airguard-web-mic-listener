package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// A friendly pastel palette shared across the child app's cards and controls.
val KidsBlueDark = Color(0xFF49415F)
val KidsBluePrimary = Color(0xFF7968C4)
val KidsBlueVibrant = Color(0xFF927FDA)
val KidsBlueDeep = Color(0xFF514776)
val KidsBlueAccent = Color(0xFF6C9CC8)
val KidsBlueContainer = Color(0xFFEAE5FF)
val KidsBlueSurface = Color(0xFFF5F1FF)

val KidsRed = Color(0xFFD97878)
val KidsRedContainer = Color(0xFFFFE8E8)
val KidsGreen = Color(0xFF548B68)
val KidsGreenVibrant = Color(0xFF70AE83)
val KidsGreenContainer = Color(0xFFE3F5E8)
val KidsAmber = Color(0xFFC58A35)
val KidsAmberContainer = Color(0xFFFFF1D6)
val KidsPurple = Color(0xFFB16D97)
val KidsPurpleContainer = Color(0xFFFBE8F3)
val KidsIndigo = Color(0xFF7968C4)
val KidsIndigoContainer = Color(0xFFEAE5FF)

val KidsBackground = Color(0xFFFFF8FC)
val KidsSurface = Color(0xFFFFFFFF)
val KidsSurfaceVariant = Color(0xFFFFF3F8)
val KidsCardBorder = Color(0xFFF0DDE9)
val KidsCardBorderActive = Color(0xFFC9BDF2)

val KidsTextPrimary = Color(0xFF302A3B)
val KidsTextSecondary = Color(0xFF625B6C)
val KidsTextMuted = Color(0xFF81798C)
