package com.example.util

import android.util.Base64
import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Must match the Parent app verifier format; only salted hashes are stored on device/cloud. */
object OfflineUnlockPinCrypto {
    const val ITERATIONS = 120_000
    private const val KEY_BITS = 256

    fun matches(pin: String, salt: String, expectedHash: String): Boolean = try {
        val saltBytes = Base64.decode(salt, Base64.NO_WRAP)
        val spec = PBEKeySpec(pin.toCharArray(), saltBytes, ITERATIONS, KEY_BITS)
        val actual = try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
                .generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
        MessageDigest.isEqual(actual, Base64.decode(expectedHash, Base64.NO_WRAP))
    } catch (_: Exception) {
        false
    }
}
