package com.example

import android.Manifest
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.RemoteMediaSession
import com.example.data.repository.ChildSyncRepository
import com.example.media.ChildMediaSignalingManager
import com.example.media.MediaPermissionPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ChildMediaStreamingTest {

    private lateinit var context: Context
    private lateinit var repository: ChildSyncRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        repository = ChildSyncRepository(context)
    }

    @Test
    fun signalingManagerStartsWithoutAnActiveSession() {
        val manager = ChildMediaSignalingManager(context, repository)

        assertNull(manager.activeSession.value)
        assertNull(manager.pendingPermissionPrompt.value)

        manager.release()
    }

    @Test
    fun cameraRequestWaitsForCameraAndMicrophonePermissions() {
        val manager = ChildMediaSignalingManager(context, repository)
        val session = RemoteMediaSession(
            id = "sess_camera_test",
            deviceId = repository.getChildDeviceId(),
            type = "CAMERA",
            status = "OFFER_SENT"
        )

        manager.evaluateAndHandleOffer(session)

        val prompt = manager.pendingPermissionPrompt.value
        assertNotNull(prompt)
        assertEquals(session.id, prompt?.session?.id)
        assertTrue(prompt?.missingPermissions?.contains(Manifest.permission.CAMERA) == true)
        assertTrue(prompt?.missingPermissions?.contains(Manifest.permission.RECORD_AUDIO) == true)

        manager.onPermissionsDenied(session)
        assertNull(manager.pendingPermissionPrompt.value)
        manager.release()
    }

    @Test
    fun alreadyGrantedCameraAndMicrophonePermissionsNeedNoRepeatedPrompt() {
        assertTrue(MediaPermissionPolicy.missingPermissions("CAMERA", hasCamera = true, hasMicrophone = true).isEmpty())
    }

    @Test
    fun cameraSessionStillRequestsOnlyPermissionsThatAreMissing() {
        assertEquals(
            listOf(Manifest.permission.CAMERA),
            MediaPermissionPolicy.missingPermissions("CAMERA", hasCamera = false, hasMicrophone = true)
        )
        assertTrue(MediaPermissionPolicy.missingPermissions("ONE_WAY_AUDIO", hasCamera = false, hasMicrophone = true).isEmpty())
    }

    @Test
    fun screenMirrorWaitsForChildAndAndroidCaptureConsent() {
        val manager = ChildMediaSignalingManager(context, repository)
        val session = RemoteMediaSession(
            id = "sess_screen_test",
            deviceId = repository.getChildDeviceId(),
            type = "SCREEN_MIRROR",
            status = "OFFER_SENT"
        )

        manager.evaluateAndHandleOffer(session)

        assertNotNull(manager.pendingPermissionPrompt.value)
        assertTrue(manager.pendingPermissionPrompt.value?.missingPermissions?.isEmpty() == true)
        assertNull(manager.activeSession.value)
        manager.onPermissionsGranted(session)
        assertNull(manager.pendingPermissionPrompt.value)
        assertEquals(session.id, manager.pendingScreenCaptureSession?.id)
        manager.onScreenCaptureDenied()
        assertNull(manager.pendingScreenCaptureSession)
        manager.release()
    }

    @Test
    @Config(sdk = [26])
    fun androidEightPermissionPolicyRemainsAvailable() {
        assertEquals(
            listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO),
            MediaPermissionPolicy.missingPermissions("CAMERA", hasCamera = false, hasMicrophone = false)
        )
    }

    @Test
    fun expiredRequestCannotStartCaptureAfterTheChildApproves() {
        val manager = ChildMediaSignalingManager(context, repository)
        val expired = RemoteMediaSession(
            id = "sess_expired_test",
            deviceId = repository.getChildDeviceId(),
            type = "CAMERA",
            status = "OFFER_SENT",
            expiresAt = System.currentTimeMillis() - 1L,
            sdpOffer = com.example.data.model.SdpPayload("offer", "test-sdp")
        )

        manager.evaluateAndHandleOffer(expired)
        assertNotNull(manager.pendingPermissionPrompt.value)
        manager.onPermissionsGranted(expired)

        assertNull(manager.pendingPermissionPrompt.value)
        assertNull(manager.activeSession.value)
        manager.release()
    }

}
