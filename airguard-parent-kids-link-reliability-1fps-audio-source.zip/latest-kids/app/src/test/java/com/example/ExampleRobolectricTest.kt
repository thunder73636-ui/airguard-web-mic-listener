package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.ChildSyncRepository
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var repository: ChildSyncRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        repository = ChildSyncRepository(context)
    }

    @Test
    fun `read string from context`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("AirGuard Kids", appName)
    }

    @Test
    fun `check device id generation and persistence`() {
        val id1 = repository.getChildDeviceId()
        assertTrue("Device ID should start with dev_", id1.startsWith("dev_"))
        val id2 = repository.getChildDeviceId()
        assertEquals("Subsequent calls must return identical persistent device ID", id1, id2)
    }

    @Test
    fun `check initial permissions state structure`() {
        val perm = repository.checkPermissionState()
        assertEquals("Total tracked permissions should be 11", 11, perm.totalCount)
        assertTrue("Granted count should be between 0 and 11", perm.totalGranted in 0..11)
    }
}
