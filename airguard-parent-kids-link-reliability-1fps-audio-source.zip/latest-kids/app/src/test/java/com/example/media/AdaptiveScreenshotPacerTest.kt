package com.example.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AdaptiveScreenshotPacerTest {
    @Test
    fun startsAtTenFpsCeilingAndNeverTargetsFaster() {
        val pacer = AdaptiveScreenshotPacer()

        assertEquals(100L, pacer.intervalMs)
        repeat(40) { pacer.onFrameCompleted(workDurationMs = 1L, wasCongested = false) }

        assertTrue(pacer.intervalMs >= 100L)
    }

    @Test
    fun slowsToMeasuredCaptureAndTransferCapacity() {
        val pacer = AdaptiveScreenshotPacer()

        pacer.onFrameCompleted(workDurationMs = 250L, wasCongested = false)

        assertEquals(312L, pacer.intervalMs)
    }

    @Test
    fun congestionAndCaptureFailuresBackOffAndStableFramesRecoverGradually() {
        val pacer = AdaptiveScreenshotPacer()
        pacer.onFrameCompleted(workDurationMs = 100L, wasCongested = true)
        val congestedInterval = pacer.intervalMs
        pacer.onCaptureFailure()

        assertTrue(congestedInterval > 100L)
        assertTrue(pacer.intervalMs > congestedInterval)
        repeat(8) { pacer.onFrameCompleted(workDurationMs = 10L, wasCongested = false) }

        assertTrue(pacer.intervalMs < congestedInterval * 2)
        assertTrue(pacer.intervalMs >= 100L)
    }

    @Test
    fun backsOffAtMostToAboutOneFramePerSecond() {
        val pacer = AdaptiveScreenshotPacer()
        repeat(10) { pacer.onCaptureFailure() }

        assertEquals(1_100L, pacer.intervalMs)
    }
}
