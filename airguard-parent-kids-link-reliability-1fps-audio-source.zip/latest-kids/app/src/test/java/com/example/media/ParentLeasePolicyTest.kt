package com.example.media

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ParentLeasePolicyTest {
    @Test
    fun onlyExpiresWhenAHeartbeatWasPublishedAndItsLeaseElapsed() {
        assertFalse(ParentLeasePolicy.isExpired(0L, 100_000L, 60_000L))
        assertFalse(ParentLeasePolicy.isExpired(50_000L, 100_000L, 60_000L))
        assertTrue(ParentLeasePolicy.isExpired(39_999L, 100_000L, 60_000L))
    }
}
