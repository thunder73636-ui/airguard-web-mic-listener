package com.example.monitoring

import org.junit.Assert.assertEquals
import org.junit.Test

class DeviceUsageStatsTest {
    @Test
    fun totalUsageCombinesAppDurationsBeforeRounding() {
        assertEquals(1, DeviceUsageStats.totalMinutesFromMillis(listOf(40_000L, 40_000L)))
    }

    @Test
    fun totalUsageDoesNotCountSubMinuteAsAFullMinute() {
        assertEquals(0, DeviceUsageStats.totalMinutesFromMillis(listOf(59_999L)))
    }
}
