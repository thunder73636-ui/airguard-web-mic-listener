package com.example.service

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DevicePausePolicyTest {
    @Test
    fun emergencyCallingRemainsAvailableDuringPause() {
        assertTrue(isEssentialDuringDevicePause("com.google.android.dialer"))
        assertTrue(isEssentialDuringDevicePause("com.android.incallui"))
    }

    @Test
    fun settingsAppsAndSystemUiAreCoveredByPauseOverlay() {
        assertFalse(isEssentialDuringDevicePause("com.android.settings"))
        assertFalse(isEssentialDuringDevicePause("com.example.kids"))
        assertFalse(isEssentialDuringDevicePause("com.android.systemui"))
        assertFalse(isEssentialDuringDevicePause("com.google.android.youtube"))
    }
}
