package com.example

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.outlined.FamilyRestroom
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.repository.ParentRepository
import com.example.ui.screens.*
import com.example.ui.components.hoverLift
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var repository: ParentRepository
    private val notificationPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = androidx.activity.SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = androidx.activity.SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )
        repository = ParentRepository(this)
        ensureOnlineAlertPermission()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AirGuardApp(repository = repository)
                }
            }
        }
    }

    private fun ensureOnlineAlertPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        ) return
        val preferences = getSharedPreferences("parent_notification_permission", MODE_PRIVATE)
        if (preferences.getBoolean("asked", false) &&
            !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)
        ) return
        preferences.edit().putBoolean("asked", true).apply()
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}

@Composable
fun AirGuardApp(repository: ParentRepository) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val coroutineScope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    val devices by repository.observeDevices().collectAsStateWithLifecycle(initialValue = emptyList())
    val account by repository.observeAccount().collectAsStateWithLifecycle(initialValue = null)

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var selectedDeviceIndex by rememberSaveable { mutableIntStateOf(0) }

    // Synchronize devices on resume or initial composition
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                coroutineScope.launch {
                    repository.syncAllDevicesFromFirestore()
                    repository.startGlobalDevicesListener()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val isTopLevelRoute = currentRoute == null || currentRoute == "main"

    Scaffold(
        bottomBar = {
            if (isTopLevelRoute) {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = NavigationBarDefaults.Elevation
                ) {
                    NavigationBarItem(
                        modifier = Modifier.hoverLift(),
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = {
                            Icon(
                                if (selectedTab == 0) Icons.Default.PhoneAndroid else Icons.Outlined.PhoneAndroid,
                                contentDescription = "Device"
                            )
                        },
                        label = { Text("Device") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF7968C4),
                            selectedTextColor = Color(0xFF7968C4),
                            unselectedIconColor = Color(0xFF716B7D),
                            unselectedTextColor = Color(0xFF716B7D),
                            indicatorColor = Color(0xFFEAE5F8)
                        )
                    )
                    NavigationBarItem(
                        modifier = Modifier.hoverLift(),
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = {
                            Icon(
                                if (selectedTab == 1) Icons.Default.LocationOn else Icons.Outlined.LocationOn,
                                contentDescription = "Location"
                            )
                        },
                        label = { Text("Location") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF7968C4),
                            selectedTextColor = Color(0xFF7968C4),
                            unselectedIconColor = Color(0xFF716B7D),
                            unselectedTextColor = Color(0xFF716B7D),
                            indicatorColor = Color(0xFFEAE5F8)
                        )
                    )
                    NavigationBarItem(
                        modifier = Modifier.hoverLift(),
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = {
                            Icon(
                                if (selectedTab == 2) Icons.Default.FamilyRestroom else Icons.Outlined.FamilyRestroom,
                                contentDescription = "Family"
                            )
                        },
                        label = { Text("Family") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF7968C4),
                            selectedTextColor = Color(0xFF7968C4),
                            unselectedIconColor = Color(0xFF716B7D),
                            unselectedTextColor = Color(0xFF716B7D),
                            indicatorColor = Color(0xFFEAE5F8)
                        )
                    )
                    NavigationBarItem(
                        modifier = Modifier.hoverLift(),
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = {
                            Icon(
                                if (selectedTab == 3) Icons.Default.Person else Icons.Outlined.Person,
                                contentDescription = "My"
                            )
                        },
                        label = { Text("My") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF7968C4),
                            selectedTextColor = Color(0xFF7968C4),
                            unselectedIconColor = Color(0xFF716B7D),
                            unselectedTextColor = Color(0xFF716B7D),
                            indicatorColor = Color(0xFFEAE5F8)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "main",
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .wrapContentWidth(androidx.compose.ui.Alignment.CenterHorizontally)
                .widthIn(max = 1_080.dp),
            enterTransition = { fadeIn(tween(180)) + slideInHorizontally(tween(180)) { it / 14 } },
            exitTransition = { fadeOut(tween(140)) + slideOutHorizontally(tween(140)) { -it / 18 } }
        ) {
            composable("main") {
                Crossfade(targetState = selectedTab, animationSpec = tween(180), label = "main_tab_transition") { tab ->
                when (tab) {
                    0 -> DashboardScreen(
                        repository = repository,
                        devices = devices,
                        selectedDeviceIndex = selectedDeviceIndex.coerceIn(0, (devices.size - 1).coerceAtLeast(0)),
                        account = account,
                        onSelectDeviceIndex = { selectedDeviceIndex = it },
                        onNavigateToBinding = { navController.navigate("binding") },
                        onNavigateToUsage = { deviceId -> navController.navigate("usage/$deviceId") },
                        onNavigateToRemote = { deviceId, type -> navController.navigate("remote/$deviceId/$type") },
                        onNavigateToFiles = { deviceId -> navController.navigate("files/$deviceId") },
                        onToggleLock = { deviceId, locked ->
                            coroutineScope.launch {
                                try {
                                    repository.toggleDeviceLock(deviceId, locked)
                                    Toast.makeText(
                                        context,
                                        if (locked) "Instant Block sent to the child device" else "Unlock sent to the child device",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, e.message ?: "Could not send the device lock command", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        onRequestScreenLock = { deviceId ->
                            coroutineScope.launch {
                                try {
                                    repository.requestDeviceScreenLock(deviceId)
                                    Toast.makeText(context, "Screen lock command sent to child", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, e.message ?: "Could not lock the child screen", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        onNavigateToWebMicListener = { navController.navigate("web-mic-listener") },
                        onRefreshTelemetry = { deviceId ->
                            coroutineScope.launch { repository.refreshDeviceTelemetry(deviceId) }
                        },
                        onNavigateToSafetyFeature = { featureKey, deviceId ->
                            navController.navigate("safety/$featureKey/$deviceId")
                        },
                        onUpdateBlockNewInstalls = { deviceId, block ->
                            coroutineScope.launch { repository.updateBlockNewInstalls(deviceId, block) }
                        },
                        onUpdateAlwaysAllowedApps = { deviceId, apps ->
                            coroutineScope.launch { repository.updateAlwaysAllowedApps(deviceId, apps) }
                        },
                        onUpdatePreventUninstall = { deviceId, prevent ->
                            coroutineScope.launch { repository.updatePreventUninstall(deviceId, prevent) }
                        },
                        onUpdateScreenTimeLimit = { deviceId, limit ->
                            coroutineScope.launch { repository.updateScreenTimeLimit(deviceId, limit) }
                        },
                        onRingDevice = { deviceId, ring ->
                            coroutineScope.launch {
                                try {
                                    repository.requestPhoneRing(deviceId, ring)
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(
                                        context,
                                        e.message ?: "Could not send ring request",
                                        android.widget.Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        },
                        onReconnectChild = { deviceId ->
                            coroutineScope.launch {
                                try {
                                    repository.requestChildReconnect(deviceId)
                                    Toast.makeText(context, "Reconnect signal sent (flashlight OFF)", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, e.message ?: "Could not send reconnect signal", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        onTurnFlashlightOn = { deviceId ->
                            coroutineScope.launch {
                                try {
                                    repository.setChildFlashlight(deviceId, true)
                                    Toast.makeText(context, "Flashlight ON command sent", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, e.message ?: "Could not turn on the child flashlight", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        onDeleteDevice = { deviceId ->
                            val result = repository.deleteDevice(deviceId)
                            selectedDeviceIndex = 0
                            val message = when (result) {
                                ParentRepository.DeleteDeviceResult.REMOVED_FROM_CLOUD -> "Device unlinked and removed"
                                ParentRepository.DeleteDeviceResult.REMOVED_LOCALLY_PENDING_SYNC -> "Removed from this Parent app. Cloud unlink will retry when available."
                            }
                            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                            result
                        },
                        onResolveExtraTimeRequest = { deviceId, approve ->
                            coroutineScope.launch {
                                try {
                                    repository.resolveExtraTimeRequest(deviceId, approve)
                                    android.widget.Toast.makeText(context, if (approve) "15 extra minutes allowed" else "Request declined", android.widget.Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(context, e.message ?: "Could not update request", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    )
                    1 -> LocationScreen(
                        devices = devices,
                        selectedDeviceIndex = selectedDeviceIndex.coerceIn(0, (devices.size - 1).coerceAtLeast(0)),
                        repository = repository,
                        onSelectDeviceIndex = { selectedDeviceIndex = it },
                        onNavigateToBinding = { navController.navigate("binding") }
                    )
                    2 -> FamilyScreen(
                        devices = devices,
                        account = account,
                        repository = repository,
                        onBack = { selectedTab = 0 },
                        onAddDevice = { navController.navigate("binding") }
                    )
                    3 -> MyScreen(
                        account = account,
                        devices = devices,
                        repository = repository,
                        onNavigateToBinding = { navController.navigate("binding") }
                    )
                }
                }
            }

            composable("binding") {
                BindingScreen(
                    repository = repository,
                    onDeviceAdded = { _ ->
                        // PairingManager already inserted the verified Firestore device into Room.
                        // Avoid a second one-shot server query here: a stale response could erase it.
                        selectedDeviceIndex = 0
                        navController.popBackStack()
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable("web-mic-listener") {
                WebMicListenerScreen(repository = repository, onBack = { navController.popBackStack() })
            }

            composable(
                route = "usage/{deviceId}",
                arguments = listOf(navArgument("deviceId") { type = NavType.StringType })
            ) { backStackEntry ->
                val deviceId = backStackEntry.arguments?.getString("deviceId") ?: ""
                UsageScreen(
                    deviceId = deviceId,
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = "files/{deviceId}",
                arguments = listOf(navArgument("deviceId") { type = NavType.StringType })
            ) { backStackEntry ->
                val deviceId = backStackEntry.arguments?.getString("deviceId") ?: ""
                val device by repository.observeDeviceById(deviceId).collectAsState(initial = null)
                FilesScreen(
                    deviceId = deviceId,
                    deviceName = device?.deviceName ?: "Child Device",
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = "remote/{deviceId}/{type}",
                arguments = listOf(
                    navArgument("deviceId") { type = NavType.StringType },
                    navArgument("type") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val deviceId = backStackEntry.arguments?.getString("deviceId") ?: ""
                val type = backStackEntry.arguments?.getString("type") ?: "CAMERA"
                RemoteScreen(
                    deviceId = deviceId,
                    initialType = type,
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    onNavigateToDiagnostics = {
                        navController.navigate("diagnostics/$deviceId/$type")
                    }
                )
            }

            composable(
                route = "diagnostics/{deviceId}/{type}",
                arguments = listOf(
                    navArgument("deviceId") { type = NavType.StringType },
                    navArgument("type") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val deviceId = backStackEntry.arguments?.getString("deviceId") ?: ""
                val type = backStackEntry.arguments?.getString("type") ?: "CAMERA"
                val device by repository.observeDeviceById(deviceId).collectAsState(initial = null)
                val signalingManager = remember(deviceId) { repository.createMediaSignalingManager() }
                val deviceName = device?.deviceName ?: "Child Device"
                val isOnline = device?.isOnline ?: true
                val hasPerm = when (type) {
                    "CAMERA" -> device?.hasCameraPermission ?: true
                    "ONE_WAY_AUDIO" -> device?.hasMicrophonePermission ?: true
                    else -> device?.hasAccessibilityPermission ?: true
                }
                LaunchedEffect(deviceId, type, isOnline, hasPerm) {
                    val uid = repository.authRepository.getCurrentUid()
                    signalingManager.startSession(deviceId, type, uid, isOnline, hasPerm)
                }
                DisposableEffect(Unit) {
                    onDispose {
                        signalingManager.endSession()
                    }
                }
                DiagnosticScreen(
                    deviceId = deviceId,
                    deviceName = deviceName,
                    signalingManager = signalingManager,
                    onBack = { navController.popBackStack() },
                    onRetry = {
                        val uid = repository.authRepository.getCurrentUid()
                        signalingManager.startSession(deviceId, type, uid, isOnline, hasPerm)
                    }
                )
            }

            composable(
                route = "safety/{featureKey}/{deviceId}",
                arguments = listOf(
                    navArgument("featureKey") { type = NavType.StringType },
                    navArgument("deviceId") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val featureKey = backStackEntry.arguments?.getString("featureKey") ?: "NOTIFICATIONS"
                val deviceId = backStackEntry.arguments?.getString("deviceId") ?: ""
                SafetyFeatureDetailScreen(
                    featureKey = featureKey,
                    deviceId = deviceId,
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
