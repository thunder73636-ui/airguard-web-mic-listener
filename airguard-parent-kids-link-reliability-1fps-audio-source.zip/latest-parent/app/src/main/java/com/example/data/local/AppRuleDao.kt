package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppRule
import kotlinx.coroutines.flow.Flow

@Dao
interface AppRuleDao {
    @Query("SELECT * FROM app_rules WHERE deviceId = :deviceId ORDER BY todayUsageMinutes DESC")
    fun observeAppRulesForDevice(deviceId: String): Flow<List<AppRule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(rule: AppRule)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rules: List<AppRule>)

    @Update
    suspend fun updateRule(rule: AppRule)

    @Query("UPDATE app_rules SET isBlocked = :isBlocked WHERE id = :ruleId")
    suspend fun toggleBlockStatus(ruleId: String, isBlocked: Boolean)

    @Query("UPDATE app_rules SET dailyLimitMinutes = :limitMinutes WHERE id = :ruleId")
    suspend fun updateDailyLimit(ruleId: String, limitMinutes: Int)

    @Query("DELETE FROM app_rules WHERE deviceId = :deviceId")
    suspend fun deleteRulesForDevice(deviceId: String)
}
