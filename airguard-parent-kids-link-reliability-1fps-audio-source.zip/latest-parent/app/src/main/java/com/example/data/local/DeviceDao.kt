package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Device
import kotlinx.coroutines.flow.Flow

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices ORDER BY lastSeenTimestamp DESC")
    fun observeAllDevices(): Flow<List<Device>>

    @Query("SELECT * FROM devices")
    suspend fun getAllDevices(): List<Device>

    @Query("SELECT * FROM devices WHERE parentUid = :parentUid")
    suspend fun getDevicesForParent(parentUid: String): List<Device>

    @Query("SELECT * FROM devices WHERE id = :deviceId LIMIT 1")
    suspend fun getDeviceById(deviceId: String): Device?

    @Query("SELECT * FROM devices WHERE id = :deviceId LIMIT 1")
    fun observeDeviceById(deviceId: String): Flow<Device?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(device: Device)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(devices: List<Device>)

    @Update
    suspend fun updateDevice(device: Device)

    @Query("UPDATE devices SET isLocked = :isLocked WHERE id = :deviceId")
    suspend fun updateLockStatus(deviceId: String, isLocked: Boolean)

    @Query("UPDATE devices SET screenTimeLimitMinutes = :limitMinutes WHERE id = :deviceId")
    suspend fun updateScreenTimeLimit(deviceId: String, limitMinutes: Int)

    @Query("UPDATE devices SET downtimeEnabled = :enabled, downtimeStartHour = :startH, downtimeStartMinute = :startM, downtimeEndHour = :endH, downtimeEndMinute = :endM, downtimeDays = :days WHERE id = :deviceId")
    suspend fun updateDowntime(deviceId: String, enabled: Boolean, startH: Int, startM: Int, endH: Int, endM: Int, days: String)

    @Query("UPDATE devices SET isOnline = :isOnline, batteryLevel = :battery, lastSeenTimestamp = :timestamp WHERE id = :deviceId")
    suspend fun updateConnectionStatus(deviceId: String, isOnline: Boolean, battery: Int, timestamp: Long)

    @Query("UPDATE devices SET blockNewInstalls = :block WHERE id = :deviceId")
    suspend fun updateBlockNewInstalls(deviceId: String, block: Boolean)

    @Query("UPDATE devices SET alwaysAllowedApps = :apps WHERE id = :deviceId")
    suspend fun updateAlwaysAllowedApps(deviceId: String, apps: String)

    @Query("UPDATE devices SET preventUninstall = :prevent WHERE id = :deviceId")
    suspend fun updatePreventUninstall(deviceId: String, prevent: Boolean)

    @Query("UPDATE devices SET hasAccessibilityPermission = :access, hasUsageStatsPermission = :usage, hasNotificationPermission = :notif, hasLocationPermission = :loc, hasCameraPermission = :cam, hasMicrophonePermission = :mic, hasAdminPermission = :admin WHERE id = :deviceId")
    suspend fun updateChildPermissions(deviceId: String, access: Boolean, usage: Boolean, notif: Boolean, loc: Boolean, cam: Boolean, mic: Boolean, admin: Boolean)

    @Query("DELETE FROM devices WHERE id = :deviceId")
    suspend fun deleteDevice(deviceId: String)

    @Query("DELETE FROM devices")
    suspend fun deleteAllDevices()
}
