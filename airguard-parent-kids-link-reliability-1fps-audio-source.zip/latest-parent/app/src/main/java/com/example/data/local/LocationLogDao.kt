package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.LocationLog
import kotlinx.coroutines.flow.Flow

@Dao
interface LocationLogDao {
    @Query("SELECT * FROM location_logs WHERE deviceId = :deviceId ORDER BY timestamp DESC LIMIT 50")
    fun observeLogsForDevice(deviceId: String): Flow<List<LocationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: LocationLog)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<LocationLog>)

    @Query("DELETE FROM location_logs WHERE deviceId = :deviceId")
    suspend fun deleteLogsForDevice(deviceId: String)
}
