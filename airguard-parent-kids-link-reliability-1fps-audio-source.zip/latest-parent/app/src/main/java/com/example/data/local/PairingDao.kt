package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.PairingSession
import kotlinx.coroutines.flow.Flow

@Dao
interface PairingDao {
    @Query("SELECT * FROM pairing_sessions ORDER BY createdAt DESC LIMIT 1")
    fun observeLatestPairingSession(): Flow<PairingSession?>

    @Query("SELECT * FROM pairing_sessions WHERE id = :sessionId LIMIT 1")
    suspend fun getPairingSession(sessionId: String): PairingSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPairingSession(session: PairingSession)

    @Query("UPDATE pairing_sessions SET status = :status WHERE id = :sessionId")
    suspend fun updateStatus(sessionId: String, status: String)

    @Query("UPDATE pairing_sessions SET status = :status, childDeviceId = :childDeviceId WHERE id = :sessionId")
    suspend fun updatePaired(sessionId: String, status: String, childDeviceId: String)

    @Query("DELETE FROM pairing_sessions")
    suspend fun clearSessions()
}
