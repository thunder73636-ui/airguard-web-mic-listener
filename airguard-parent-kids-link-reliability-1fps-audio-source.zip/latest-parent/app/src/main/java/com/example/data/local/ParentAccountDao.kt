package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ParentAccount
import kotlinx.coroutines.flow.Flow

@Dao
interface ParentAccountDao {
    @Query("SELECT * FROM parent_accounts WHERE id = 'primary_account' LIMIT 1")
    fun observeAccount(): Flow<ParentAccount?>

    @Query("SELECT * FROM parent_accounts WHERE id = 'primary_account' LIMIT 1")
    suspend fun getAccount(): ParentAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAccount(account: ParentAccount)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDefaultIfAbsent(account: ParentAccount)

    @Update
    suspend fun updateAccount(account: ParentAccount)

    @Query("UPDATE parent_accounts SET isLoggedIn = :isLoggedIn WHERE id = 'primary_account'")
    suspend fun setLoggedIn(isLoggedIn: Boolean)

    @Query("UPDATE parent_accounts SET email = :email, name = :name, firebaseUid = :uid, isLoggedIn = true WHERE id = 'primary_account'")
    suspend fun updateAuthProfile(email: String, name: String, uid: String?)
}
