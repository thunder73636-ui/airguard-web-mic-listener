package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.RemoteRequest
import kotlinx.coroutines.flow.Flow

@Dao
interface RemoteRequestDao {
    @Query("SELECT * FROM remote_requests WHERE deviceId = :deviceId ORDER BY timestamp DESC LIMIT 20")
    fun observeRequestsForDevice(deviceId: String): Flow<List<RemoteRequest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRequest(request: RemoteRequest)

    @Query("UPDATE remote_requests SET status = :status, details = :details WHERE id = :requestId")
    suspend fun updateRequestStatus(requestId: String, status: String, details: String)

    @Query("DELETE FROM remote_requests WHERE deviceId = :deviceId")
    suspend fun deleteRequestsForDevice(deviceId: String)
}
