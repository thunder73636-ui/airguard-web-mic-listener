package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SafetyDao {
    // Notification Logs
    @Query("SELECT * FROM notification_logs WHERE deviceId = :deviceId ORDER BY timestamp DESC")
    fun observeNotifications(deviceId: String): Flow<List<NotificationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(log: NotificationLog)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(logs: List<NotificationLog>)

    @Query("DELETE FROM notification_logs WHERE deviceId = :deviceId")
    suspend fun deleteNotificationsForDevice(deviceId: String)

    // Social Content Detection
    @Query("SELECT * FROM social_detection_logs WHERE deviceId = :deviceId ORDER BY timestamp DESC")
    fun observeSocialDetections(deviceId: String): Flow<List<SocialDetectionLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSocialDetection(log: SocialDetectionLog)

    @Query("DELETE FROM social_detection_logs WHERE deviceId = :deviceId")
    suspend fun deleteSocialDetectionsForDevice(deviceId: String)

    // Photo Detection
    @Query("SELECT * FROM photo_detection_logs WHERE deviceId = :deviceId ORDER BY timestamp DESC")
    fun observePhotoDetections(deviceId: String): Flow<List<PhotoDetectionLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhotoDetection(log: PhotoDetectionLog)

    @Query("DELETE FROM photo_detection_logs WHERE deviceId = :deviceId")
    suspend fun deletePhotoDetectionsForDevice(deviceId: String)

    // Snapshots
    @Query("SELECT * FROM snapshot_logs WHERE deviceId = :deviceId ORDER BY timestamp DESC")
    fun observeSnapshots(deviceId: String): Flow<List<SnapshotLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(log: SnapshotLog)

    @Query("DELETE FROM snapshot_logs WHERE deviceId = :deviceId")
    suspend fun deleteSnapshotsForDevice(deviceId: String)

    // Calls & SMS
    @Query("SELECT * FROM call_sms_logs WHERE deviceId = :deviceId ORDER BY timestamp DESC")
    fun observeCallSms(deviceId: String): Flow<List<CallSmsLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCallSms(logs: List<CallSmsLog>)

    @Query("DELETE FROM call_sms_logs WHERE deviceId = :deviceId")
    suspend fun deleteCallSmsForDevice(deviceId: String)

    // Web Filtering
    @Query("SELECT * FROM web_filter_rules WHERE deviceId = :deviceId")
    fun observeWebFilterRules(deviceId: String): Flow<List<WebFilterRule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWebRule(rule: WebFilterRule)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWebRules(rules: List<WebFilterRule>)

    @Query("DELETE FROM web_filter_rules WHERE deviceId = :deviceId")
    suspend fun deleteWebRulesForDevice(deviceId: String)

    @Query("DELETE FROM web_filter_rules WHERE id = :ruleId")
    suspend fun deleteWebRule(ruleId: String)

    // Browsing History
    @Query("SELECT * FROM browsing_logs WHERE deviceId = :deviceId ORDER BY lastVisitedTimestamp DESC")
    fun observeBrowsingLogs(deviceId: String): Flow<List<BrowsingLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBrowsingLogs(logs: List<BrowsingLog>)

    @Query("DELETE FROM browsing_logs WHERE deviceId = :deviceId")
    suspend fun deleteBrowsingLogsForDevice(deviceId: String)
}
