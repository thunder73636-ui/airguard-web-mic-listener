package com.example.data.manager

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.model.Device
import com.example.data.model.PairingSession
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.SecureRandom
import java.util.UUID

/**
 * PairingManager manages cryptographically secure random pairing tokens,
 * child device QR payload generation, and Firestore synchronization.
 */
class PairingManager(
    private val context: Context
) {
    private val secureRandom = SecureRandom()
    private val db = AppDatabase.getInstance(context)
    private val pairingDao = db.pairingDao()
    private val deviceDao = db.deviceDao()

    private val _cloudError = MutableStateFlow<String?>(null)

    /**
     * Non-null when the current pairing code could NOT be confirmed in Firestore
     * (the child app cannot find a code that is not in the cloud). Shown in the UI.
     */
    val cloudError: StateFlow<String?> = _cloudError.asStateFlow()

    private fun describe(e: Throwable): String {
        val code = (e as? com.google.firebase.firestore.FirebaseFirestoreException)?.code
        return when (code) {
            com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                "Firestore rejected the write (PERMISSION_DENIED). Deploy firestore.rules to database " +
                    "'${runCatching { context.getString(com.example.R.string.firestore_database_id) }.getOrNull()}', " +
                    "or check the API key / App Check restrictions."
            com.google.firebase.firestore.FirebaseFirestoreException.Code.UNAVAILABLE ->
                "Cannot reach Firestore. Check this phone's internet connection."
            com.google.firebase.firestore.FirebaseFirestoreException.Code.NOT_FOUND ->
                "Firestore database not found. Check firestore_database_id in firebase_applet_config.xml."
            else -> "Cloud sync failed: ${e.message}"
        }
    }

    /**
     * Resolves the Firestore instance safely using custom database ID.
     */
    fun getFirestore(): FirebaseFirestore? {
        return try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                val customDbId = try {
                    context.getString(com.example.R.string.firestore_database_id)
                } catch (_: Exception) {
                    null
                }
                if (!customDbId.isNullOrBlank()) {
                    FirebaseFirestore.getInstance(FirebaseApp.getInstance(), customDbId)
                } else {
                    FirebaseFirestore.getInstance()
                }
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase Firestore not available: ${e.message}")
            null
        }
    }

    /**
     * Generates a cryptographically secure random pairing token using SecureRandom.
     */
    fun generateSecurePairingToken(byteLength: Int = 32): String {
        val randomBytes = ByteArray(byteLength)
        secureRandom.nextBytes(randomBytes)
        val hexString = randomBytes.joinToString("") { "%02x".format(it) }
        return "ptk_$hexString"
    }

    /**
     * Generates a human-friendly, cryptographically secure 9-digit pairing code
     * formatted as three 3-digit groups (e.g. "492 817 305").
     */
    fun generateSecurePairingCode(): String {
        val part1 = 100 + secureRandom.nextInt(900)
        val part2 = 100 + secureRandom.nextInt(900)
        val part3 = 100 + secureRandom.nextInt(900)
        return "$part1 $part2 $part3"
    }

    /**
     * Generates the QR code payload URL for the child device.
     */
    fun generateQrCodePayload(
        token: String,
        pairingCode: String,
        deviceName: String,
        parentUid: String? = null
    ): String {
        val cleanCode = pairingCode.replace(" ", "")
        val encodedDevice = Uri.encode(deviceName.ifBlank { "Child Device" })
        val uid = parentUid ?: "parent_user"
        val timestamp = System.currentTimeMillis()
        return "https://apps.airdroid.com/kids/pair?token=$token&code=$cleanCode&device=$encodedDevice&parent=$uid&ts=$timestamp"
    }

    /**
     * Complete workflow:
     * 1. Generates cryptographically secure token and 9-digit code
     * 2. Generates QR payload URL
     * 3. Persists to local Room database for instantaneous UI feedback
     * 4. Persists to Firestore cloud collection for child discovery
     */
    suspend fun createAndStorePairingSession(
        deviceName: String,
        parentUid: String? = null
    ): PairingSession = withContext(Dispatchers.IO) {
        val token = generateSecurePairingToken(32)
        val code = generateSecurePairingCode()
        val qrPayload = generateQrCodePayload(token, code, deviceName, parentUid)
        val sessionId = "pair_" + UUID.randomUUID().toString().take(8)
        val expiresAt = System.currentTimeMillis() + 15 * 60 * 1000L
        val uid = parentUid ?: "parent_user"

        // 1. Create Room local entity
        val localSession = PairingSession(
            id = sessionId,
            code = code,
            qrPayload = qrPayload,
            deviceName = deviceName.ifBlank { "Child Device" },
            token = token,
            createdAt = System.currentTimeMillis(),
            expiresAt = expiresAt,
            status = "WAITING",
            parentUid = uid
        )
        pairingDao.clearSessions()
        pairingDao.insertPairingSession(localSession)

        // 2. Store in Firestore asynchronously
        _cloudError.value = null
        val firestore = getFirestore()
        if (firestore == null) {
            _cloudError.value = "Firebase is not initialised in this app, so the child app cannot see this code."
        } else {
            try {
                // set().await() only completes once the SERVER confirms the write; when the database
                // is unreachable it would hang forever and the UI would never get a session.
                val confirmed = withTimeoutOrNull(12_000L) {
                    firestore.collection(COLLECTION_PAIRING_SESSIONS)
                        .document(sessionId)
                        .set(localSession.toMap())
                        .await()
                    true
                }
                if (confirmed == null) {
                    _cloudError.value = "Code could not be confirmed on the server (timed out). " +
                        "Check internet, the database id, and Firestore rules."
                    Log.e(TAG, "Pairing session write timed out: $sessionId")
                } else {
                    Log.d(TAG, "Pairing session successfully stored in Firestore: $sessionId (Code: $code)")
                }
            } catch (e: Exception) {
                _cloudError.value = describe(e)
                Log.e(TAG, "Failed storing pairing session in Firestore: ${e.message}", e)
            }
        }
        localSession
    }

    /**
     * Realtime observer for Firestore pairing session status changes.
     * Emits the latest PairingSession whenever the child device scans or completes the handshake.
     */
    fun observeFirestorePairingSession(sessionId: String): Flow<PairingSession?> = callbackFlow {
        val firestore = getFirestore()
        if (firestore == null) {
            trySend(null)
            close()
            return@callbackFlow
        }
        var registration: ListenerRegistration? = null
        try {
            registration = firestore.collection(COLLECTION_PAIRING_SESSIONS)
                .document(sessionId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Error listening to pairing session: ${error.message}")
                        _cloudError.value = describe(error)
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val session = PairingSession(
                            id = snapshot.getString("id") ?: sessionId,
                            token = snapshot.getString("token") ?: "",
                            code = snapshot.getString("code") ?: "",
                            deviceName = snapshot.getString("deviceName") ?: "",
                            qrPayload = snapshot.getString("qrPayload") ?: "",
                            parentUid = snapshot.getString("parentUid") ?: "",
                            status = snapshot.getString("status") ?: "WAITING",
                            createdAt = snapshot.getLong("createdAt") ?: System.currentTimeMillis(),
                            expiresAt = snapshot.getLong("expiresAt") ?: (System.currentTimeMillis() + 15 * 60 * 1000L),
                            childDeviceId = snapshot.getString("childDeviceId"),
                            childModel = snapshot.getString("childModel"),
                            childAndroidVersion = snapshot.getString("childAndroidVersion")
                        )
                        trySend(session)
                    } else {
                        trySend(null)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to attach snapshot listener: ${e.message}")
            trySend(null)
        }
        awaitClose {
            registration?.remove()
        }
    }

    /**
     * Completes handshake from Firestore:
     * Reads child device document from Firestore 'devices/{childDeviceId}'
     * and saves it to local Room database, ensuring instant appearance in the Parent dashboard.
     */
    suspend fun completePairingFromFirestore(
        sessionId: String,
        childDeviceId: String
    ): Result<Device> = withContext(Dispatchers.IO) {
        try {
            val firestore = getFirestore()
            var device: Device? = null
            if (firestore != null) {
                val doc = firestore.collection(COLLECTION_DEVICES).document(childDeviceId).get().await()
                if (doc.exists()) {
                    device = Device(
                        id = doc.getString("id") ?: childDeviceId,
                        deviceName = doc.getString("deviceName")?.takeIf { it.isNotBlank() } ?: doc.getString("model")?.takeIf { it.isNotBlank() } ?: "Child Device",
                        model = doc.getString("model") ?: "Android Device",
                        androidVersion = doc.getString("androidVersion") ?: "Android",
                        ipAddress = doc.getString("ipAddress") ?: "",
                        batteryLevel = (doc.getLong("batteryLevel")?.toInt()) ?: 0,
                        isOnline = isRecentHeartbeat(
                            doc.getTimestamp("lastSeenServerAt")?.toDate()?.time ?: doc.getLong("lastSeenTimestamp")
                        ),
                        isLocked = doc.getBoolean("isLocked") ?: false,
                        screenTimeLimitMinutes = (doc.getLong("screenTimeLimitMinutes")?.toInt()) ?: 180,
                        todayUsageMinutes = (doc.getLong("todayUsageMinutes")?.toInt()) ?: 0,
                        webDailyLimitMinutes = (doc.getLong("webDailyLimitMinutes")?.toInt()) ?: 60,
                        latitude = doc.getDouble("latitude"),
                        longitude = doc.getDouble("longitude"),
                        address = doc.getString("address"),
                        locationTimestamp = doc.getLong("locationTimestamp") ?: 0L,
                        lastSeenTimestamp = doc.getTimestamp("lastSeenServerAt")?.toDate()?.time
                            ?: doc.getLong("lastSeenTimestamp") ?: 0L,
                        downtimeEnabled = doc.getBoolean("downtimeEnabled") ?: false,
                        downtimeStartHour = (doc.getLong("downtimeStartHour")?.toInt()) ?: 21,
                        downtimeStartMinute = (doc.getLong("downtimeStartMinute")?.toInt()) ?: 30,
                        downtimeEndHour = (doc.getLong("downtimeEndHour")?.toInt()) ?: 7,
                        downtimeEndMinute = (doc.getLong("downtimeEndMinute")?.toInt()) ?: 0,
                        downtimeDays = doc.getString("downtimeDays") ?: "Mon,Tue,Wed,Thu,Sun",
                        isAppManagementEnabled = doc.getBoolean("isAppManagementEnabled") ?: false,
                        unlockCountToday = (doc.getLong("unlockCountToday")?.toInt()) ?: 0,
                        notificationsCountToday = (doc.getLong("notificationsCountToday")?.toInt()) ?: 0,
                        hasAccessibilityPermission = doc.getBoolean("hasAccessibilityPermission") ?: false,
                        hasUsageStatsPermission = doc.getBoolean("hasUsageStatsPermission") ?: false,
                        hasNotificationPermission = doc.getBoolean("hasNotificationPermission") ?: false,
                        hasLocationPermission = doc.getBoolean("hasLocationPermission") ?: false,
                        hasCameraPermission = doc.getBoolean("hasCameraPermission") ?: false,
                        hasMicrophonePermission = doc.getBoolean("hasMicrophonePermission") ?: false,
                        hasPhoneStatePermission = doc.getBoolean("hasPhoneStatePermission") ?: false,
                        hasCallLogPermission = doc.getBoolean("hasCallLogPermission") ?: false,
                        hasPostNotificationsPermission = doc.getBoolean("hasPostNotificationsPermission") ?: false,
                        isIgnoringBatteryOptimizations = doc.getBoolean("isIgnoringBatteryOptimizations") ?: false,
                        hasAdminPermission = doc.getBoolean("hasAdminPermission") ?: false,
                        blockNewInstalls = doc.getBoolean("blockNewInstalls") ?: false,
                        alwaysAllowedApps = doc.getString("alwaysAllowedApps") ?: "Phone,Maps,Calculator",
                        preventUninstall = doc.getBoolean("preventUninstall") ?: false,
                        extraTimeRequestAt = doc.getLong("extraTimeRequestAt") ?: 0L,
                        extraTimeRequestHandledAt = doc.getLong("extraTimeRequestHandledAt") ?: 0L,
                        extraTimeUntil = doc.getLong("extraTimeUntil") ?: 0L,
                        parentUid = doc.getString("parentUid")
                    )
                }
            }

            if (device == null) return@withContext Result.failure(IllegalStateException("The child app has not created its Firestore device record yet. Do not add a device manually; pair from AirGuard Kids."))

            // Save to Room SQLite so dashboard immediately sees it
            deviceDao.insertOrUpdate(device)
            pairingDao.updatePaired(sessionId, "PAIRED", childDeviceId)

            Log.i(TAG, "Completed pairing for device $childDeviceId into local database")
            Result.success(device)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to complete pairing: ${e.message}", e)
            Result.failure(e)
        }
    }

    private fun isRecentHeartbeat(timestamp: Long?): Boolean {
        val lastSeen = timestamp ?: 0L
        val age = System.currentTimeMillis() - lastSeen
        return lastSeen > 0L && age in -60_000L..300_000L
    }

    suspend fun cancelPairingSession(sessionId: String) = withContext(Dispatchers.IO) {
        pairingDao.updateStatus(sessionId, "CANCELLED")
        val firestore = getFirestore()
        if (firestore != null) {
            try {
                firestore.collection(COLLECTION_PAIRING_SESSIONS)
                    .document(sessionId)
                    .update("status", "CANCELLED")
                    .await()
            } catch (e: Exception) {
                Log.w(TAG, "Firestore cancel update skipped: ${e.message}")
            }
        }
    }

    companion object {
        private const val TAG = "PairingManager"
        const val COLLECTION_PAIRING_SESSIONS = "pairing_sessions"
        const val COLLECTION_DEVICES = "devices"
    }
}
