package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
@Entity(tableName = "app_rules")
data class AppRule(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val packageName: String = "",
    val appName: String = "",
    val category: String = "App",
    val isBlocked: Boolean = false,
    val dailyLimitMinutes: Int = 60,
    val todayUsageMinutes: Int = 0
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "deviceId" to deviceId,
        "packageName" to packageName,
        "appName" to appName,
        "category" to category,
        "isBlocked" to isBlocked,
        "dailyLimitMinutes" to dailyLimitMinutes,
        "todayUsageMinutes" to todayUsageMinutes
    )
}
