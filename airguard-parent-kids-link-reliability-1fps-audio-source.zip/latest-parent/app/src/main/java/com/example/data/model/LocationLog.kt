package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
@Entity(tableName = "location_logs")
data class LocationLog(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val placeName: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "deviceId" to deviceId,
        "latitude" to latitude,
        "longitude" to longitude,
        "placeName" to placeName,
        "timestamp" to timestamp
    )
}
