package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
@Entity(tableName = "pairing_sessions")
data class PairingSession(
    @PrimaryKey val id: String = "",
    val code: String = "",
    val qrPayload: String = "",
    val deviceName: String = "",
    val token: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 15 * 60 * 1000L,
    val status: String = "WAITING", // WAITING, PAIRED, EXPIRED, CANCELLED
    val parentUid: String = "",
    val childDeviceId: String? = null,
    val childModel: String? = null,
    val childAndroidVersion: String? = null
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "code" to code,
        "qrPayload" to qrPayload,
        "deviceName" to deviceName,
        "token" to token,
        "createdAt" to createdAt,
        "expiresAt" to expiresAt,
        "status" to status,
        "parentUid" to parentUid,
        "childDeviceId" to childDeviceId,
        "childModel" to childModel,
        "childAndroidVersion" to childAndroidVersion
    )
}
