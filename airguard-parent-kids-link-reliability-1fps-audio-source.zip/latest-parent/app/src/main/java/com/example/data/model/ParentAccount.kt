package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
@Entity(tableName = "parent_accounts")
data class ParentAccount(
    @PrimaryKey val id: String = "primary_account",
    val email: String = "parent@airguard.com",
    val name: String = "Sarah Miller",
    val isLoggedIn: Boolean = true,
    val firebaseUid: String? = null,
    val photoUrl: String? = null,
    val biometricUnlockEnabled: Boolean = false,
    val suspiciousKeywordFilter: Boolean = true,
    val explicitContentFilter: Boolean = true
)
