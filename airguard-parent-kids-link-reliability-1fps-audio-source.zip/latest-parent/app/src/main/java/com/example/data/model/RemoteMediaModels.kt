package com.example.data.model

import com.google.firebase.firestore.IgnoreExtraProperties

enum class MediaSessionState {
    IDLE,
    CONNECTING,
    OFFER_SENT,
    ANSWER_RECEIVED,
    CONNECTED,
    RECONNECTING,
    DISCONNECTED,
    FAILED,
    PERMISSION_DENIED,
    DEVICE_OFFLINE
}

enum class DiagnosticStageStatus(val displayLabel: String) {
    NOT_STARTED("Not started"),
    WAITING("Waiting for the other device"),
    CONNECTED_NO_MEDIA("Connected without media"),
    RECEIVING_MEDIA("Receiving media"),
    PLAYBACK_OR_RENDER_FAILED("Playback or rendering failed"),
    CONNECTION_FAILED("Connection failed")
}

data class MediaDiagnostics(
    val streamType: String = "CAMERA", // CAMERA or ONE_WAY_AUDIO
    val overallStatus: DiagnosticStageStatus = DiagnosticStageStatus.NOT_STARTED,
    val peerConnectionState: String = "NEW",
    val iceConnectionState: String = "NEW",
    val signalingState: String = "STABLE",
    // Camera Pipeline: Request → Session → Remote track → Frames received → Renderer status
    val requestDispatched: Boolean = false,
    val sessionCreated: Boolean = false,
    val remoteVideoTrackReceived: Boolean = false,
    val videoFramesReceivedCount: Long = 0,
    val rendererStatus: String = "Not initialized",
    // Audio Pipeline: Request → Session → Remote track → Incoming audio → Playback status
    val remoteAudioTrackReceived: Boolean = false,
    val audioTrackEnabled: Boolean = false,
    val audioTrackUnmuted: Boolean = false,
    val audioBytesReceivedCount: Long = 0,
    val audioFocusGranted: Boolean = false,
    val audioRoutingMode: String = "NORMAL",
    val audioPlaybackStatus: String = "Idle",
    // Telemetry & Timing
    val elapsedSeconds: Long = 0,
    val lastExceptionMessage: String? = null,
    val lastErrorTimestamp: Long = 0
)

@IgnoreExtraProperties
data class SdpPayload(
    val type: String = "", // "offer" or "answer"
    val sdp: String = ""
)

@IgnoreExtraProperties
data class IceCandidatePayload(
    val sdpMid: String? = null,
    val sdpMLineIndex: Int = 0,
    val candidate: String = ""
)

@IgnoreExtraProperties
data class RemoteMediaSession(
    val id: String = "",
    val deviceId: String = "",
    val type: String = "CAMERA", // CAMERA, ONE_WAY_AUDIO, SCREEN_MIRROR
    val status: String = "PENDING_CONSENT", // PENDING_CONSENT, CONNECTED, DISCONNECTED, FAILED
    val sdpOffer: String? = null,
    val sdpAnswer: String? = null,
    val candidates: List<Map<String, Any>> = emptyList(),
    val details: String = "",
    val lastHandshake: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "deviceId" to deviceId,
        "type" to type,
        "status" to status,
        "sdpOffer" to sdpOffer,
        "sdpAnswer" to sdpAnswer,
        "candidates" to candidates,
        "details" to details,
        "lastHandshake" to lastHandshake,
        "createdAt" to createdAt
    )
}
