package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
@Entity(tableName = "remote_requests")
data class RemoteRequest(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val type: String = "", // CAMERA, SCREEN_MIRROR, ONE_WAY_AUDIO
    val status: String = "PENDING_CONSENT", // PENDING_CONSENT, CHILD_CLIENT_REQUIRED, CONNECTED, FAILED
    val timestamp: Long = System.currentTimeMillis(),
    val details: String = "",
    val parentUid: String = ""
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "deviceId" to deviceId,
        "type" to type,
        "status" to status,
        "timestamp" to timestamp,
        "details" to details,
        "parentUid" to parentUid
    )
}
