package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
@Entity(tableName = "notification_logs")
data class NotificationLog(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val appName: String = "",
    val packageName: String = "",
    val sender: String = "",
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isFlagged: Boolean = false
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "deviceId" to deviceId,
        "appName" to appName,
        "packageName" to packageName,
        "sender" to sender,
        "content" to content,
        "timestamp" to timestamp,
        "isFlagged" to isFlagged
    )
}

@IgnoreExtraProperties
@Entity(tableName = "social_detection_logs")
data class SocialDetectionLog(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val platform: String = "App", // TikTok, Instagram, WhatsApp, YouTube
    val keyword: String = "",
    val snippet: String = "",
    val riskLevel: String = "Low", // High, Medium, Low
    val timestamp: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
@Entity(tableName = "photo_detection_logs")
data class PhotoDetectionLog(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val fileName: String = "",
    val category: String = "Safe", // Explicit, Violence, Safe
    val flaggedReason: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isReviewed: Boolean = false
)

@IgnoreExtraProperties
@Entity(tableName = "snapshot_logs")
data class SnapshotLog(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val type: String = "SCREEN", // SCREEN, CAMERA_FRONT, CAMERA_REAR
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "CAPTURED"
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "deviceId" to deviceId,
        "type" to type,
        "timestamp" to timestamp,
        "status" to status
    )
}

@IgnoreExtraProperties
@Entity(tableName = "call_sms_logs")
data class CallSmsLog(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val contactName: String = "",
    val phoneNumber: String = "",
    val type: String = "INCOMING_CALL", // INCOMING_CALL, OUTGOING_CALL, INCOMING_SMS, OUTGOING_SMS
    val durationOrBody: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "deviceId" to deviceId,
        "contactName" to contactName,
        "phoneNumber" to phoneNumber,
        "type" to type,
        "durationOrBody" to durationOrBody,
        "timestamp" to timestamp
    )
}

@IgnoreExtraProperties
@Entity(tableName = "web_filter_rules")
data class WebFilterRule(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val urlPattern: String = "",
    val isBlocked: Boolean = true,
    val category: String = "Custom Blacklist"
)

@IgnoreExtraProperties
@Entity(tableName = "browsing_logs")
data class BrowsingLog(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val url: String = "",
    val title: String = "",
    val visitCount: Int = 1,
    val lastVisitedTimestamp: Long = System.currentTimeMillis(),
    val isBlocked: Boolean = false
)
