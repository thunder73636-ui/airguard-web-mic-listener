package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.model.ParentAccount
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNot
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class UserProfile(
    val uid: String,
    val email: String,
    val displayName: String,
    val photoUrl: String? = null
)

sealed interface AuthUiState {
    data object Loading : AuthUiState
    data class Authenticated(val user: UserProfile) : AuthUiState
    data class Unauthenticated(val lastError: String? = null) : AuthUiState
}

class AuthRepository(private val context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val accountDao = db.parentAccountDao()
    private val coroutineScope = CoroutineScope(Dispatchers.IO)
    private val credentialManager = CredentialManager.create(context)

    val firebaseAuth: FirebaseAuth? by lazy {
        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                FirebaseAuth.getInstance()
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseAuth initialization deferred: ${e.message}")
            null
        }
    }

    private val _authState = MutableStateFlow<AuthUiState>(AuthUiState.Loading)
    val authState: StateFlow<AuthUiState> = _authState.asStateFlow()

    init {
        // Observe Firebase Auth State
        firebaseAuth?.addAuthStateListener { auth ->
            val user = auth.currentUser
            if (user != null) {
                val profile = user.toProfile()
                _authState.value = AuthUiState.Authenticated(profile)
                coroutineScope.launch {
                    accountDao.updateAuthProfile(
                        email = profile.email,
                        name = profile.displayName,
                        uid = profile.uid
                    )
                }
            } else {
                coroutineScope.launch {
                    val local = accountDao.getAccount()
                    if (local?.isLoggedIn == true) {
                        _authState.value = AuthUiState.Authenticated(
                            UserProfile(
                                uid = local.firebaseUid ?: "parent_user",
                                email = local.email,
                                displayName = local.name
                            )
                        )
                    } else {
                        _authState.value = AuthUiState.Unauthenticated()
                    }
                }
            }
        } ?: run {
            coroutineScope.launch {
                val local = accountDao.getAccount()
                if (local?.isLoggedIn == true) {
                    _authState.value = AuthUiState.Authenticated(
                        UserProfile(
                    uid = local.firebaseUid ?: "parent_user",
                            email = local.email,
                            displayName = local.name
                        )
                    )
                } else {
                    _authState.value = AuthUiState.Unauthenticated()
                }
            }
        }
    }

    fun getCurrentUid(): String {
        return firebaseAuth?.currentUser?.uid
            ?: (_authState.value as? AuthUiState.Authenticated)?.user?.uid
            ?: "parent_user"
    }

    /** Wait for the persisted sign-in state before creating an owner-tagged pairing record. */
    suspend fun getResolvedUid(): String {
        firebaseAuth?.currentUser?.uid?.let { return it }
        val persisted = accountDao.getAccount()
        persisted?.takeIf { it.isLoggedIn }?.firebaseUid?.takeIf { it.isNotBlank() }?.let { return it }
        val state = authState.filterNot { it == AuthUiState.Loading }.first()
        return (state as? AuthUiState.Authenticated)?.user?.uid ?: "parent_user"
    }

    suspend fun signInWithGoogle(activity: Activity): Result<UserProfile> {
        val auth = firebaseAuth ?: return Result.failure(IllegalStateException("Firebase Auth unavailable"))
        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            return Result.failure(IllegalStateException("default_web_client_id not found: ${e.message}"))
        }

        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

        return try {
            val result = credentialManager.getCredential(activity, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                val authResult = auth.signInWithCredential(authCredential).await()
                val user = authResult.user ?: throw IllegalStateException("Firebase user was null after Google Sign-In")
                val profile = user.toProfile()
                _authState.value = AuthUiState.Authenticated(profile)
                accountDao.updateAuthProfile(profile.email, profile.displayName, profile.uid)
                Result.success(profile)
            } else {
                Result.failure(IllegalArgumentException("Unexpected credential type received"))
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Google Sign-In cancelled: ${e.message}")
            Result.failure(e)
        } catch (e: NoCredentialException) {
            Log.w(TAG, "No eligible Google account is available: ${e.message}")
            Result.failure(IllegalStateException("No Google account is available on this device. Add an account and try again.", e))
        } catch (e: Exception) {
            Log.e(TAG, "Google Sign-In failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun signOut(): Result<Unit> {
        return try {
            firebaseAuth?.signOut()
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w(TAG, "Failed clearing credential state: ${e.message}")
            }
            accountDao.setLoggedIn(false)
            _authState.value = AuthUiState.Unauthenticated()
            Result.success(Unit)
        } catch (e: Exception) {
            accountDao.setLoggedIn(false)
            _authState.value = AuthUiState.Unauthenticated()
            Result.failure(e)
        }
    }

    private fun FirebaseUser.toProfile(): UserProfile {
        return UserProfile(
            uid = uid,
            email = email ?: "parent@airguard.com",
            displayName = displayName?.ifBlank { "Parent User" } ?: "Parent User",
            photoUrl = photoUrl?.toString()
        )
    }

    companion object {
        private const val TAG = "AuthRepository"
    }
}
