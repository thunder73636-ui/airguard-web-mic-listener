package com.example.data.repository

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.data.local.AppDatabase
import com.example.data.manager.PairingManager
import com.example.data.model.*
import com.example.media.MediaSignalingManager
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

class ParentRepository(private val context: Context) {
    private val db = AppDatabase.getInstance(context)
    val deviceDao = db.deviceDao()
    private val appRuleDao = db.appRuleDao()
    private val pairingDao = db.pairingDao()
    private val locationLogDao = db.locationLogDao()
    private val remoteRequestDao = db.remoteRequestDao()
    private val accountDao = db.parentAccountDao()
    private val safetyDao = db.safetyDao()
    private val unlinkPrefs = context.getSharedPreferences("airguard_parent_pending_unlinks", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.IO)
    val authRepository = AuthRepository(context)
    val pairingManager = PairingManager(context)

    private val activeFirestoreListeners = mutableMapOf<String, ListenerRegistration>()
    private var allDevicesListener: ListenerRegistration? = null
    private var deviceListenerRetryJob: Job? = null
    private var deviceListenerRetryAttempt = 0
    private val onlineStates = mutableMapOf<String, Boolean>()
    private val onlineStateLock = Any()
    @Volatile private var hasSeededOnlineStates = false

    enum class DeleteDeviceResult { REMOVED_FROM_CLOUD, REMOVED_LOCALLY_PENDING_SYNC }

    init {
        // Sync any existing devices from Firestore on initialization
        scope.launch {
            syncAllDevicesFromFirestore()
            retryPendingUnlinks()
            startGlobalDevicesListener()
            while (true) {
                delay(30_000L)
                for (device in deviceDao.getAllDevices()) {
                    val fresh = isFreshHeartbeat(device.lastSeenTimestamp)
                    synchronized(onlineStateLock) { onlineStates[device.id] = fresh }
                    if (fresh != device.isOnline) {
                        deviceDao.updateConnectionStatus(device.id, fresh, device.batteryLevel, device.lastSeenTimestamp)
                    }
                }
            }
        }
        registerPendingUnlinkNetworkRetry()
    }

    fun getFirestore(): FirebaseFirestore? = pairingManager.getFirestore()

    fun createMediaSignalingManager(): MediaSignalingManager =
        MediaSignalingManager(context, getFirestore())

    /**
     * Starts listening to Firestore 'devices' collection.
     * When any child device writes telemetry (battery, online status, GPS, etc.),
     * it immediately updates the local Room database, which reactively updates all Compose UI screens.
     */
    fun startGlobalDevicesListener() {
        val firestore = getFirestore() ?: return
        if (authRepository.authState.value == AuthUiState.Loading) {
            scope.launch {
                authRepository.getResolvedUid()
                startGlobalDevicesListener()
            }
            return
        }
        synchronized(this) {
            deviceListenerRetryJob?.cancel()
            deviceListenerRetryJob = null
        }
        val parentUid = authRepository.getCurrentUid()
        allDevicesListener?.remove()

        try {
            allDevicesListener = firestore.collection("devices")
                .whereEqualTo("parentUid", parentUid)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Error in devices snapshot listener: ${error.message}")
                        scheduleDevicesListenerRetry()
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val fromServer = !snapshot.metadata.isFromCache
                        if (fromServer) synchronized(this) {
                            deviceListenerRetryAttempt = 0
                            deviceListenerRetryJob?.cancel()
                            deviceListenerRetryJob = null
                        }
                        scope.launch {
                            if (fromServer) synchronized(onlineStateLock) {
                                if (!hasSeededOnlineStates) {
                                    snapshot.documents.forEach { doc ->
                                        val id = doc.getString("id") ?: doc.id
                                        onlineStates[id] = isFreshHeartbeat(deviceLastSeenTimestamp(doc))
                                    }
                                    hasSeededOnlineStates = true
                                } else {
                                    snapshot.documentChanges.forEach { change ->
                                        val doc = change.document
                                        val id = doc.getString("id") ?: doc.id
                                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                            onlineStates.remove(id)
                                        } else {
                                            val online = isFreshHeartbeat(deviceLastSeenTimestamp(doc))
                                            val wasOnline = onlineStates.put(id, online)
                                            if (wasOnline != true && online) {
                                                postChildOnlineNotification(id, doc.getString("deviceName") ?: "Child Device")
                                            }
                                        }
                                    }
                                }
                            }
                            for (change in snapshot.documentChanges) {
                                val doc = change.document
                                if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                    val removedId = doc.getString("id") ?: doc.id
                                    clearPendingUnlink(removedId)
                                    removeChildTelemetryListeners(removedId)
                                    deleteLocalDeviceData(removedId)
                                    continue
                                }
                                try {
                                    val devId = doc.getString("id") ?: doc.id
                                    if (devId in pendingUnlinkIds()) {
                                        scope.launch { retryPendingUnlinks() }
                                        continue
                                    }
                                    val device = Device(
                                        id = devId,
                                        deviceName = doc.getString("deviceName") ?: "Child Device",
                                        model = doc.getString("model") ?: "Android Phone",
                                        androidVersion = doc.getString("androidVersion") ?: "Android 14 (API 34)",
                                        ipAddress = doc.getString("ipAddress") ?: "",
                                        batteryLevel = (doc.getLong("batteryLevel")?.toInt()) ?: 0,
                isOnline = isFreshHeartbeat(deviceLastSeenTimestamp(doc)),
                                        isLocked = doc.getBoolean("isLocked") ?: false,
                                        screenTimeLimitMinutes = (doc.getLong("screenTimeLimitMinutes")?.toInt()) ?: 180,
                                        todayUsageMinutes = (doc.getLong("todayUsageMinutes")?.toInt()) ?: 0,
                                        webDailyLimitMinutes = (doc.getLong("webDailyLimitMinutes")?.toInt()) ?: 60,
                                        latitude = doc.getDouble("latitude"),
                                        longitude = doc.getDouble("longitude"),
                                        address = doc.getString("address"),
                                        locationTimestamp = doc.getLong("locationTimestamp") ?: 0L,
                                        lastSeenTimestamp = deviceLastSeenTimestamp(doc),
                                        downtimeEnabled = doc.getBoolean("downtimeEnabled") ?: false,
                                        downtimeStartHour = (doc.getLong("downtimeStartHour")?.toInt()) ?: 21,
                                        downtimeStartMinute = (doc.getLong("downtimeStartMinute")?.toInt()) ?: 30,
                                        downtimeEndHour = (doc.getLong("downtimeEndHour")?.toInt()) ?: 7,
                                        downtimeEndMinute = (doc.getLong("downtimeEndMinute")?.toInt()) ?: 0,
                                        downtimeDays = doc.getString("downtimeDays") ?: "Mon,Tue,Wed,Thu,Sun",
                                        isAppManagementEnabled = doc.getBoolean("isAppManagementEnabled") ?: false,
                                        unlockCountToday = (doc.getLong("unlockCountToday")?.toInt()) ?: 0,
                                        notificationsCountToday = (doc.getLong("notificationsCountToday")?.toInt()) ?: 0,
                                        hasAccessibilityPermission = doc.getBoolean("hasAccessibilityPermission") ?: false,
                                        hasUsageStatsPermission = doc.getBoolean("hasUsageStatsPermission") ?: false,
                                        hasNotificationPermission = doc.getBoolean("hasNotificationPermission") ?: false,
                                        hasLocationPermission = doc.getBoolean("hasLocationPermission") ?: false,
                                        hasCameraPermission = doc.getBoolean("hasCameraPermission") ?: false,
                                        hasMicrophonePermission = doc.getBoolean("hasMicrophonePermission") ?: false,
                                        hasPhoneStatePermission = doc.getBoolean("hasPhoneStatePermission") ?: false,
                                        hasCallLogPermission = doc.getBoolean("hasCallLogPermission") ?: false,
                                        hasPostNotificationsPermission = doc.getBoolean("hasPostNotificationsPermission") ?: false,
                                        isIgnoringBatteryOptimizations = doc.getBoolean("isIgnoringBatteryOptimizations") ?: false,
                                        hasAdminPermission = doc.getBoolean("hasAdminPermission") ?: false,
                                        blockNewInstalls = doc.getBoolean("blockNewInstalls") ?: false,
                                        alwaysAllowedApps = doc.getString("alwaysAllowedApps") ?: "Phone,Maps,Calculator",
                                        preventUninstall = doc.getBoolean("preventUninstall") ?: false,
                                        extraTimeRequestAt = doc.getLong("extraTimeRequestAt") ?: 0L,
                                        extraTimeRequestHandledAt = doc.getLong("extraTimeRequestHandledAt") ?: 0L,
                                        extraTimeUntil = doc.getLong("extraTimeUntil") ?: 0L,
                                        parentUid = doc.getString("parentUid")
                                    )
                                    deviceDao.insertOrUpdate(device)
                                    // Start telemetry sub-listeners for this child device
                                    attachChildTelemetryListeners(devId)
                                } catch (e: Exception) {
                                    Log.w(TAG, "Failed to parse child device from Firestore: ${e.message}")
                                }
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to attach global devices listener: ${e.message}")
        }
    }

    @Synchronized
    private fun scheduleDevicesListenerRetry() {
        if (deviceListenerRetryJob?.isActive == true) return
        val attempt = deviceListenerRetryAttempt.coerceAtMost(5)
        val waitMs = (1_000L shl attempt).coerceAtMost(30_000L)
        deviceListenerRetryAttempt = (deviceListenerRetryAttempt + 1).coerceAtMost(6)
        deviceListenerRetryJob = scope.launch {
            delay(waitMs)
            synchronized(this@ParentRepository) { deviceListenerRetryJob = null }
            if (authRepository.authState.value != AuthUiState.Loading) startGlobalDevicesListener()
        }
    }

    private fun postChildOnlineNotification(deviceId: String, deviceName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHILD_ONLINE_CHANNEL, "Child device status", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val openApp = Intent(context, com.example.MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context, deviceId.hashCode(), openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        runCatching {
            NotificationManagerCompat.from(context).notify(
                deviceId.hashCode(),
                NotificationCompat.Builder(context, CHILD_ONLINE_CHANNEL)
                    .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                    .setContentTitle("Child is online")
                    .setContentText("$deviceName is connected")
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .build()
            )
        }.onFailure { Log.w(TAG, "Could not show child online notification: ${it.message}") }
    }

    /**
     * Attaches sub-listeners for a child device (Locations, Notifications, Calls/SMS)
     */
    fun attachChildTelemetryListeners(deviceId: String) {
        val firestore = getFirestore() ?: return
        if (activeFirestoreListeners.containsKey(deviceId)) return

        try {
            // 1. Listen for new location logs
            val locReg = firestore.collection("locations").document(deviceId).collection("logs")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    scope.launch {
                        val logs = snapshot.documents.mapNotNull { doc ->
                            try {
                                LocationLog(
                                    id = doc.getString("id") ?: doc.id,
                                    deviceId = deviceId,
                                    latitude = doc.getDouble("latitude") ?: return@mapNotNull null,
                                    longitude = doc.getDouble("longitude") ?: return@mapNotNull null,
                                    placeName = doc.getString("placeName") ?: "Current Location",
                                    timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                                )
                            } catch (e: Exception) { null }
                        }
                        if (logs.isNotEmpty()) {
                            locationLogDao.insertAll(logs)
                        }
                    }
                }
            activeFirestoreListeners["${deviceId}_loc"] = locReg

            // 2. Listen for notification logs
            val notifReg = firestore.collection("notification_logs")
                .whereEqualTo("deviceId", deviceId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Notification listener failed for $deviceId: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot == null) return@addSnapshotListener
                    scope.launch {
                        val notifs = snapshot.documents.mapNotNull { doc ->
                            try {
                                NotificationLog(
                                    id = doc.getString("id") ?: doc.id,
                                    deviceId = deviceId,
                                    appName = doc.getString("appName") ?: "Notification",
                                    packageName = doc.getString("packageName") ?: "",
                                    sender = doc.getString("sender") ?: "Sender",
                                    content = doc.getString("content") ?: "",
                                    timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                    isFlagged = doc.getBoolean("isFlagged") ?: false
                                )
                            } catch (e: Exception) { null }
                        }
                        if (notifs.isNotEmpty()) {
                            safetyDao.insertNotifications(notifs)
                        }
                    }
                }
            activeFirestoreListeners["${deviceId}_notif"] = notifReg

            // 3. Listen for call/SMS logs
            val callReg = firestore.collection("call_sms_logs")
                .whereEqualTo("deviceId", deviceId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Call-log listener failed for $deviceId: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot == null) return@addSnapshotListener
                    scope.launch {
                        val calls = snapshot.documents.mapNotNull { doc ->
                            try {
                                CallSmsLog(
                                    id = doc.getString("id") ?: doc.id,
                                    deviceId = deviceId,
                                    contactName = doc.getString("contactName") ?: "Unknown",
                                    phoneNumber = doc.getString("phoneNumber") ?: "",
                                    type = doc.getString("type") ?: "INCOMING_CALL",
                                    durationOrBody = doc.getString("durationOrBody") ?: "",
                                    timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                                )
                            } catch (e: Exception) { null }
                        }
                        if (calls.isNotEmpty()) {
                            safetyDao.insertCallSms(calls)
                        }
                    }
                }
            activeFirestoreListeners["${deviceId}_call"] = callReg
            activeFirestoreListeners[deviceId] = locReg

            // Installed-app rules are authored on the child and controlled from the parent.
            val appRulesReg = firestore.collection("app_rules")
                .whereEqualTo("deviceId", deviceId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) {
                        if (error != null) Log.w(TAG, "App rules listener failed for $deviceId: ${error.message}")
                        return@addSnapshotListener
                    }
                    scope.launch {
                        val rules = snapshot.documents.mapNotNull { doc ->
                            val pkg = doc.getString("packageName") ?: return@mapNotNull null
                            AppRule(
                                id = doc.getString("id") ?: doc.id,
                                deviceId = deviceId,
                                packageName = pkg,
                                appName = doc.getString("appName") ?: pkg,
                                category = doc.getString("category") ?: "App",
                                isBlocked = doc.getBoolean("isBlocked") ?: false,
                                dailyLimitMinutes = (doc.getLong("dailyLimitMinutes")?.toInt()) ?: 0,
                                todayUsageMinutes = (doc.getLong("todayUsageMinutes")?.toInt()) ?: 0
                            )
                        }
                        if (rules.isNotEmpty()) appRuleDao.insertAll(rules)
                    }
                }
            activeFirestoreListeners["${deviceId}_apps"] = appRulesReg

            // Web rules are kept in the same cloud project so the child can apply them in the
            // supervised browser. Third-party browser history is not exposed by Android.
            val webRulesReg = firestore.collection("web_filter_rules")
                .whereEqualTo("deviceId", deviceId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) {
                        if (error != null) Log.w(TAG, "Web rules listener failed for $deviceId: ${error.message}")
                        return@addSnapshotListener
                    }
                    scope.launch {
                        safetyDao.deleteWebRulesForDevice(deviceId)
                        val rules = snapshot.documents.mapNotNull { doc ->
                            val pattern = doc.getString("urlPattern") ?: return@mapNotNull null
                            WebFilterRule(
                                id = doc.getString("id") ?: doc.id,
                                deviceId = deviceId,
                                urlPattern = pattern,
                                isBlocked = doc.getBoolean("isBlocked") ?: true,
                                category = doc.getString("category") ?: "Custom"
                            )
                        }
                        if (rules.isNotEmpty()) safetyDao.insertWebRules(rules)
                    }
                }
            activeFirestoreListeners["${deviceId}_web"] = webRulesReg
        } catch (e: Exception) {
            Log.w(TAG, "Error attaching child telemetry listeners: ${e.message}")
        }
    }

    private fun removeChildTelemetryListeners(deviceId: String) {
        val keys = activeFirestoreListeners.keys.filter { it == deviceId || it.startsWith("${deviceId}_") }
        keys.forEach { key ->
            activeFirestoreListeners.remove(key)?.remove()
        }
    }

    /**
     * One-time sync of all devices from Firestore into Room.
     */
    suspend fun syncAllDevicesFromFirestore() {
        retryPendingUnlinks()
        val firestore = getFirestore() ?: return
        try {
            val parentUid = authRepository.getResolvedUid()
            if (parentUid != "parent_user") {
                runCatching { claimGuestLinkedDevicesForAccount(parentUid) }
                    .onFailure { Log.w(TAG, "Could not claim legacy child links for $parentUid: ${it.message}") }
            }
            val query = firestore.collection("devices")
                .whereEqualTo("parentUid", parentUid)
                .get(Source.SERVER).await()
            // A one-shot query can race pairing or return a partial result. Never delete local
            // devices from absence in this query; the live listener and explicit unlink own removal.
            for (doc in query.documents) {
                val devId = doc.getString("id") ?: doc.id
                if (devId in pendingUnlinkIds()) {
                    scope.launch { retryPendingUnlinks() }
                    continue
                }
                val device = Device(
                    id = devId,
                    deviceName = doc.getString("deviceName")?.takeIf { it.isNotBlank() } ?: doc.getString("model")?.takeIf { it.isNotBlank() } ?: "Child Device",
                    model = doc.getString("model") ?: "Android Phone",
                    androidVersion = doc.getString("androidVersion") ?: "Android 14 (API 34)",
                    ipAddress = doc.getString("ipAddress") ?: "",
                    batteryLevel = (doc.getLong("batteryLevel")?.toInt()) ?: 0,
                    isOnline = isFreshHeartbeat(deviceLastSeenTimestamp(doc)),
                    isLocked = doc.getBoolean("isLocked") ?: false,
                    screenTimeLimitMinutes = (doc.getLong("screenTimeLimitMinutes")?.toInt()) ?: 180,
                    todayUsageMinutes = (doc.getLong("todayUsageMinutes")?.toInt()) ?: 0,
                    webDailyLimitMinutes = (doc.getLong("webDailyLimitMinutes")?.toInt()) ?: 60,
                    latitude = doc.getDouble("latitude"),
                    longitude = doc.getDouble("longitude"),
                    address = doc.getString("address"),
                    locationTimestamp = doc.getLong("locationTimestamp") ?: 0L,
                    lastSeenTimestamp = deviceLastSeenTimestamp(doc),
                    downtimeEnabled = doc.getBoolean("downtimeEnabled") ?: false,
                    downtimeStartHour = (doc.getLong("downtimeStartHour")?.toInt()) ?: 21,
                    downtimeStartMinute = (doc.getLong("downtimeStartMinute")?.toInt()) ?: 30,
                    downtimeEndHour = (doc.getLong("downtimeEndHour")?.toInt()) ?: 7,
                    downtimeEndMinute = (doc.getLong("downtimeEndMinute")?.toInt()) ?: 0,
                    downtimeDays = doc.getString("downtimeDays") ?: "Mon,Tue,Wed,Thu,Sun",
                    isAppManagementEnabled = doc.getBoolean("isAppManagementEnabled") ?: false,
                    unlockCountToday = (doc.getLong("unlockCountToday")?.toInt()) ?: 0,
                    notificationsCountToday = (doc.getLong("notificationsCountToday")?.toInt()) ?: 0,
                    hasAccessibilityPermission = doc.getBoolean("hasAccessibilityPermission") ?: false,
                    hasUsageStatsPermission = doc.getBoolean("hasUsageStatsPermission") ?: false,
                    hasNotificationPermission = doc.getBoolean("hasNotificationPermission") ?: false,
                    hasLocationPermission = doc.getBoolean("hasLocationPermission") ?: false,
                    hasCameraPermission = doc.getBoolean("hasCameraPermission") ?: false,
                    hasMicrophonePermission = doc.getBoolean("hasMicrophonePermission") ?: false,
                    hasPhoneStatePermission = doc.getBoolean("hasPhoneStatePermission") ?: false,
                    hasCallLogPermission = doc.getBoolean("hasCallLogPermission") ?: false,
                    hasPostNotificationsPermission = doc.getBoolean("hasPostNotificationsPermission") ?: false,
                    isIgnoringBatteryOptimizations = doc.getBoolean("isIgnoringBatteryOptimizations") ?: false,
                    hasAdminPermission = doc.getBoolean("hasAdminPermission") ?: false,
                    blockNewInstalls = doc.getBoolean("blockNewInstalls") ?: false,
                    alwaysAllowedApps = doc.getString("alwaysAllowedApps") ?: "Phone,Maps,Calculator",
                    preventUninstall = doc.getBoolean("preventUninstall") ?: false,
                    extraTimeRequestAt = doc.getLong("extraTimeRequestAt") ?: 0L,
                    extraTimeRequestHandledAt = doc.getLong("extraTimeRequestHandledAt") ?: 0L,
                    extraTimeUntil = doc.getLong("extraTimeUntil") ?: 0L,
                    parentUid = doc.getString("parentUid")
                )
                deviceDao.insertOrUpdate(device)
                attachChildTelemetryListeners(devId)
            }
            Log.d(TAG, "Synced ${query.size()} devices from Firestore")
        } catch (e: Exception) {
            Log.w(TAG, "Failed syncing devices from Firestore: ${e.message}")
        }
    }

    // Devices
    fun observeDevices(): Flow<List<Device>> = combine(deviceDao.observeAllDevices(), authRepository.authState) { devices, state ->
        devicesVisibleToParent(devices, state)
    }
    fun observeDeviceById(deviceId: String): Flow<Device?> = deviceDao.observeDeviceById(deviceId)
    suspend fun getDeviceById(deviceId: String): Device? = deviceDao.getDeviceById(deviceId)

    /** Attach child links created in local fallback mode to the signed-in Google account. */
    suspend fun claimGuestLinkedDevicesForAccount(parentUid: String): Int {
        require(parentUid.isNotBlank() && parentUid != "parent_user") { "A signed-in Google account is required." }
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; child links could not be saved to this account.")
        val legacyDevices = deviceDao.getAllDevices().filter {
            it.parentUid == "parent_user" || it.parentUid.isNullOrBlank()
        }
        var claimedCount = 0
        for (device in legacyDevices) {
            val ref = firestore.collection("devices").document(device.id)
            val claimed = firestore.runTransaction { transaction ->
                val snapshot = transaction.get(ref)
                if (!snapshot.exists()) {
                    false
                } else {
                    val cloudOwner = snapshot.getString("parentUid")
                    when {
                        cloudOwner == parentUid -> true
                        cloudOwner == "parent_user" || cloudOwner.isNullOrBlank() -> {
                            transaction.update(ref, "parentUid", parentUid)
                            true
                        }
                        else -> false
                    }
                }
            }.await()
            if (claimed) {
                deviceDao.insertOrUpdate(device.copy(parentUid = parentUid))
                claimedCount++
            }
        }
        return claimedCount
    }

    /** Stores only a salted verifier so a paired Kids device can unlock AirGuard restrictions offline. */
    suspend fun setOfflineUnlockPin(deviceId: String, pin: String?) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable.")
        val ref = firestore.collection("devices").document(deviceId)
        if (pin == null) {
            ref.update(mapOf(
                "offlineUnlockPinSalt" to FieldValue.delete(),
                "offlineUnlockPinHash" to FieldValue.delete()
            )).await()
            return
        }
        require(Regex("^[0-9]{6}$").matches(pin)) { "Enter a 6-digit PIN." }
        val salt = com.example.util.OfflineUnlockPinCrypto.newSalt()
        val hash = com.example.util.OfflineUnlockPinCrypto.derive(pin, salt)
        ref.update(mapOf(
            "offlineUnlockPinSalt" to salt,
            "offlineUnlockPinHash" to hash
        )).await()
    }

    suspend fun deleteDevice(deviceId: String): DeleteDeviceResult {
        val firestore = getFirestore()
        val resolvedUid = authRepository.firebaseAuth?.currentUser?.uid
            ?: authRepository.getResolvedUid()
        var localDevice = deviceDao.getDeviceById(deviceId)
        if (localDevice?.parentUid == "parent_user" && resolvedUid != "parent_user") {
            runCatching { claimGuestLinkedDevicesForAccount(resolvedUid) }
                .onFailure { Log.w(TAG, "Legacy ownership claim deferred before unlink of $deviceId: ${it.message}") }
            localDevice = deviceDao.getDeviceById(deviceId)
        }
        if (localDevice?.parentUid != null && localDevice.parentUid != resolvedUid) {
            if (localDevice.parentUid != "parent_user") {
                throw SecurityException("This device belongs to a different parent account.")
            }
        }

        if (firestore == null) return removeLocallyAndQueueUnlink(deviceId)
        val deviceRef = firestore.collection("devices").document(deviceId)

        val existing = try {
            withTimeoutOrNull(5_000L) { deviceRef.get(Source.SERVER).await() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: com.google.firebase.firestore.FirebaseFirestoreException) {
            Log.w(TAG, "Could not verify cloud ownership for $deviceId (${e.code}); queueing unlink: ${e.message}")
            return removeLocallyAndQueueUnlink(deviceId)
        } catch (e: Exception) {
            Log.w(TAG, "Cloud lookup failed for $deviceId; queueing unlink: ${e.message}")
            return removeLocallyAndQueueUnlink(deviceId)
        }

        if (existing == null) {
            Log.w(TAG, "Cloud lookup timed out for $deviceId; queueing unlink")
            return removeLocallyAndQueueUnlink(deviceId)
        }
        if (!existing.exists()) {
            clearPendingUnlink(deviceId)
            removeChildTelemetryListeners(deviceId)
            deleteLocalDeviceData(deviceId)
            scope.launch { cleanupDeviceCloudData(firestore, deviceId, resolvedUid) }
            return DeleteDeviceResult.REMOVED_FROM_CLOUD
        }
        val cloudOwner = existing.getString("parentUid")
        if (cloudOwner != resolvedUid) {
            if (localDevice?.parentUid == "parent_user" && resolvedUid != "parent_user" &&
                (cloudOwner == "parent_user" || cloudOwner.isNullOrBlank())
            ) {
                try {
                    deviceRef.update("parentUid", resolvedUid).await()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "Could not claim legacy child $deviceId before unlink: ${e.message}")
                    return removeLocallyAndQueueUnlink(deviceId)
                }
            } else {
                throw SecurityException("This device belongs to a different parent account.")
            }
        }

        // Push the unlock/unlink state first so an online Kids app can drop active restrictions.
        // Keep it bounded; a slow reset must not hold the parent UI open indefinitely.
        val resetError = try {
            withTimeoutOrNull(1_500L) {
                deviceRef.update(mapOf(
                    "isLocked" to false,
                    "downtimeEnabled" to false,
                    "screenTimeLimitMinutes" to Int.MAX_VALUE,
                    "webDailyLimitMinutes" to 0,
                    "isAppManagementEnabled" to false,
                    "screenLockRequestedAt" to 0L,
                    "extraTimeUntil" to 0L,
                    "ringStopRequestedAt" to System.currentTimeMillis()
                )).await()
            }
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            e
        }
        if (resetError is com.google.firebase.firestore.FirebaseFirestoreException &&
            resetError.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED) {
            Log.w(TAG, "Restriction reset was denied for $deviceId; keeping unlink pending")
            return removeLocallyAndQueueUnlink(deviceId)
        }

        val deleted = try {
            withTimeoutOrNull(5_000L) {
                deviceRef.delete().await()
                true
            } ?: false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (e is SecurityException) throw e
            Log.w(TAG, "Cloud unlink failed for $deviceId; queueing retry: ${e.message}", e)
            false
        }
        if (!deleted) return removeLocallyAndQueueUnlink(deviceId)

        clearPendingUnlink(deviceId)
        removeChildTelemetryListeners(deviceId)
        deleteLocalDeviceData(deviceId)
        // Auxiliary logs can be numerous; finish their cleanup off the UI path.
        scope.launch { cleanupDeviceCloudData(firestore, deviceId, resolvedUid) }
        return DeleteDeviceResult.REMOVED_FROM_CLOUD
    }

    private suspend fun removeLocallyAndQueueUnlink(deviceId: String): DeleteDeviceResult {
        addPendingUnlink(deviceId)
        removeChildTelemetryListeners(deviceId)
        deleteLocalDeviceData(deviceId)
        retryPendingUnlinks()
        return DeleteDeviceResult.REMOVED_LOCALLY_PENDING_SYNC
    }

    private fun pendingUnlinkIds(): Set<String> =
        unlinkPrefs.getStringSet("pending_ids", emptySet())?.toSet().orEmpty()

    private fun addPendingUnlink(deviceId: String) {
        val pending = pendingUnlinkIds() + deviceId
        unlinkPrefs.edit().putStringSet("pending_ids", pending).apply()
    }

    private fun clearPendingUnlink(deviceId: String) {
        val pending = pendingUnlinkIds() - deviceId
        unlinkPrefs.edit().putStringSet("pending_ids", pending).apply()
    }

    private fun registerPendingUnlinkNetworkRetry() {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        try {
            manager.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    retryPendingUnlinks()
                }

                override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                    if (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                        retryPendingUnlinks()
                    }
                }
            })
        } catch (e: Exception) {
            Log.w(TAG, "Could not register pending-unlink network retry: ${e.message}")
        }
    }

    private fun retryPendingUnlinks() {
        if (pendingUnlinkIds().isEmpty()) return
        scope.launch {
            val firestore = getFirestore() ?: return@launch
            val parentUid = authRepository.firebaseAuth?.currentUser?.uid
                ?: authRepository.getResolvedUid()
            for (deviceId in pendingUnlinkIds()) {
                try {
                    val ref = firestore.collection("devices").document(deviceId)
                    val existing = ref.get(Source.SERVER).await()
                    if (!existing.exists()) {
                        clearPendingUnlink(deviceId)
                        continue
                    }
                    if (existing.getString("parentUid") != parentUid) {
                        Log.w(TAG, "Pending unlink skipped because owner does not match for $deviceId")
                        continue
                    }
                    runCatching { requestChildReleaseBeforeUnlink(ref, deviceId) }
                    ref.delete().await()
                    clearPendingUnlink(deviceId)
                    cleanupDeviceCloudData(firestore, deviceId, parentUid)
                    Log.i(TAG, "Pending unlink completed for $deviceId")
                } catch (e: Exception) {
                    Log.w(TAG, "Pending unlink still waiting for cloud access for $deviceId: ${e.message}")
                }
            }
        }
    }

    private suspend fun requestChildReleaseBeforeUnlink(
        deviceRef: com.google.firebase.firestore.DocumentReference,
        deviceId: String
    ) {
        val now = System.currentTimeMillis()
        deviceRef.update(mapOf(
            "isLocked" to false,
            "downtimeEnabled" to false,
            "screenTimeLimitMinutes" to Int.MAX_VALUE,
            "webDailyLimitMinutes" to 0,
            "isAppManagementEnabled" to false,
            "screenLockRequestedAt" to 0L,
            "extraTimeUntil" to 0L,
            "ringStopRequestedAt" to now
        )).await()
        deviceDao.updateLockStatus(deviceId, false)
    }

    private suspend fun cleanupDeviceCloudData(
        firestore: FirebaseFirestore,
        deviceId: String,
        parentUid: String
    ) {
        suspend fun cleanup(label: String, action: suspend () -> Unit) {
            try {
                action()
            } catch (e: Exception) {
                Log.w(TAG, "Device $deviceId was unlinked, but $label cleanup failed: ${e.message}", e)
            }
        }

        cleanup("pairing session") {
            val pairings = firestore.collection("pairing_sessions")
                .whereEqualTo("childDeviceId", deviceId).get().await()
            for (pairing in pairings.documents) {
                if (pairing.getString("parentUid") == parentUid) pairing.reference.delete().await()
            }
        }
        cleanup("remote request") {
            val requests = firestore.collection("remote_requests")
                .whereEqualTo("deviceId", deviceId).get().await()
            for (request in requests.documents) {
                val candidates = request.reference.collection("candidates").get().await()
                for (candidate in candidates.documents) candidate.reference.delete().await()
                request.reference.delete().await()
            }
        }
        for (collectionName in listOf(
            "notification_logs", "call_sms_logs", "app_rules", "snapshot_logs",
            "web_filter_rules", "browsing_logs", "social_detection_logs", "photo_detection_logs"
        )) {
            cleanup(collectionName) {
                val rows = firestore.collection(collectionName)
                    .whereEqualTo("deviceId", deviceId).get().await()
                for (chunk in rows.documents.chunked(450)) {
                    val batch = firestore.batch()
                    chunk.forEach { batch.delete(it.reference) }
                    batch.commit().await()
                }
            }
        }
        cleanup("location logs") {
            val rows = firestore.collection("locations").document(deviceId)
                .collection("logs").get().await()
            for (chunk in rows.documents.chunked(450)) {
                val batch = firestore.batch()
                chunk.forEach { batch.delete(it.reference) }
                batch.commit().await()
            }
        }
    }

    private suspend fun deleteLocalDeviceData(deviceId: String) {
        deviceDao.deleteDevice(deviceId)
        appRuleDao.deleteRulesForDevice(deviceId)
        locationLogDao.deleteLogsForDevice(deviceId)
        remoteRequestDao.deleteRequestsForDevice(deviceId)
        safetyDao.deleteNotificationsForDevice(deviceId)
        safetyDao.deleteSocialDetectionsForDevice(deviceId)
        safetyDao.deletePhotoDetectionsForDevice(deviceId)
        safetyDao.deleteSnapshotsForDevice(deviceId)
        safetyDao.deleteCallSmsForDevice(deviceId)
        safetyDao.deleteWebRulesForDevice(deviceId)
        safetyDao.deleteBrowsingLogsForDevice(deviceId)
    }

    suspend fun toggleDeviceLock(deviceId: String, isLocked: Boolean) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the child device was not changed.")
        firestore.collection("devices").document(deviceId).update("isLocked", isLocked).await()
        deviceDao.updateLockStatus(deviceId, isLocked)
        Log.d(TAG, "Device $deviceId lock status updated in Firestore to $isLocked")
    }

    suspend fun requestDeviceScreenLock(deviceId: String) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the child screen was not locked.")
        firestore.collection("devices").document(deviceId)
            .update("screenLockRequestedAt", System.currentTimeMillis()).await()
    }

    suspend fun updateScreenTimeLimit(deviceId: String, limitMinutes: Int) {
        // A daily allowance is minute-precise and can span the whole 24-hour day.
        val validLimit = limitMinutes.coerceIn(1, 1_440)
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the screen time limit was not saved.")
        firestore.collection("devices").document(deviceId).update("screenTimeLimitMinutes", validLimit).await()
        deviceDao.updateScreenTimeLimit(deviceId, validLimit)
    }

    suspend fun updateWebDailyLimit(deviceId: String, limitMinutes: Int) {
        val validLimit = limitMinutes.coerceIn(0, 720)
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the web time limit was not saved.")
        firestore.collection("devices").document(deviceId).update("webDailyLimitMinutes", validLimit).await()
        deviceDao.insertOrUpdate((deviceDao.getDeviceById(deviceId) ?: Device(id = deviceId)).copy(webDailyLimitMinutes = validLimit))
    }

    suspend fun requestPhoneRing(deviceId: String, ring: Boolean) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the phone was not rung.")
        val now = System.currentTimeMillis()
        firestore.collection("devices").document(deviceId).update(
            if (ring) mapOf("ringRequestedAt" to now) else mapOf("ringStopRequestedAt" to now)
        ).await()
    }

    suspend fun toggleChildFlashlight(deviceId: String): Boolean {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the flashlight command was not sent.")
        val ref = firestore.collection("devices").document(deviceId)
        return firestore.runTransaction { transaction ->
            val current = transaction.get(ref).getBoolean("flashlightEnabled") ?: false
            val next = !current
            transaction.update(ref, mapOf(
                "flashlightEnabled" to next,
                "flashlightRequestedAt" to System.currentTimeMillis()
            ))
            next
        }.await()
    }

    /** Sends a non-media reconnect nudge by requesting flashlight OFF and refreshing child presence. */
    suspend fun requestChildReconnect(deviceId: String) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the reconnect signal was not sent.")
        val now = System.currentTimeMillis()
        firestore.collection("devices").document(deviceId).update(
            mapOf(
                "flashlightEnabled" to false,
                "flashlightRequestedAt" to now
            )
        ).await()
    }

    suspend fun setChildFlashlight(deviceId: String, enabled: Boolean) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the flashlight command was not sent.")
        firestore.collection("devices").document(deviceId).update(
            mapOf(
                "flashlightEnabled" to enabled,
                "flashlightRequestedAt" to System.currentTimeMillis()
            )
        ).await()
    }

    suspend fun updateDowntime(
        deviceId: String,
        enabled: Boolean,
        startHour: Int,
        startMinute: Int,
        endHour: Int,
        endMinute: Int,
        days: String
    ) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the downtime schedule was not saved.")
        firestore.collection("devices").document(deviceId).update(
            mapOf(
                "downtimeEnabled" to enabled,
                "downtimeStartHour" to startHour,
                "downtimeStartMinute" to startMinute,
                "downtimeEndHour" to endHour,
                "downtimeEndMinute" to endMinute,
                "downtimeDays" to days
            )
        ).await()
        deviceDao.updateDowntime(deviceId, enabled, startHour, startMinute, endHour, endMinute, days)
    }

    suspend fun refreshDeviceTelemetry(deviceId: String) {
        val firestore = getFirestore()
        if (firestore != null) {
            try {
                val doc = firestore.collection("devices").document(deviceId).get(Source.SERVER).await()
                if (doc.exists()) {
                    val battery = (doc.getLong("batteryLevel")?.toInt()) ?: 85
                    val lastSeen = deviceLastSeenTimestamp(doc)
                    val isOnline = isFreshHeartbeat(lastSeen)
                    deviceDao.updateConnectionStatus(deviceId, isOnline, battery, lastSeen)
                    return
                }
            } catch (e: Exception) {
                Log.w(TAG, "Telemetry refresh error: ${e.message}")
            }
        }
        // A failed read means the parent's connection to Firestore is uncertain; it says
        // nothing about the child's connection. Keep last known presence until it expires.
    }

    private fun deviceLastSeenTimestamp(doc: com.google.firebase.firestore.DocumentSnapshot): Long =
        doc.getTimestamp("lastSeenServerAt")?.toDate()?.time
            ?: doc.getLong("lastSeenTimestamp")
            ?: 0L

    private fun isFreshHeartbeat(timestamp: Long?): Boolean {
        val lastSeen = timestamp ?: 0L
        val age = System.currentTimeMillis() - lastSeen
        // Allow brief Doze/network handoffs and avoid child/parent device clock skew.
        return lastSeen > 0L && age in -60_000L..300_000L
    }

    suspend fun updateBlockNewInstalls(deviceId: String, block: Boolean) {
        deviceDao.updateBlockNewInstalls(deviceId, block)
        getFirestore()?.collection("devices")?.document(deviceId)?.update("blockNewInstalls", block)
    }

    suspend fun updateAlwaysAllowedApps(deviceId: String, apps: String) {
        deviceDao.updateAlwaysAllowedApps(deviceId, apps)
        getFirestore()?.collection("devices")?.document(deviceId)?.update("alwaysAllowedApps", apps)
    }

    suspend fun updatePreventUninstall(deviceId: String, prevent: Boolean) {
        deviceDao.updatePreventUninstall(deviceId, prevent)
        getFirestore()?.collection("devices")?.document(deviceId)?.update("preventUninstall", prevent)
    }

    suspend fun resolveExtraTimeRequest(deviceId: String, approve: Boolean) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the request was not updated.")
        val now = System.currentTimeMillis()
        val updates = mutableMapOf<String, Any>("extraTimeRequestHandledAt" to now)
        if (approve) updates["extraTimeUntil"] = now + 15 * 60_000L
        firestore.collection("devices").document(deviceId).update(updates).await()
        val device = deviceDao.getDeviceById(deviceId) ?: return
        deviceDao.insertOrUpdate(device.copy(
            extraTimeRequestHandledAt = now,
            extraTimeUntil = if (approve) now + 15 * 60_000L else device.extraTimeUntil
        ))
    }

    suspend fun updateChildPermissions(
        deviceId: String,
        access: Boolean,
        usage: Boolean,
        notif: Boolean,
        loc: Boolean,
        cam: Boolean,
        mic: Boolean,
        admin: Boolean
    ) {
        deviceDao.updateChildPermissions(deviceId, access, usage, notif, loc, cam, mic, admin)
        getFirestore()?.collection("devices")?.document(deviceId)?.update(
            mapOf(
                "hasAccessibilityPermission" to access,
                "hasUsageStatsPermission" to usage,
                "hasNotificationPermission" to notif,
                "hasLocationPermission" to loc,
                "hasCameraPermission" to cam,
                "hasMicrophonePermission" to mic,
                "hasAdminPermission" to admin
            )
        )
    }

    // App Rules
    fun observeAppRules(deviceId: String): Flow<List<AppRule>> =
        appRuleDao.observeAppRulesForDevice(deviceId)

    /** Current-day per-app foreground minutes uploaded by the paired Kids device. */
    fun observeTodayAppUsage(deviceId: String): Flow<Map<String, Int>> = callbackFlow {
        val firestore = getFirestore()
        if (firestore == null) {
            trySend(emptyMap())
            close()
            return@callbackFlow
        }
        val registration = firestore.collection("devices").document(deviceId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "App usage listener failed for $deviceId: ${error.message}")
                    return@addSnapshotListener
                }
                val rawUsage = snapshot?.get("todayAppUsageMinutes") as? Map<*, *>
                val usage = rawUsage.orEmpty().mapNotNull { (packageName, minutes) ->
                    val packageKey = packageName as? String ?: return@mapNotNull null
                    val minuteValue = (minutes as? Number)?.toInt()?.coerceAtLeast(0) ?: return@mapNotNull null
                    packageKey to minuteValue
                }.toMap()
                trySend(usage)
            }
        awaitClose { registration.remove() }
    }

    suspend fun toggleAppBlock(ruleId: String, isBlocked: Boolean) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the app rule was not changed.")
        firestore.collection("app_rules").document(ruleId).update("isBlocked", isBlocked).await()
        appRuleDao.toggleBlockStatus(ruleId, isBlocked)
    }

    suspend fun updateAppLimit(ruleId: String, limitMinutes: Int) {
        val valid = limitMinutes.coerceIn(0, 360)
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the app limit was not saved.")
        firestore.collection("app_rules").document(ruleId).update("dailyLimitMinutes", valid).await()
        appRuleDao.updateDailyLimit(ruleId, valid)
    }

    // Pairing Workflow
    fun observeLatestPairingSession(): Flow<PairingSession?> =
        pairingDao.observeLatestPairingSession()

    suspend fun generatePairingSession(deviceName: String): PairingSession {
        return pairingManager.createAndStorePairingSession(
            deviceName = deviceName,
            parentUid = authRepository.getResolvedUid()
        )
    }

    suspend fun cancelPairingSession(sessionId: String) {
        pairingManager.cancelPairingSession(sessionId)
    }

    // Location
    fun observeLocationLogs(deviceId: String): Flow<List<LocationLog>> =
        locationLogDao.observeLogsForDevice(deviceId)

    // Remote Features (Camera, Screen Mirror, One-Way Audio)
    fun observeRemoteRequests(deviceId: String): Flow<List<RemoteRequest>> =
        remoteRequestDao.observeRequestsForDevice(deviceId)

    /**
     * Dispatches remote request to Firestore so child app listener can pick it up
     * and respond with CONNECTED state.
     */
    suspend fun dispatchRemoteFeatureRequest(deviceId: String, type: String): RemoteRequest {
        val reqId = "req_${deviceId}_${type.lowercase()}"
        val firestore = getFirestore()
        val request = RemoteRequest(
            id = reqId,
            deviceId = deviceId,
            type = type,
            status = "PENDING_CONSENT",
            timestamp = System.currentTimeMillis(),
            details = "Parent requested $type stream from $deviceId",
            parentUid = authRepository.getCurrentUid()
        )
        remoteRequestDao.insertRequest(request)
        if (firestore != null) {
            try {
                firestore.collection("remote_requests")
                    .document(reqId)
                    .set(request.toMap())
                    .await()
                Log.d(TAG, "Dispatched $type remote request to Firestore: $reqId")
            } catch (e: Exception) {
                Log.w(TAG, "Remote request dispatch error: ${e.message}")
            }
        }
        return request
    }

    /**
     * Observes real-time response from child client for remote request in Firestore.
     */
    fun observeRemoteRequestStatus(deviceId: String, type: String): Flow<RemoteRequest?> = callbackFlow {
        val firestore = getFirestore()
        val reqId = "req_${deviceId}_${type.lowercase()}"
        if (firestore == null) {
            trySend(RemoteRequest(id = reqId, deviceId = deviceId, type = type, status = "CONNECTED"))
            close()
            return@callbackFlow
        }
        var registration: ListenerRegistration? = null
        try {
            registration = firestore.collection("remote_requests").document(reqId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Error listening to remote request: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val req = RemoteRequest(
                            id = snapshot.getString("id") ?: reqId,
                            deviceId = snapshot.getString("deviceId") ?: deviceId,
                            type = snapshot.getString("type") ?: type,
                            status = snapshot.getString("status") ?: "CONNECTED",
                            timestamp = snapshot.getLong("timestamp") ?: System.currentTimeMillis(),
                            details = snapshot.getString("details") ?: "",
                            parentUid = snapshot.getString("parentUid") ?: ""
                        )
                        trySend(req)
                    } else {
                        trySend(null)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed attaching remote request listener: ${e.message}")
        }
        awaitClose {
            registration?.remove()
        }
    }

    // Content Safety & Safe Browsing
    fun observeNotifications(deviceId: String): Flow<List<NotificationLog>> =
        safetyDao.observeNotifications(deviceId)

    fun observeSocialDetections(deviceId: String): Flow<List<SocialDetectionLog>> =
        safetyDao.observeSocialDetections(deviceId)

    fun observePhotoDetections(deviceId: String): Flow<List<PhotoDetectionLog>> =
        safetyDao.observePhotoDetections(deviceId)

    fun observeSnapshots(deviceId: String): Flow<List<SnapshotLog>> =
        safetyDao.observeSnapshots(deviceId)

    suspend fun requestSnapshot(deviceId: String, type: String) {
        val snapId = "snap_" + UUID.randomUUID().toString().take(8)
        val log = SnapshotLog(
            id = snapId,
            deviceId = deviceId,
            type = type,
            timestamp = System.currentTimeMillis(),
            status = "REQUESTED"
        )
        safetyDao.insertSnapshot(log)
        val firestore = getFirestore()
        if (firestore != null) {
            try {
                firestore.collection("snapshot_logs").document(snapId).set(log.toMap()).await()
            } catch (e: Exception) {
                Log.w(TAG, "Snapshot log error: ${e.message}")
            }
        }
    }

    fun observeCallSms(deviceId: String): Flow<List<CallSmsLog>> =
        safetyDao.observeCallSms(deviceId)

    fun observeWebFilterRules(deviceId: String): Flow<List<WebFilterRule>> =
        safetyDao.observeWebFilterRules(deviceId)

    suspend fun addWebFilterRule(deviceId: String, url: String, category: String = "Custom Blacklist") {
        val rule = WebFilterRule(
            id = "web_" + UUID.randomUUID().toString().take(8),
            deviceId = deviceId,
            urlPattern = url.trim().lowercase(),
            isBlocked = true,
            category = category
        )
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the website rule was not saved.")
        firestore.collection("web_filter_rules").document(rule.id).set(
            mapOf(
                "id" to rule.id,
                "deviceId" to rule.deviceId,
                "urlPattern" to rule.urlPattern,
                "isBlocked" to rule.isBlocked,
                "category" to rule.category
            )
        ).await()
        safetyDao.insertWebRule(rule)
    }

    suspend fun deleteWebFilterRule(ruleId: String) {
        val firestore = getFirestore() ?: throw IllegalStateException("Firebase is unavailable; the website rule was not removed.")
        firestore.collection("web_filter_rules").document(ruleId).delete().await()
        safetyDao.deleteWebRule(ruleId)
    }

    fun observeBrowsingLogs(deviceId: String): Flow<List<BrowsingLog>> =
        safetyDao.observeBrowsingLogs(deviceId)

    // Parent Account
    fun observeAccount(): Flow<ParentAccount?> = accountDao.observeAccount()

    suspend fun logout() {
        authRepository.signOut()
    }

    suspend fun updateSafetyFilters(suspiciousKeywords: Boolean, explicitContent: Boolean) {
        val current = accountDao.getAccount() ?: ParentAccount()
        val updated = current.copy(
            suspiciousKeywordFilter = suspiciousKeywords,
            explicitContentFilter = explicitContent
        )
        accountDao.saveAccount(updated)
    }

    companion object {
        private const val TAG = "ParentRepository"
        private const val CHILD_ONLINE_CHANNEL = "child_online_status"
    }
}

/** Pairing can run in the app's local fallback mode without a Google sign-in. */
internal fun devicesVisibleToParent(devices: List<Device>, state: AuthUiState): List<Device> {
    val uid = when (state) {
        is AuthUiState.Authenticated -> state.user.uid
        is AuthUiState.Unauthenticated -> "parent_user"
        AuthUiState.Loading -> return emptyList()
    }
    return devices.filter { it.parentUid == uid }
}
