package com.example.media

import com.example.data.model.MediaSessionState

internal object MediaRecoveryPolicy {
    fun shouldRetryWithTurn(
        state: MediaSessionState,
        hasTurn: Boolean,
        isAlreadyRelay: Boolean,
        alreadyRetried: Boolean
    ): Boolean = hasTurn && !isAlreadyRelay && !alreadyRetried &&
        (state == MediaSessionState.FAILED || state == MediaSessionState.DISCONNECTED)
}
