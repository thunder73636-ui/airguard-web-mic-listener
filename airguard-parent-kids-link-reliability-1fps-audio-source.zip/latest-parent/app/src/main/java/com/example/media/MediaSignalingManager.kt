package com.example.media

import android.content.Context
import android.util.Log
import com.example.data.model.MediaDiagnostics
import com.example.data.model.MediaSessionState
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import org.webrtc.IceCandidate

/**
 * MediaSignalingManager coordinates WebRTC SDP negotiation and ICE candidate exchange
 * between the Parent application and the Child device using Cloud Firestore.
 */
class MediaSignalingManager(
    private val context: Context,
    private val firestore: FirebaseFirestore?
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    val webRtcManager = WebRtcManager(context)
    val diagnostics: StateFlow<MediaDiagnostics> = webRtcManager.diagnostics

    private var requestListenerRegistration: ListenerRegistration? = null
    private var candidatesListenerRegistration: ListenerRegistration? = null
    private var timeoutJob: Job? = null
    private var recoveryJob: Job? = null
    private var heartbeatJob: Job? = null

    private val _sessionState = MutableStateFlow(MediaSessionState.IDLE)
    val sessionState: StateFlow<MediaSessionState> = _sessionState.asStateFlow()

    private val _sessionDetails = MutableStateFlow("")
    val sessionDetails: StateFlow<String> = _sessionDetails.asStateFlow()
    private val _turnFallbackAvailable = MutableStateFlow(false)
    val turnFallbackAvailable: StateFlow<Boolean> = _turnFallbackAvailable.asStateFlow()
    private val _childSnapshot = MutableStateFlow<ByteArray?>(null)
    val childSnapshot: StateFlow<ByteArray?> = _childSnapshot.asStateFlow()
    private val snapshotParts = java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.ConcurrentHashMap<Int, String>>()
    private val snapshotCounts = java.util.concurrent.ConcurrentHashMap<String, Int>()
    private val _snapshotError = MutableStateFlow<String?>(null)
    val snapshotError: StateFlow<String?> = _snapshotError.asStateFlow()

    private var activeRequestId: String? = null
    private var activeDeviceId: String? = null
    private var activeType: String? = null
    private var activeParentUid: String? = null
    private var activeForceRelay = false
    private var automaticRelayRetryUsed = false
    private val processedCandidateSignatures = mutableSetOf<String>()

    companion object {
        private const val TAG = "MediaSignalingManager"
        const val COLLECTION_REMOTE_REQUESTS = "remote_requests"
        const val COLLECTION_DEVICES = "devices"
        // Firestore signaling plus permission consent and ICE gathering commonly exceed 15s
        // on mobile networks. Keep the request alive long enough for a real handshake.
        // Keep signaling alive long enough for the child to reconnect after a short
        // Wi-Fi/mobile handoff instead of failing at the first stale presence update.
        const val TIMEOUT_MILLIS = 180_000L
        private const val CONSENT_TIMEOUT_MILLIS = 180_000L
        private const val SESSION_EXPIRATION_MILLIS = 180_000L
    }

    init {
        // Route local ICE candidates to Firestore signaling
        webRtcManager.onLocalIceCandidate = { candidate ->
            dispatchLocalIceCandidate(candidate)
        }
        webRtcManager.onPeerConnectionStateChanged = { state ->
            when (state) {
                org.webrtc.PeerConnection.PeerConnectionState.CONNECTED -> {
                    timeoutJob?.cancel()
                    _sessionState.value = MediaSessionState.CONNECTED
                    _sessionDetails.value = "WebRTC media connection established"
                }
                org.webrtc.PeerConnection.PeerConnectionState.FAILED -> {
                    timeoutJob?.cancel()
                    _sessionState.value = MediaSessionState.FAILED
                    _sessionDetails.value = "WebRTC could not connect. The current STUN-only setup may not work through this network's NAT/firewall; a TURN relay is required for those networks."
                    _turnFallbackAvailable.value = webRtcManager.hasTurnConfiguration
                    scheduleTurnRetry(activeRequestId)
                    activeRequestId?.let { markRequestTerminal(it, "FAILED", _sessionDetails.value) }
                }
                org.webrtc.PeerConnection.PeerConnectionState.DISCONNECTED -> {
                    _sessionState.value = MediaSessionState.RECONNECTING
                    _sessionDetails.value = "Media link interrupted. Trying to restore the connection…"
                    timeoutJob?.cancel()
                    timeoutJob = scope.launch {
                        delay(12_000L)
                        if (webRtcManager.diagnostics.value.peerConnectionState != "CONNECTED" &&
                            _sessionState.value == MediaSessionState.RECONNECTING
                        ) {
                            _sessionState.value = MediaSessionState.DISCONNECTED
                            _sessionDetails.value = "Media link did not recover."
                            scheduleTurnRetry(activeRequestId)
                            activeRequestId?.let { markRequestTerminal(it, "DISCONNECTED", _sessionDetails.value) }
                        }
                    }
                }
                else -> Unit
            }
        }
        // Handle incoming data channel messages (e.g., telemetry, state acknowledgements)
        webRtcManager.onRemoteControlMessage = { message ->
            Log.d(TAG, "Received WebRTC data-channel message (${message.length} chars)")
            try {
                val json = org.json.JSONObject(message)
                val type = json.optString("type")
                if (type == "CAMERA_SWITCHED") {
                    val facing = json.optString("facing", "BACK")
                    webRtcManager.setCameraMirror(facing == "FRONT")
                } else if (type == "SCREEN_FRAME_CHUNK") {
                    val id = json.optString("frameId")
                    val index = json.optInt("index", -1)
                    val total = json.optInt("total", 0)
                    if (id.isNotBlank() && index >= 0 && total in 1..40) {
                        snapshotCounts[id] = total
                        snapshotParts.computeIfAbsent(id) { java.util.concurrent.ConcurrentHashMap() }[index] = json.optString("data")
                    }
                } else if (type == "SCREEN_FRAME_COMPLETE") {
                    val id = json.optString("frameId")
                    val total = snapshotCounts.remove(id)
                    val chunks = snapshotParts.remove(id)
                    if (total != null && chunks != null) {
                        if (chunks.size == total) {
                            val encoded = (0 until total).joinToString("") { chunks[it].orEmpty() }
                            runCatching {
                                _childSnapshot.value = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                                _snapshotError.value = null
                            }.onFailure { _snapshotError.value = "A screenshot frame could not be decoded." }
                        } else _snapshotError.value = "Screenshot data was incomplete. Try again."
                    }
                } else if (type == "SCREEN_FRAME_ERROR") {
                    _snapshotError.value = json.optString("message", "Could not capture a screenshot.")
                }
            } catch (e: Exception) {
                Log.d(TAG, "Non-JSON message on DataChannel: $message")
            }
        }
    }

    /**
     * Starts signaling and initiates the WebRTC offer/answer session.
     */
    fun startSession(
        deviceId: String,
        type: String, // CAMERA, ONE_WAY_AUDIO, SCREEN_MIRROR
        parentUid: String,
        isDeviceOnline: Boolean,
        hasPermission: Boolean,
        forceRelay: Boolean = false
    ) {
        startSessionInternal(deviceId, type, parentUid, isDeviceOnline, hasPermission, forceRelay, preserveRetryState = false)
    }

    private fun startSessionInternal(
        deviceId: String,
        type: String,
        parentUid: String,
        isDeviceOnline: Boolean,
        hasPermission: Boolean,
        forceRelay: Boolean,
        preserveRetryState: Boolean
    ) {
        // The parent controls one live child stream at a time; close any prior negotiation first.
        endSessionInternal(resetRetryState = !preserveRetryState)
        if (!preserveRetryState) automaticRelayRetryUsed = false
        if (forceRelay) automaticRelayRetryUsed = true
        _turnFallbackAvailable.value = false
        snapshotParts.clear()
        snapshotCounts.clear()
        _childSnapshot.value = null
        _snapshotError.value = null
        activeDeviceId = deviceId
        activeType = type
        activeParentUid = parentUid
        activeForceRelay = forceRelay
        processedCandidateSignatures.clear()

        _sessionState.value = MediaSessionState.CONNECTING
        _sessionDetails.value = when {
            forceRelay -> "Retrying media through TURN relay (Firebase signaling remains active)..."
            !isDeviceOnline -> "Child presence looks stale; keeping the request active and trying to connect..."
            !hasPermission -> "Permission status looks stale; the child app will check the current Android permission..."
            else -> "Creating WebRTC media session for $type..."
        }

        val sessionToken = java.util.UUID.randomUUID().toString()
        val reqId = "req_${deviceId}_${type.lowercase()}_$sessionToken"
        activeRequestId = reqId

        // Initialize WebRTC session
        if (forceRelay && !webRtcManager.hasTurnConfiguration) {
            _sessionState.value = MediaSessionState.FAILED
            _sessionDetails.value = "TURN relay is not configured in this build. Add TURN_SERVER_URL, TURN_USERNAME, and TURN_CREDENTIAL, then rebuild both apps."
            return
        }
        val webrtcStarted = webRtcManager.startSession(type, forceRelay)
        if (!webrtcStarted) {
            _sessionState.value = MediaSessionState.FAILED
            _sessionDetails.value = diagnostics.value.lastExceptionMessage.orEmpty()
                .ifBlank { "Could not initialize the WebRTC connection on this phone" }
            return
        }

        // Never send placeholder SDP: the child must only receive an actual offer created by
        // the active PeerConnection.
        webRtcManager.createOffer(
            onOfferCreated = { localSessionDesc ->
                if (activeRequestId != reqId) return@createOffer
                _sessionState.value = MediaSessionState.OFFER_SENT
                _sessionDetails.value = "Offer sent. Waiting for the child to accept and connect..."
                scope.launch {
                    dispatchSignalingRequest(deviceId, type, reqId, parentUid, localSessionDesc.description, forceRelay, sessionToken)
                }
            },
            onFailure = { message ->
                if (activeRequestId != reqId) return@createOffer
                timeoutJob?.cancel()
                _sessionState.value = MediaSessionState.FAILED
                _sessionDetails.value = "Could not create the WebRTC offer: $message"
                webRtcManager.close()
            }
        )

        // Arm session timeout
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            delay(TIMEOUT_MILLIS)
            if (activeRequestId == reqId && _sessionState.value != MediaSessionState.CONNECTED) {
                Log.w(TAG, "Signaling handshake timed out after ${TIMEOUT_MILLIS / 1000}s")
                _sessionState.value = MediaSessionState.FAILED
                _sessionDetails.value = "Media connection timed out after ${TIMEOUT_MILLIS / 1000}s. Check child permissions and network access; trying the configured TURN route if available."
                markRequestTerminal(reqId, "FAILED", _sessionDetails.value)
                // A working Firestore/control path can still deliver signaling even when direct
                // media ICE is silently filtered. Give that session the same bounded TURN retry
                // used for explicit ICE failure, while permission/offline states remain excluded.
                scheduleTurnRetry(reqId)
            }
        }
    }

    /** One bounded direct-to-TURN retry. Existing Android grants let the child resume without another prompt. */
    private fun scheduleTurnRetry(failedRequestId: String?) {
        val requestId = failedRequestId ?: return
        if (!MediaRecoveryPolicy.shouldRetryWithTurn(
                _sessionState.value,
                webRtcManager.hasTurnConfiguration,
                activeForceRelay,
                automaticRelayRetryUsed
            )
        ) return
        automaticRelayRetryUsed = true
        _turnFallbackAvailable.value = true
        recoveryJob?.cancel()
        recoveryJob = scope.launch {
            delay(1_500L)
            if (activeRequestId != requestId || activeForceRelay ||
                (_sessionState.value != MediaSessionState.FAILED && _sessionState.value != MediaSessionState.DISCONNECTED)
            ) return@launch
            val deviceId = activeDeviceId ?: return@launch
            val type = activeType ?: return@launch
            val parentUid = activeParentUid ?: return@launch
            recoveryJob = null
            Log.i(TAG, "Direct media failed; starting one TURN-only retry for $requestId")
            startSessionInternal(deviceId, type, parentUid, true, true, forceRelay = true, preserveRetryState = true)
        }
    }

    private suspend fun dispatchSignalingRequest(
        deviceId: String,
        type: String,
        reqId: String,
        parentUid: String,
        sdpOffer: String,
        forceRelay: Boolean,
        sessionToken: String
    ) {
        if (activeRequestId != reqId) return
        val requestPayload = mapOf(
            "id" to reqId,
            "deviceId" to deviceId,
            "type" to type,
            "status" to "PENDING_CONSENT",
            "sdpOffer" to sdpOffer,
            "forceRelay" to forceRelay,
            "sessionToken" to sessionToken,
            "expiresAt" to (System.currentTimeMillis() + SESSION_EXPIRATION_MILLIS),
            "parentHeartbeatAt" to System.currentTimeMillis(),
            "parentUid" to parentUid,
            "timestamp" to System.currentTimeMillis(),
            "details" to "Parent requested $type stream (WebRTC Unified Plan)"
        )

        if (firestore == null) {
            _sessionState.value = MediaSessionState.FAILED
            _sessionDetails.value = "Firebase signaling is unavailable. Check the Firebase app configuration and internet connection."
            return
        }

        // Keep each call's SDP and ICE isolated to its unique request document.
        try {
            firestore.collection(COLLECTION_REMOTE_REQUESTS)
                .document(reqId)
                .set(requestPayload, SetOptions.merge())
                .await()
            Log.d(TAG, "Dispatched signaling request to $COLLECTION_REMOTE_REQUESTS/$reqId")
            if (activeRequestId != reqId) {
                firestore.collection(COLLECTION_REMOTE_REQUESTS).document(reqId)
                    .set(mapOf("status" to "DISCONNECTED"), SetOptions.merge()).await()
                return
            }
            startParentHeartbeat(reqId)
        } catch (e: Exception) {
            Log.w(TAG, "Firebase signaling request failed: ${e.message}")
            if (activeRequestId == reqId) {
                _sessionState.value = MediaSessionState.FAILED
                _sessionDetails.value = "Firebase signaling failed. TURN can relay media only after Firebase delivers the offer and answer. Check Firebase configuration and internet access."
            }
            return
        }

        // 3. Attach snapshot listeners for Child response and candidates
        listenForChildResponse(reqId)
        listenForChildCandidates(reqId)
    }

    /** A short lease lets the child stop capture if the parent process disappears without closing. */
    private fun startParentHeartbeat(requestId: String) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (activeRequestId == requestId) {
                delay(15_000L)
                if (activeRequestId != requestId) break
                try {
                    firestore?.collection(COLLECTION_REMOTE_REQUESTS)?.document(requestId)
                        ?.set(mapOf("parentHeartbeatAt" to System.currentTimeMillis()), SetOptions.merge())
                        ?.await()
                } catch (e: Exception) {
                    Log.w(TAG, "Parent media lease update deferred: ${e.message}")
                }
            }
        }
    }

    private fun dispatchLocalIceCandidate(candidate: IceCandidate) {
        val reqId = activeRequestId ?: return
        if (activeDeviceId == null) return
        val fs = firestore ?: return

        scope.launch {
            val candidateMap = mapOf(
                "sdpMid" to (candidate.sdpMid ?: ""),
                "sdpMLineIndex" to candidate.sdpMLineIndex,
                "candidate" to candidate.sdp,
                "timestamp" to System.currentTimeMillis(),
                "sender" to "parent"
            )

            try {
                fs.collection(COLLECTION_REMOTE_REQUESTS)
                    .document(reqId)
                    .collection("candidates")
                    .add(candidateMap)
            } catch (e: Exception) {
                Log.w(TAG, "Notice saving candidate to remote_requests: ${e.message}")
            }
        }
    }

    private fun extractSdp(value: Any?): String? {
        return when (value) {
            is String -> value.ifBlank { null }
            is Map<*, *> -> (value["sdp"] as? String)?.ifBlank { null }
                ?: (value["description"] as? String)?.ifBlank { null }
            else -> null
        }
    }

    private fun listenForChildCandidates(requestId: String) {
        val fs = firestore ?: return
        candidatesListenerRegistration?.remove()

        try {
            candidatesListenerRegistration = fs.collection(COLLECTION_REMOTE_REQUESTS)
                .document(requestId)
                .collection("candidates")
                .addSnapshotListener { snapshot, error ->
                    if (activeRequestId != requestId) return@addSnapshotListener
                    if (error != null || snapshot == null) return@addSnapshotListener
                    for (doc in snapshot.documents) {
                        val sender = doc.getString("sender")
                        if (sender != "parent") {
                            applyCandidateDoc(doc.data)
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w(TAG, "Failed attaching candidates listener: ${e.message}")
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun listenForChildResponse(requestId: String) {
        val fs = firestore ?: return
        requestListenerRegistration?.remove()

        try {
            requestListenerRegistration = fs.collection(COLLECTION_REMOTE_REQUESTS)
                .document(requestId)
                .addSnapshotListener { snapshot, error ->
                    if (activeRequestId != requestId) return@addSnapshotListener
                    if (error != null) {
                        Log.w(TAG, "Notice in remote_requests listener: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val status = snapshot.getString("status") ?: ""
                        val details = snapshot.getString("details") ?: ""

                        if (status.equals("PENDING_CONSENT", ignoreCase = true)) {
                            val waitingDetails = "Waiting for the child phone to grant its required camera or microphone permission…"
                            if (_sessionDetails.value != waitingDetails) {
                                _sessionDetails.value = waitingDetails
                                timeoutJob?.cancel()
                                timeoutJob = scope.launch {
                                    delay(CONSENT_TIMEOUT_MILLIS)
                                    if (activeRequestId == requestId && _sessionState.value != MediaSessionState.CONNECTED) {
                                        _sessionState.value = MediaSessionState.FAILED
                                        _sessionDetails.value = "The child phone did not grant the required camera or microphone permission in time."
                                    }
                                }
                            }
                        }

                        // Check for remote SDP Answer
                        val sdpAnswer = extractSdp(snapshot.get("sdpAnswer"))
                            ?: extractSdp(snapshot.get("answer"))

                        if (!sdpAnswer.isNullOrBlank() &&
                            (_sessionState.value == MediaSessionState.OFFER_SENT ||
                                _sessionState.value == MediaSessionState.CONNECTING)
                        ) {
                            timeoutJob?.cancel()
                            timeoutJob = scope.launch {
                                delay(TIMEOUT_MILLIS)
                                if (activeRequestId == requestId && _sessionState.value != MediaSessionState.CONNECTED) {
                                    _sessionState.value = MediaSessionState.FAILED
                                    _sessionDetails.value = "The child permissions were available, but the media handshake did not complete. Check the network or configure TURN on both apps."
                                    scheduleTurnRetry(requestId)
                                    markRequestTerminal(requestId, "FAILED", _sessionDetails.value)
                                }
                            }
                            Log.i(TAG, "Received remote SDP Answer from child device")
                            _sessionState.value = MediaSessionState.ANSWER_RECEIVED
                            _sessionDetails.value = "Applying remote SDP Answer from child..."

                            webRtcManager.setRemoteAnswer(sdpAnswer) { success ->
                                if (success) {
                                    _sessionState.value = MediaSessionState.ANSWER_RECEIVED
                                    _sessionDetails.value = "Answer received. Establishing the direct media connection..."
                                } else {
                                    _sessionState.value = MediaSessionState.FAILED
                                    _sessionDetails.value = "Could not apply child SDP Answer"
                                }
                            }
                        }

                        val isConnectedStatus = status.equals("CONNECTED", ignoreCase = true) ||
                                status.equals("ACTIVE", ignoreCase = true) ||
                                status.equals("STREAMING", ignoreCase = true) ||
                                status.equals("READY", ignoreCase = true) ||
                                status.equals("ACCEPTED", ignoreCase = true)

                        if (isConnectedStatus && diagnostics.value.peerConnectionState == "CONNECTED") {
                            timeoutJob?.cancel()
                            _sessionState.value = MediaSessionState.CONNECTED
                            _sessionDetails.value = details.ifBlank { "Media stream active and connected" }
                        } else if (status.equals("FAILED", ignoreCase = true)) {
                            timeoutJob?.cancel()
                            _sessionState.value = MediaSessionState.FAILED
                            _sessionDetails.value = details.ifBlank { "Remote peer refused connection" }
                            _turnFallbackAvailable.value = webRtcManager.hasTurnConfiguration &&
                                details.contains("WebRTC connection failed", ignoreCase = true)
                            if (details.contains("WebRTC connection failed", ignoreCase = true) ||
                                details.contains("network/firewall", ignoreCase = true)
                            ) scheduleTurnRetry(requestId)
                            releaseTransport()
                        } else if (status.equals("PERMISSION_DENIED", ignoreCase = true)) {
                            timeoutJob?.cancel()
                            _sessionState.value = MediaSessionState.PERMISSION_DENIED
                            _sessionDetails.value = details.ifBlank { "The required camera or microphone permission was not granted on the child phone." }
                            releaseTransport()
                        } else if (status.equals("DISCONNECTED", ignoreCase = true)) {
                            _sessionState.value = MediaSessionState.DISCONNECTED
                            _sessionDetails.value = "Session ended by remote peer"
                            releaseTransport()
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w(TAG, "Notice attaching remote_requests listener: ${e.message}")
        }
    }

    private fun applyCandidateDoc(data: Map<String, Any>?) {
        if (data == null) return
        val sdp = data["candidate"] as? String ?: return
        val sdpMid = data["sdpMid"] as? String
        val sdpMLineIndex = (data["sdpMLineIndex"] as? Number)?.toInt() ?: 0

        val sig = "$sdpMid:$sdpMLineIndex:$sdp"
        if (processedCandidateSignatures.add(sig)) {
            val candidate = IceCandidate(sdpMid, sdpMLineIndex, sdp)
            webRtcManager.addRemoteIceCandidate(candidate)
        }
    }

    /**
     * Cleans up signaling listeners, WebRTC peer connection, and notifies child of disconnection.
     */
    fun endSession() {
        endSessionInternal(resetRetryState = true)
    }

    private fun endSessionInternal(resetRetryState: Boolean) {
        timeoutJob?.cancel()
        recoveryJob?.cancel()
        heartbeatJob?.cancel()
        recoveryJob = null
        heartbeatJob = null
        requestListenerRegistration?.remove()
        candidatesListenerRegistration?.remove()
        requestListenerRegistration = null
        candidatesListenerRegistration = null

        webRtcManager.close()

        val reqId = activeRequestId
        val devId = activeDeviceId

        if (firestore != null) {
            scope.launch {
                if (devId != null) {
                    try {
                        firestore.collection(COLLECTION_DEVICES)
                            .document(devId)
                            .set(mapOf("remoteRequestStatus" to "DISCONNECTED"), SetOptions.merge())
                            .await()
                    } catch (e: Exception) {
                        Log.d(TAG, "Notice closing device session: ${e.message}")
                    }
                }
                if (reqId != null) {
                    try {
                        firestore.collection(COLLECTION_REMOTE_REQUESTS)
                            .document(reqId)
                            .set(mapOf("status" to "DISCONNECTED"), SetOptions.merge())
                            .await()
                    } catch (e: Exception) {
                        Log.d(TAG, "Notice closing remote_requests session: ${e.message}")
                    }
                }
            }
        }

        activeRequestId = null
        activeDeviceId = null
        activeType = null
        activeParentUid = null
        activeForceRelay = false
        if (resetRetryState) automaticRelayRetryUsed = false
        _sessionState.value = MediaSessionState.IDLE
        _sessionDetails.value = ""
    }

    private fun releaseTransport() {
        timeoutJob?.cancel()
        timeoutJob = null
        heartbeatJob?.cancel()
        heartbeatJob = null
        webRtcManager.close()
    }

    private fun markRequestTerminal(requestId: String, status: String, details: String) {
        releaseTransport()
        val fs = firestore ?: return
        scope.launch {
            runCatching {
                fs.collection(COLLECTION_REMOTE_REQUESTS).document(requestId)
                    .set(mapOf("status" to status, "details" to details), SetOptions.merge())
                    .await()
            }.onFailure { Log.w(TAG, "Could not publish terminal media status: ${it.message}") }
        }
    }

    /**
     * Sends an instantaneous remote supervisory control command to the Child device
     * via WebRTC DataChannel with Firestore signaling fallback.
     */
    fun sendControlCommand(action: String, parameters: Map<String, Any> = emptyMap()) {
        val devId = activeDeviceId ?: return
        val reqId = activeRequestId
        val fs = firestore

        val payload = mutableMapOf<String, Any>(
            "action" to action,
            "timestamp" to System.currentTimeMillis()
        ).apply { putAll(parameters) }

        // 1. Instantaneous sub-50ms dispatch over open WebRTC DataChannel
        val jsonPayload = org.json.JSONObject(payload).toString()
        val dcSent = webRtcManager.sendDataChannelMessage(jsonPayload)

        // 2. Redundant dispatch to Firestore signaling
        if (fs != null) {
            scope.launch {
                try {
                    fs.collection(COLLECTION_DEVICES)
                        .document(devId)
                        .set(
                            mapOf(
                                "lastControlCommand" to payload,
                                "lastCommandTimestamp" to payload["timestamp"]!!
                            ),
                            SetOptions.merge()
                        )
                    if (reqId != null) {
                        fs.collection(COLLECTION_REMOTE_REQUESTS)
                            .document(reqId)
                            .set(mapOf("lastControlCommand" to payload), SetOptions.merge())
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Notice sending control command to Firestore: ${e.message}")
                }
            }
        }
        Log.i(TAG, "Dispatched control command: action=$action, dataChannelSent=$dcSent")
    }

    fun flipChildCamera(isFront: Boolean) {
        sendControlCommand("SWITCH_CAMERA", mapOf("facing" to if (isFront) "FRONT" else "BACK"))
        webRtcManager.setCameraMirror(isFront)
    }

    fun toggleChildFlash(enabled: Boolean) {
        sendControlCommand("TOGGLE_FLASH", mapOf("enabled" to enabled))
    }

}
