package com.example.media

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.util.Log

/**
 * RemoteAudioPlayer manages Android audio focus, speakerphone output routing,
 * and audio playout volume/mute for the incoming Child device microphone stream.
 */
class RemoteAudioPlayer(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    @Volatile
    private var isPlaying = false
    @Volatile
    private var isMuted = false
    @Volatile
    private var currentVolume = 1.0f

    var onRoutingChanged: ((focusGranted: Boolean, routingMode: String, playbackStatus: String) -> Unit)? = null

    companion object {
        private const val TAG = "RemoteAudioPlayer"
    }

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                Log.w(TAG, "Audio focus lost permanently, pausing playback")
                onRoutingChanged?.invoke(false, getRoutingModeString(), "Audio focus lost")
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                Log.w(TAG, "Audio focus lost transiently, muting")
                onRoutingChanged?.invoke(false, getRoutingModeString(), "Transient focus loss")
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                Log.i(TAG, "Audio focus regained")
                onRoutingChanged?.invoke(true, getRoutingModeString(), "Playing on speakerphone")
            }
        }
    }

    /**
     * Initializes audio focus and routes incoming audio to device speaker.
     */
    fun start(): Boolean {
        if (isPlaying) return true

        // 1. Request Audio Focus
        val focusGranted = requestAudioFocus()
        if (!focusGranted) {
            Log.w(TAG, "Could not acquire audio focus for child audio monitoring")
        }

        // 2. Route audio to device speaker
        val routingMode = routeAudioToSpeaker()

        isPlaying = true
        val status = if (focusGranted) "Audio Focus Granted & Routed to Speaker" else "Audio Focus Deferred"
        onRoutingChanged?.invoke(focusGranted, routingMode, status)
        Log.i(TAG, "RemoteAudioPlayer started: focusGranted=$focusGranted, routing=$routingMode")
        return focusGranted
    }

    private fun requestAudioFocus(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(attributes)
                    .setOnAudioFocusChangeListener(focusChangeListener)
                    .setAcceptsDelayedFocusGain(true)
                    .build()
                audioFocusRequest = request
                audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(
                    focusChangeListener,
                    AudioManager.STREAM_VOICE_CALL,
                    AudioManager.AUDIOFOCUS_GAIN
                ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error requesting audio focus: ${e.message}")
            false
        }
    }

    private fun routeAudioToSpeaker(): String {
        return try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            var routing = "SPEAKERPHONE_ON"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val devices = audioManager.availableCommunicationDevices
                val speakerDevice = devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                if (speakerDevice != null) {
                    val routed = audioManager.setCommunicationDevice(speakerDevice)
                    Log.d(TAG, "Routed audio via setCommunicationDevice(SPEAKER): $routed")
                    routing = "BUILTIN_SPEAKER (API 31+)"
                }
            }
            @Suppress("DEPRECATION")
            audioManager.isSpeakerphoneOn = true

            // Ensure audible call/media volume
            try {
                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL)
                val currVol = audioManager.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
                if (currVol == 0 && maxVol > 0) {
                    audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, (maxVol * 0.75f).toInt().coerceAtLeast(1), 0)
                }
            } catch (ignored: Exception) {}

            routing
        } catch (e: Exception) {
            Log.w(TAG, "Failed to route audio to speaker: ${e.message}")
            "ROUTING_FAILED: ${e.message}"
        }
    }

    private fun getRoutingModeString(): String {
        return when (audioManager.mode) {
            AudioManager.MODE_IN_COMMUNICATION -> "MODE_IN_COMMUNICATION"
            AudioManager.MODE_IN_CALL -> "MODE_IN_CALL"
            AudioManager.MODE_RINGTONE -> "MODE_RINGTONE"
            else -> "MODE_NORMAL"
        }
    }

    fun setMuted(muted: Boolean) {
        isMuted = muted
        onRoutingChanged?.invoke(
            true,
            getRoutingModeString(),
            if (muted) "Audio Muted by User" else "Speakerphone Playout Active"
        )
    }

    fun setVolume(volume: Float) {
        currentVolume = volume.coerceIn(0.0f, 1.0f)
    }

    fun pause() {
        isPlaying = false
        onRoutingChanged?.invoke(false, getRoutingModeString(), "Paused")
    }

    fun release() {
        isPlaying = false

        // Abandon Audio Focus
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(focusChangeListener)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error abandoning audio focus: ${e.message}")
        }
        audioFocusRequest = null

        // Reset Audio Routing
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                audioManager.clearCommunicationDevice()
            }
            @Suppress("DEPRECATION")
            audioManager.isSpeakerphoneOn = false
            audioManager.mode = AudioManager.MODE_NORMAL
            Log.i(TAG, "Audio mode reset to MODE_NORMAL")
        } catch (e: Exception) {
            Log.w(TAG, "Error resetting audio mode: ${e.message}")
        }

        onRoutingChanged?.invoke(false, "MODE_NORMAL", "Released")
    }
}
