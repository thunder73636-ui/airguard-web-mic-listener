package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.MediaDiagnostics
import org.webrtc.SurfaceViewRenderer

/**
 * WebRTC video surface that embeds an org.webrtc.SurfaceViewRenderer,
 * attaches it to the WebRtcManager video track pipeline, and provides
 * real-time frame status overlays.
 */
@Composable
fun RemoteVideoSurface(
    webRtcManager: WebRtcManager,
    diagnostics: MediaDiagnostics,
    deviceName: String,
    modifier: Modifier = Modifier
) {
    var rendererRef by remember { mutableStateOf<SurfaceViewRenderer?>(null) }

    DisposableEffect(webRtcManager) {
        onDispose {
            rendererRef?.let { webRtcManager.detachVideoRenderer(it) }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)),
        contentAlignment = Alignment.Center
    ) {
        // Hardware WebRTC SurfaceViewRenderer
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                SurfaceViewRenderer(context).apply {
                    id = android.view.View.generateViewId()
                    setZOrderMediaOverlay(true)
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    webRtcManager.attachVideoRenderer(this)
                    rendererRef = this
                }
            },
            onRelease = { view ->
                webRtcManager.detachVideoRenderer(view)
                rendererRef = null
            }
        )

        // Overlay when no frames have been decoded/received yet
        if (diagnostics.videoFramesReceivedCount == 0L) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A).copy(alpha = 0.92f))
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color(0xFF1E293B), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (diagnostics.remoteVideoTrackReceived) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(32.dp),
                            color = Color(0xFF38BDF8),
                            strokeWidth = 3.dp
                        )
                    } else {
                        Icon(
                            Icons.Outlined.Videocam,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                val statusText = when {
                    diagnostics.remoteVideoTrackReceived ->
                        "Remote Video Track Connected\nAwaiting first video frame from $deviceName..."
                    diagnostics.sessionCreated ->
                        "WebRTC Session Active (ICE: ${diagnostics.iceConnectionState})\nAwaiting remote video track from $deviceName..."
                    else ->
                        "Negotiating media pipeline with $deviceName..."
                }

                Text(
                    text = statusText,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Signaling: ${diagnostics.signalingState} | Track: ${if (diagnostics.remoteVideoTrackReceived) "Received" else "Pending"}",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp
                )
            }
        }
    }
}
