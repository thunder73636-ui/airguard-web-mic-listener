package com.example.media

import android.content.Context
import android.util.Log
import com.example.data.model.DiagnosticStageStatus
import com.example.data.model.MediaDiagnostics
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.concurrent.atomic.AtomicLong

/**
 * WebRTCManager manages the WebRTC PeerConnection, EGL hardware context,
 * JavaAudioDeviceModule audio playout, audio/video track lifecycle,
 * and comprehensive real-time diagnostics for Child device media streaming.
 *
 * Implements PeerConnection.Observer and DataChannel.Observer with comprehensive logging
 * for all connection state changes, ICE candidate gathering events, and track addition/removal events.
 */
class WebRTCManager(private val context: Context) : PeerConnection.Observer, DataChannel.Observer {
    val hasTurnConfiguration: Boolean
        get() = TurnServerConfig.isConfigured(
            com.example.BuildConfig.TURN_SERVER_URL,
            com.example.BuildConfig.TURN_USERNAME,
            com.example.BuildConfig.TURN_CREDENTIAL
        )

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private var activeDataChannel: DataChannel? = null

    val eglBase: EglBase? by lazy {
        try {
            EglBase.create()
        } catch (t: Throwable) {
            Log.w(TAG, "EglBase creation notice: ${t.message}")
            null
        }
    }

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    @Volatile private var peerConnectionGeneration = 0L
    private var remoteVideoTrack: VideoTrack? = null
    private var remoteAudioTrack: AudioTrack? = null
    private var currentVideoSink: SurfaceViewRenderer? = null

    private val pendingRemoteCandidates = mutableListOf<IceCandidate>()
    @Volatile
    private var isRemoteDescriptionSet = false

    private val _diagnostics = MutableStateFlow(MediaDiagnostics())
    val diagnostics: StateFlow<MediaDiagnostics> = _diagnostics.asStateFlow()

    private val frameCounter = AtomicLong(0)
    private val audioBytesCounter = AtomicLong(0)
    private var statsJob: Job? = null
    private var timerJob: Job? = null
    private var startTimeMillis: Long = 0

    var onLocalIceCandidate: ((IceCandidate) -> Unit)? = null
    var onRemoteControlMessage: ((String) -> Unit)? = null
    var onPeerConnectionStateChanged: ((PeerConnection.PeerConnectionState) -> Unit)? = null

    companion object {
        private const val TAG = "WebRTCManager"
        private val ICE_SERVERS = iceServersForBuild()

        private fun iceServersForBuild(): List<PeerConnection.IceServer> = buildList {
            add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
            val urls = TurnServerConfig.urls(com.example.BuildConfig.TURN_SERVER_URL)
                .filter(TurnServerConfig::isIceServerUrl)
            urls.forEach { url ->
                val builder = PeerConnection.IceServer.builder(url)
                if (TurnServerConfig.isTurnUrl(url)) {
                    builder.setUsername(com.example.BuildConfig.TURN_USERNAME)
                        .setPassword(com.example.BuildConfig.TURN_CREDENTIAL)
                }
                add(builder.createIceServer())
            }
        }
    }

    private val frameCountSink = VideoSink { _ ->
        val count = frameCounter.incrementAndGet()
        if (count == 1L) {
            updateDiagnostics {
                copy(
                    videoFramesReceivedCount = 1L,
                    overallStatus = DiagnosticStageStatus.RECEIVING_MEDIA
                )
            }
        }
    }

    init {
        initializeFactory()
    }

    private fun initializeFactory() {
        try {
            val initOptions = PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
            PeerConnectionFactory.initialize(initOptions)

            val base = eglBase
            val builder = PeerConnectionFactory.builder()
                .setOptions(PeerConnectionFactory.Options())

            // Configure hardware-accelerated JavaAudioDeviceModule for incoming audio playout
            try {
                val adm = JavaAudioDeviceModule.builder(context)
                    .setUseHardwareAcousticEchoCanceler(true)
                    .setUseHardwareNoiseSuppressor(true)
                    .createAudioDeviceModule()
                builder.setAudioDeviceModule(adm)
                Log.i(TAG, "Configured JavaAudioDeviceModule for WebRTC audio")
            } catch (t: Throwable) {
                Log.w(TAG, "AudioDeviceModule configuration notice: ${t.message}")
            }

            if (base != null) {
                builder.setVideoDecoderFactory(DefaultVideoDecoderFactory(base.eglBaseContext))
                builder.setVideoEncoderFactory(DefaultVideoEncoderFactory(base.eglBaseContext, true, true))
            }

            peerConnectionFactory = builder.createPeerConnectionFactory()
            Log.i(TAG, "PeerConnectionFactory initialized")
        } catch (t: Throwable) {
            Log.w(TAG, "PeerConnectionFactory initialization notice: ${t.message}")
            recordException("WebRTC native library notice: ${t.message}")
        }
    }

    fun startSession(streamType: String, forceRelay: Boolean = false): Boolean {
        startTimeMillis = System.currentTimeMillis()
        frameCounter.set(0)
        audioBytesCounter.set(0)
        isRemoteDescriptionSet = false
        synchronized(pendingRemoteCandidates) {
            pendingRemoteCandidates.clear()
        }

        updateDiagnostics {
            MediaDiagnostics(
                streamType = streamType,
                overallStatus = DiagnosticStageStatus.WAITING,
                requestDispatched = true,
                sessionCreated = false,
                rendererStatus = if (currentVideoSink != null) "Renderer ready" else "Waiting for SurfaceView",
                elapsedSeconds = 0
            )
        }

        startTimer()

        val factory = peerConnectionFactory
        if (factory == null) {
            recordException("PeerConnectionFactory not available")
            updateDiagnostics { copy(overallStatus = DiagnosticStageStatus.CONNECTION_FAILED) }
            return false
        }

        try {
            closeExistingPeerConnection()

            val rtcConfig = PeerConnection.RTCConfiguration(ICE_SERVERS).apply {
                tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.ENABLED
                bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
                rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
                continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
                if (forceRelay) iceTransportsType = PeerConnection.IceTransportsType.RELAY
            }

            val generation = peerConnectionGeneration
            peerConnection = factory.createPeerConnection(rtcConfig, observerForGeneration(generation))
            if (peerConnection == null) {
                recordException("Failed creating PeerConnection from factory")
                updateDiagnostics { copy(overallStatus = DiagnosticStageStatus.CONNECTION_FAILED) }
                return false
            }

            // In Unified Plan, parent is receiver (downlink from child device)
            // Add transceivers with RECV_ONLY for video and audio
            if (streamType == "CAMERA" || streamType == "SCREEN_MIRROR") {
                peerConnection?.addTransceiver(
                    MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO,
                    RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.RECV_ONLY)
                )
            }
            if (streamType in setOf("CAMERA", "ONE_WAY_AUDIO", "ACCESSIBILITY_SCREENSHOT")) {
                peerConnection?.addTransceiver(
                    MediaStreamTrack.MediaType.MEDIA_TYPE_AUDIO,
                    RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.RECV_ONLY)
                )
            }

            updateDiagnostics {
                copy(
                    sessionCreated = true,
                    peerConnectionState = "CREATED",
                    iceConnectionState = "NEW"
                )
            }

            startStatsPolling()
            Log.i(TAG, "WebRTC Session initialized for $streamType with RECV_ONLY transceivers")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Exception creating WebRTC session: ${e.message}", e)
            recordException("Session creation failed: ${e.message}")
            updateDiagnostics { copy(overallStatus = DiagnosticStageStatus.CONNECTION_FAILED) }
            return false
        }
    }

    /** Ignore callbacks racing in from a PeerConnection that has already been replaced. */
    private fun observerForGeneration(generation: Long): PeerConnection.Observer =
        object : PeerConnection.Observer by this@WebRTCManager {
            override fun onIceCandidate(candidate: IceCandidate?) {
                if (generation == peerConnectionGeneration) this@WebRTCManager.onIceCandidate(candidate)
            }

            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {
                if (generation == peerConnectionGeneration) this@WebRTCManager.onConnectionChange(newState)
            }

            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                if (generation == peerConnectionGeneration) this@WebRTCManager.onIceConnectionChange(state)
            }

            override fun onAddTrack(receiver: RtpReceiver?, mediaStreams: Array<out MediaStream>?) {
                if (generation == peerConnectionGeneration) this@WebRTCManager.onAddTrack(receiver, mediaStreams)
            }

            override fun onTrack(transceiver: RtpTransceiver?) {
                if (generation == peerConnectionGeneration) this@WebRTCManager.onTrack(transceiver)
            }

            override fun onAddStream(stream: MediaStream?) {
                if (generation == peerConnectionGeneration) this@WebRTCManager.onAddStream(stream)
            }

            override fun onDataChannel(channel: DataChannel?) {
                if (generation == peerConnectionGeneration) this@WebRTCManager.onDataChannel(channel)
            }
        }

    /**
     * Generates a valid WebRTC SDP Offer when Parent acts as offerer.
     * In Unified Plan with RECV_ONLY transceivers already configured,
     * empty MediaConstraints avoids generating duplicate m-lines.
     */
    fun createOffer(
        onOfferCreated: (SessionDescription) -> Unit,
        onFailure: (String) -> Unit = {}
    ) {
        val pc = peerConnection
        if (pc == null) {
            recordException("Cannot create offer: PeerConnection is null")
            onFailure("PeerConnection is unavailable")
            return
        }

        // Proactively initialize data channel so m=application is present in the offer
        if (activeDataChannel == null) {
            createDataChannel("airguard_control")
        }

        val constraints = MediaConstraints()

        pc.createOffer(object : SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription?) {
                if (desc == null) return
                Log.i(TAG, "WebRTC SDP Offer created successfully (${desc.type})")
                pc.setLocalDescription(object : SdpObserver {
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onSetSuccess() {
                        Log.i(TAG, "Local SDP Offer successfully applied")
                        updateDiagnostics { copy(signalingState = "HAVE_LOCAL_OFFER") }
                        onOfferCreated(desc)
                    }
                    override fun onCreateFailure(err: String?) {
                        Log.e(TAG, "Set local SDP error: $err")
                        recordException("Set local SDP failed: $err")
                        onFailure(err ?: "Failed to apply local offer")
                    }
                    override fun onSetFailure(err: String?) {
                        Log.e(TAG, "Set local SDP failed: $err")
                        recordException("Set local SDP failed: $err")
                        onFailure(err ?: "Failed to apply local offer")
                    }
                }, desc)
            }

            override fun onSetSuccess() {}
            override fun onCreateFailure(error: String?) {
                Log.e(TAG, "Create SDP Offer failed: $error")
                recordException("Create offer failed: $error")
                updateDiagnostics { copy(overallStatus = DiagnosticStageStatus.CONNECTION_FAILED) }
                onFailure(error ?: "Offer creation failed")
            }
            override fun onSetFailure(error: String?) {}
        }, constraints)
    }

    /**
     * Creates an SDP Answer when Child device acts as offerer.
     */
    fun createAnswerForRemoteOffer(remoteOfferSdp: String, onAnswerCreated: (SessionDescription) -> Unit) {
        val pc = peerConnection ?: return
        try {
            val sessionDesc = SessionDescription(SessionDescription.Type.OFFER, remoteOfferSdp)
            pc.setRemoteDescription(object : SdpObserver {
                override fun onCreateSuccess(desc: SessionDescription?) {}
                override fun onSetSuccess() {
                    Log.i(TAG, "Remote SDP Offer applied, creating answer...")
                    isRemoteDescriptionSet = true
                    drainPendingCandidates()

                    val constraints = MediaConstraints().apply {
                        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
                        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                    }

                    pc.createAnswer(object : SdpObserver {
                        override fun onCreateSuccess(answerDesc: SessionDescription?) {
                            if (answerDesc == null) return
                            pc.setLocalDescription(object : SdpObserver {
                                override fun onCreateSuccess(p0: SessionDescription?) {}
                                override fun onSetSuccess() {
                                    Log.i(TAG, "Local SDP Answer applied")
                                    updateDiagnostics { copy(signalingState = "STABLE") }
                                    onAnswerCreated(answerDesc)
                                }
                                override fun onCreateFailure(err: String?) {}
                                override fun onSetFailure(err: String?) {}
                            }, answerDesc)
                        }
                        override fun onSetSuccess() {}
                        override fun onCreateFailure(err: String?) {}
                        override fun onSetFailure(err: String?) {}
                    }, constraints)
                }
                override fun onCreateFailure(err: String?) {}
                override fun onSetFailure(err: String?) {
                    Log.e(TAG, "Failed setting remote offer: $err")
                    recordException("Set remote offer failed: $err")
                }
            }, sessionDesc)
        } catch (e: Exception) {
            Log.e(TAG, "Exception parsing remote offer: ${e.message}", e)
        }
    }

    /**
     * Applies the remote SDP Answer received from Child device.
     */
    fun setRemoteAnswer(sdpAnswerText: String, onComplete: ((Boolean) -> Unit)? = null) {
        val pc = peerConnection
        if (pc == null) {
            recordException("Cannot set remote answer: PeerConnection is null")
            onComplete?.invoke(false)
            return
        }

        try {
            val sessionDesc = SessionDescription(SessionDescription.Type.ANSWER, sdpAnswerText)
            pc.setRemoteDescription(object : SdpObserver {
                override fun onCreateSuccess(desc: SessionDescription?) {}
                override fun onSetSuccess() {
                    Log.i(TAG, "Remote SDP Answer successfully applied")
                    isRemoteDescriptionSet = true
                    drainPendingCandidates()

                    updateDiagnostics {
                        copy(
                            signalingState = "STABLE",
                            overallStatus = if (remoteVideoTrackReceived || remoteAudioTrackReceived)
                                DiagnosticStageStatus.RECEIVING_MEDIA else DiagnosticStageStatus.CONNECTED_NO_MEDIA
                        )
                    }
                    onComplete?.invoke(true)
                }

                override fun onCreateFailure(err: String?) {}
                override fun onSetFailure(err: String?) {
                    Log.e(TAG, "Failed setting remote SDP Answer: $err")
                    recordException("Set remote answer failed: $err")
                    updateDiagnostics { copy(overallStatus = DiagnosticStageStatus.CONNECTION_FAILED) }
                    onComplete?.invoke(false)
                }
            }, sessionDesc)
        } catch (e: Exception) {
            Log.e(TAG, "Exception parsing remote SDP Answer: ${e.message}", e)
            recordException("Remote SDP parse error: ${e.message}")
            onComplete?.invoke(false)
        }
    }

    /**
     * Adds an ICE candidate received from Child device signaling.
     * Queues candidate if remote description is not yet set.
     */
    fun addRemoteIceCandidate(candidate: IceCandidate) {
        if (!isRemoteDescriptionSet) {
            synchronized(pendingRemoteCandidates) {
                pendingRemoteCandidates.add(candidate)
            }
            Log.d(TAG, "Queued remote ICE candidate prior to remote description: ${candidate.sdpMid}")
            return
        }

        val pc = peerConnection
        if (pc == null) {
            Log.w(TAG, "PeerConnection is null, skipping candidate")
            return
        }
        try {
            pc.addIceCandidate(candidate)
            Log.d(TAG, "Added remote ICE candidate: ${candidate.sdpMid}")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to add remote ICE candidate: ${e.message}")
        }
    }

    private fun drainPendingCandidates() {
        val pc = peerConnection ?: return
        synchronized(pendingRemoteCandidates) {
            if (pendingRemoteCandidates.isNotEmpty()) {
                Log.i(TAG, "Draining ${pendingRemoteCandidates.size} queued ICE candidates")
                for (cand in pendingRemoteCandidates) {
                    try {
                        pc.addIceCandidate(cand)
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed adding queued ICE candidate: ${e.message}")
                    }
                }
                pendingRemoteCandidates.clear()
            }
        }
    }

    /**
     * Attaches a SurfaceViewRenderer to the active video track.
     */
    fun attachVideoRenderer(renderer: SurfaceViewRenderer) {
        currentVideoSink = renderer
        try {
            val base = eglBase
            if (base != null) {
                try {
                    renderer.init(base.eglBaseContext, null)
                } catch (ise: IllegalStateException) {
                    Log.d(TAG, "SurfaceViewRenderer already initialized: ${ise.message}")
                }
                renderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                renderer.setEnableHardwareScaler(true)
                Log.i(TAG, "SurfaceViewRenderer initialized with EglBase context")
                updateDiagnostics { copy(rendererStatus = "Renderer initialized & attached") }
            } else {
                updateDiagnostics { copy(rendererStatus = "SurfaceView attached") }
            }

            remoteVideoTrack?.let { track ->
                try {
                    track.removeSink(renderer)
                } catch (ignored: Exception) {}
                track.addSink(renderer)
                track.setEnabled(true)
                Log.i(TAG, "Attached remote video track to SurfaceViewRenderer")
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Error initializing SurfaceViewRenderer: ${t.message}", t)
            recordException("Renderer init error: ${t.message}")
            updateDiagnostics { copy(rendererStatus = "Renderer init notice: ${t.message}") }
        }
    }

    fun detachVideoRenderer(renderer: SurfaceViewRenderer) {
        try {
            remoteVideoTrack?.removeSink(renderer)
            renderer.release()
            if (currentVideoSink == renderer) {
                currentVideoSink = null
            }
            updateDiagnostics { copy(rendererStatus = "Renderer detached") }
        } catch (e: Exception) {
            Log.w(TAG, "Error detaching renderer: ${e.message}")
        }
    }

    fun setAudioMuted(isMuted: Boolean) {
        remoteAudioTrack?.setEnabled(!isMuted)
        remoteAudioTrack?.setVolume(if (isMuted) 0.0 else 1.0)
        updateDiagnostics { copy(audioTrackUnmuted = !isMuted) }
    }

    fun setAudioVolume(volume: Float) {
        val vol = volume.coerceIn(0f, 1f).toDouble()
        remoteAudioTrack?.setVolume(vol)
    }

    fun setCameraMirror(isFront: Boolean) {
        currentVideoSink?.setMirror(isFront)
    }

    // =========================================================================
    // PeerConnection.Observer Implementation with Robust Logging
    // =========================================================================

    override fun onSignalingChange(state: PeerConnection.SignalingState?) {
        val stateName = state?.name ?: "UNKNOWN"
        Log.i(TAG, "[WebRTC State Transition] onSignalingChange -> $stateName (prev=${_diagnostics.value.signalingState})")
        updateDiagnostics { copy(signalingState = stateName) }
    }

    override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
        val stateName = state?.name ?: "UNKNOWN"
        Log.i(TAG, "[WebRTC State Transition] onIceConnectionChange -> $stateName (prev=${_diagnostics.value.iceConnectionState})")
        updateDiagnostics {
            val newOverall = when (state) {
                PeerConnection.IceConnectionState.CONNECTED,
                PeerConnection.IceConnectionState.COMPLETED -> {
                    if (remoteVideoTrackReceived || remoteAudioTrackReceived) {
                        if (videoFramesReceivedCount > 0 || audioBytesReceivedCount > 0) {
                            DiagnosticStageStatus.RECEIVING_MEDIA
                        } else {
                            DiagnosticStageStatus.CONNECTED_NO_MEDIA
                        }
                    } else {
                        DiagnosticStageStatus.CONNECTED_NO_MEDIA
                    }
                }
                PeerConnection.IceConnectionState.FAILED -> DiagnosticStageStatus.CONNECTION_FAILED
                PeerConnection.IceConnectionState.DISCONNECTED -> DiagnosticStageStatus.CONNECTION_FAILED
                else -> overallStatus
            }
            copy(iceConnectionState = stateName, overallStatus = newOverall)
        }
    }

    override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {
        val stateName = newState?.name ?: "UNKNOWN"
        updateDiagnostics { copy(peerConnectionState = stateName) }
        newState?.let { onPeerConnectionStateChanged?.invoke(it) }
        if (newState == PeerConnection.PeerConnectionState.FAILED) {
            updateDiagnostics { copy(overallStatus = DiagnosticStageStatus.CONNECTION_FAILED) }
        }
    }

    override fun onIceConnectionReceivingChange(receiving: Boolean) {
        Log.i(TAG, "[WebRTC ICE Event] onIceConnectionReceivingChange: receiving=$receiving")
    }

    override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {
        val stateName = state?.name ?: "UNKNOWN"
        Log.i(TAG, "[WebRTC ICE Gathering State] onIceGatheringChange -> $stateName")
    }

    override fun onIceCandidate(candidate: IceCandidate?) {
        if (candidate != null) {
            Log.i(
                TAG,
                "[WebRTC ICE Candidate Gathered] sdpMid=${candidate.sdpMid}, " +
                        "sdpMLineIndex=${candidate.sdpMLineIndex}, " +
                        "serverUrl=${candidate.serverUrl}, " +
                        "candidate=${candidate.sdp.trim()}"
            )
            onLocalIceCandidate?.invoke(candidate)
        } else {
            Log.w(TAG, "[WebRTC ICE Candidate] onIceCandidate invoked with null candidate")
        }
    }

    override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {
        val count = candidates?.size ?: 0
        Log.i(TAG, "[WebRTC ICE Event] onIceCandidatesRemoved: count=$count")
    }

    override fun onAddStream(stream: MediaStream?) {
        val videoCount = stream?.videoTracks?.size ?: 0
        val audioCount = stream?.audioTracks?.size ?: 0
        Log.i(
            TAG,
            "[WebRTC Media Event] onAddStream (legacy stream): streamId=${stream?.id}, " +
                    "videoTracks=$videoCount, audioTracks=$audioCount"
        )
        stream?.videoTracks?.firstOrNull()?.let { handleRemoteVideoTrack(it) }
        stream?.audioTracks?.firstOrNull()?.let { handleRemoteAudioTrack(it) }
    }

    override fun onRemoveStream(stream: MediaStream?) {
        Log.i(TAG, "[WebRTC Media Event] onRemoveStream: streamId=${stream?.id}")
    }

    override fun onDataChannel(channel: DataChannel?) {
        Log.i(
            TAG,
            "[WebRTC DataChannel Event] onDataChannel received: label=${channel?.label()}, " +
                    "id=${channel?.id()}, state=${channel?.state()}"
        )
        activeDataChannel = channel
        channel?.registerObserver(this)
    }

    override fun onRenegotiationNeeded() {
        Log.i(TAG, "[WebRTC Connection Event] onRenegotiationNeeded")
    }

    override fun onAddTrack(receiver: RtpReceiver?, mediaStreams: Array<out MediaStream>?) {
        val track = receiver?.track()
        Log.i(
            TAG,
            "[WebRTC Media Track Event] onAddTrack: id=${track?.id()}, kind=${track?.kind()}, " +
                    "enabled=${track?.enabled()}, streams=${mediaStreams?.map { it.id }}"
        )
        when (track) {
            is VideoTrack -> handleRemoteVideoTrack(track)
            is AudioTrack -> handleRemoteAudioTrack(track)
        }
    }

    override fun onTrack(transceiver: RtpTransceiver?) {
        val track = transceiver?.receiver?.track()
        Log.i(
            TAG,
            "[WebRTC Media Track Event] onTrack (Unified Plan): mid=${transceiver?.mid}, " +
                    "direction=${transceiver?.direction}, kind=${track?.kind()}, id=${track?.id()}"
        )
        when (track) {
            is VideoTrack -> handleRemoteVideoTrack(track)
            is AudioTrack -> handleRemoteAudioTrack(track)
        }
    }

    override fun onRemoveTrack(receiver: RtpReceiver?) {
        val track = receiver?.track()
        Log.i(
            TAG,
            "[WebRTC Media Track Event] onRemoveTrack: id=${track?.id()}, kind=${track?.kind()}"
        )
    }

    // =========================================================================
    // DataChannel.Observer Implementation with Robust Logging
    // =========================================================================

    override fun onBufferedAmountChange(previousAmount: Long) {
        val currentAmount = activeDataChannel?.bufferedAmount() ?: 0L
        Log.d(
            TAG,
            "[WebRTC DataChannel State] onBufferedAmountChange: channel=${activeDataChannel?.label()}, " +
                    "previousAmount=$previousAmount, currentAmount=$currentAmount"
        )
    }

    override fun onStateChange() {
        val state = activeDataChannel?.state()
        Log.i(
            TAG,
            "[WebRTC DataChannel State Transition] onStateChange -> $state (channel=${activeDataChannel?.label()})"
        )
    }

    override fun onMessage(buffer: DataChannel.Buffer?) {
        if (buffer == null) return
        val isBinary = buffer.binary
        val byteCount = buffer.data.remaining()
        val textContent = try {
            val bytes = ByteArray(byteCount)
            buffer.data.get(bytes)
            String(bytes, Charsets.UTF_8)
        } catch (e: Exception) {
            "Unable to parse ($byteCount bytes)"
        }
        val messageType = runCatching { org.json.JSONObject(textContent).optString("type", "CONTROL") }
            .getOrDefault("UNPARSEABLE")
        Log.d(
            TAG,
            "[WebRTC DataChannel Message] type=$messageType, binary=$isBinary, bytesReceived=$byteCount, channel=${activeDataChannel?.label()}"
        )
        onRemoteControlMessage?.invoke(textContent)
    }

    /**
     * Sends a command or message payload over the active WebRTC DataChannel.
     */
    fun sendDataChannelMessage(message: String): Boolean {
        val dc = activeDataChannel
        if (dc != null && dc.state() == DataChannel.State.OPEN) {
            return try {
                val bytes = message.toByteArray(Charsets.UTF_8)
                val buffer = DataChannel.Buffer(java.nio.ByteBuffer.wrap(bytes), false)
                val sent = dc.send(buffer)
                val action = runCatching { org.json.JSONObject(message).optString("action", "CONTROL") }
                    .getOrDefault("CONTROL")
                Log.d(TAG, "[WebRTC DataChannel Send] channel=${dc.label()}, sent=$sent, action=$action, bytes=${bytes.size}")
                sent
            } catch (e: Exception) {
                Log.w(TAG, "[WebRTC DataChannel Send] Error sending message: ${e.message}")
                false
            }
        }
        Log.d(TAG, "[WebRTC DataChannel Send] Channel unavailable (dc=${dc?.label()}, state=${dc?.state()})")
        return false
    }

    private fun handleRemoteVideoTrack(track: VideoTrack) {
        remoteVideoTrack = track
        track.setEnabled(true)
        Log.i(TAG, "Received remote VideoTrack: ${track.id()}, enabled: ${track.enabled()}")

        // Attach frame counter sink idempotently
        try {
            track.removeSink(frameCountSink)
        } catch (ignored: Exception) {}
        track.addSink(frameCountSink)

        // Attach to active renderer if ready
        currentVideoSink?.let { renderer ->
            try {
                track.removeSink(renderer)
            } catch (ignored: Exception) {}
            track.addSink(renderer)
            Log.i(TAG, "Attached VideoTrack directly to active SurfaceViewRenderer")
        }

        updateDiagnostics {
            copy(
                remoteVideoTrackReceived = true,
                overallStatus = if (videoFramesReceivedCount > 0) DiagnosticStageStatus.RECEIVING_MEDIA else DiagnosticStageStatus.CONNECTED_NO_MEDIA
            )
        }
    }

    private fun handleRemoteAudioTrack(track: AudioTrack) {
        remoteAudioTrack = track
        track.setEnabled(true)
        track.setVolume(1.0)
        Log.i(TAG, "Received remote AudioTrack: ${track.id()}, enabled: ${track.enabled()}")

        updateDiagnostics {
            copy(
                remoteAudioTrackReceived = true,
                audioTrackEnabled = track.enabled(),
                audioTrackUnmuted = true,
                audioPlaybackStatus = "WebRTC AudioTrack Playout Active",
                overallStatus = DiagnosticStageStatus.RECEIVING_MEDIA
            )
        }
    }

    private fun startStatsPolling() {
        statsJob?.cancel()
        statsJob = scope.launch {
            while (isActive) {
                delay(1000)
                val pc = peerConnection ?: break
                pc.getStats { report ->
                    var newFrames: Long? = null
                    var newBytes: Long? = null

                    for (stat in report.statsMap.values) {
                        if (stat.type == "inbound-rtp") {
                            val kind = stat.members["kind"] as? String
                            if (kind == "video") {
                                val frames = (stat.members["framesReceived"] as? Number)?.toLong()
                                    ?: (stat.members["framesDecoded"] as? Number)?.toLong()
                                if (frames != null) newFrames = frames
                            } else if (kind == "audio") {
                                val bytes = (stat.members["bytesReceived"] as? Number)?.toLong()
                                if (bytes != null) newBytes = bytes
                            }
                        }
                    }

                    if (newFrames != null && newFrames > 0) {
                        frameCounter.set(newFrames)
                    }
                    if (newBytes != null && newBytes > 0) {
                        audioBytesCounter.set(newBytes)
                    }

                    updateDiagnostics {
                        copy(
                            videoFramesReceivedCount = frameCounter.get(),
                            audioBytesReceivedCount = audioBytesCounter.get(),
                            overallStatus = if (frameCounter.get() > 0 || audioBytesCounter.get() > 0)
                                DiagnosticStageStatus.RECEIVING_MEDIA else overallStatus
                        )
                    }
                }
            }
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive) {
                delay(1000)
                val elapsed = (System.currentTimeMillis() - startTimeMillis) / 1000
                updateDiagnostics { copy(elapsedSeconds = elapsed) }
            }
        }
    }

    fun updateAudioRoutingDiagnostics(focusGranted: Boolean, routingMode: String, playbackStatus: String) {
        updateDiagnostics {
            copy(
                audioFocusGranted = focusGranted,
                audioRoutingMode = routingMode,
                audioPlaybackStatus = playbackStatus
            )
        }
    }

    private fun recordException(msg: String) {
        updateDiagnostics {
            copy(
                lastExceptionMessage = msg,
                lastErrorTimestamp = System.currentTimeMillis()
            )
        }
    }

    private inline fun updateDiagnostics(transform: MediaDiagnostics.() -> MediaDiagnostics) {
        _diagnostics.value = _diagnostics.value.transform()
    }

    private fun closeExistingPeerConnection() {
        peerConnectionGeneration++
        statsJob?.cancel()
        statsJob = null
        remoteVideoTrack?.let { track ->
            currentVideoSink?.let { track.removeSink(it) }
            track.removeSink(frameCountSink)
        }
        remoteVideoTrack = null
        remoteAudioTrack = null
        isRemoteDescriptionSet = false
        synchronized(pendingRemoteCandidates) {
            pendingRemoteCandidates.clear()
        }
        activeDataChannel?.unregisterObserver()
        try {
            activeDataChannel?.dispose()
        } catch (ignored: Exception) {}
        activeDataChannel = null
        try {
            peerConnection?.dispose()
        } catch (e: Exception) {
            Log.w(TAG, "Error disposing peer connection: ${e.message}")
        }
        peerConnection = null
    }

    /**
     * Creates and registers a local DataChannel for control messages, latency ping, and telemetry.
     */
    fun createDataChannel(label: String = "airguard_control"): DataChannel? {
        val pc = peerConnection ?: return null
        return try {
            val init = DataChannel.Init().apply {
                ordered = true
            }
            val dc = pc.createDataChannel(label, init)
            dc?.let {
                activeDataChannel = it
                it.registerObserver(this)
                Log.i(TAG, "[WebRTC DataChannel] Created local data channel: label=$label, id=${it.id()}")
            }
            dc
        } catch (e: Exception) {
            Log.w(TAG, "[WebRTC DataChannel] Failed creating data channel: ${e.message}")
            null
        }
    }

    fun close() {
        timerJob?.cancel()
        timerJob = null
        statsJob?.cancel()
        statsJob = null
        closeExistingPeerConnection()
        currentVideoSink = null
        updateDiagnostics {
            copy(
                overallStatus = DiagnosticStageStatus.NOT_STARTED,
                peerConnectionState = "CLOSED",
                iceConnectionState = "CLOSED"
            )
        }
    }
}

/**
 * Typealias providing backwards compatibility for WebRtcManager references.
 */
typealias WebRtcManager = WebRTCManager

