package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun ChildMascotAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Background circular frame
        drawCircle(
            color = Color(0xFFCCFBF1),
            radius = w * 0.48f,
            center = Offset(w * 0.5f, h * 0.5f)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.8f),
            radius = w * 0.48f,
            center = Offset(w * 0.5f, h * 0.5f),
            style = Stroke(width = 1.5.dp.toPx())
        )

        // Green sprout leaf at top
        val leafPath = Path().apply {
            moveTo(w * 0.5f, h * 0.28f)
            quadraticTo(w * 0.42f, h * 0.12f, w * 0.34f, h * 0.14f)
            quadraticTo(w * 0.36f, h * 0.24f, w * 0.5f, h * 0.28f)
            quadraticTo(w * 0.58f, h * 0.10f, w * 0.68f, h * 0.12f)
            quadraticTo(w * 0.64f, h * 0.24f, w * 0.5f, h * 0.28f)
            close()
        }
        drawPath(leafPath, color = Color(0xFF34D399))

        // Cute round purple body
        val bodyCenter = Offset(w * 0.5f, h * 0.56f)
        val bodyRadius = w * 0.34f
        drawCircle(
            color = Color(0xFF7C3AED),
            radius = bodyRadius,
            center = bodyCenter
        )

        // Left Eye
        drawCircle(
            color = Color(0xFF1E1B4B),
            radius = w * 0.08f,
            center = Offset(w * 0.41f, h * 0.54f)
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.035f,
            center = Offset(w * 0.395f, h * 0.52f)
        )

        // Right Eye
        drawCircle(
            color = Color(0xFF1E1B4B),
            radius = w * 0.08f,
            center = Offset(w * 0.59f, h * 0.54f)
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.035f,
            center = Offset(w * 0.575f, h * 0.52f)
        )

        // Smiling mouth
        val mouthPath = Path().apply {
            moveTo(w * 0.46f, h * 0.65f)
            quadraticTo(w * 0.50f, h * 0.70f, w * 0.54f, h * 0.65f)
        }
        drawPath(
            mouthPath,
            color = Color(0xFF4C1D95),
            style = Stroke(width = 1.8.dp.toPx())
        )

        // Rosy cheeks
        drawCircle(
            color = Color(0xFFF472B6).copy(alpha = 0.5f),
            radius = w * 0.045f,
            center = Offset(w * 0.32f, h * 0.62f)
        )
        drawCircle(
            color = Color(0xFFF472B6).copy(alpha = 0.5f),
            radius = w * 0.045f,
            center = Offset(w * 0.68f, h * 0.62f)
        )
    }
}
