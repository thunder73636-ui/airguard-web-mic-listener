package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun InstantBlockIcon(
    modifier: Modifier = Modifier,
    size: Dp = 26.dp,
    tint: Color = Color(0xFF1E293B)
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeWidth = 2.dp.toPx()

        val shacklePath = Path().apply {
            moveTo(w * 0.30f, h * 0.45f)
            lineTo(w * 0.30f, h * 0.26f)
            cubicTo(w * 0.30f, h * 0.10f, w * 0.70f, h * 0.10f, w * 0.70f, h * 0.26f)
            lineTo(w * 0.70f, h * 0.45f)
        }
        drawPath(shacklePath, color = tint, style = Stroke(width = strokeWidth))

        drawRoundRect(
            color = tint,
            topLeft = Offset(w * 0.18f, h * 0.42f),
            size = Size(w * 0.64f, h * 0.52f),
            cornerRadius = CornerRadius(5.dp.toPx(), 5.dp.toPx()),
            style = Stroke(width = strokeWidth)
        )

        val boltPath = Path().apply {
            moveTo(w * 0.52f, h * 0.48f)
            lineTo(w * 0.40f, h * 0.68f)
            lineTo(w * 0.50f, h * 0.68f)
            lineTo(w * 0.46f, h * 0.86f)
            lineTo(w * 0.62f, h * 0.64f)
            lineTo(w * 0.52f, h * 0.64f)
            close()
        }
        drawPath(boltPath, color = tint)
    }
}

@Composable
fun DowntimeHourglassIcon(
    modifier: Modifier = Modifier,
    size: Dp = 26.dp,
    tint: Color = Color(0xFF1E293B)
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeWidth = 2.dp.toPx()

        drawCircle(
            color = tint,
            radius = w * 0.42f,
            center = Offset(w * 0.5f, h * 0.5f),
            style = Stroke(width = strokeWidth)
        )

        val hgPath = Path().apply {
            moveTo(w * 0.36f, h * 0.30f)
            lineTo(w * 0.64f, h * 0.30f)
            lineTo(w * 0.52f, h * 0.50f)
            lineTo(w * 0.64f, h * 0.70f)
            lineTo(w * 0.36f, h * 0.70f)
            lineTo(w * 0.48f, h * 0.50f)
            close()
        }
        drawPath(hgPath, color = tint, style = Stroke(width = 1.5.dp.toPx()))

        drawCircle(color = tint, radius = 1.dp.toPx(), center = Offset(w * 0.5f, h * 0.52f))
        drawCircle(color = tint, radius = 1.dp.toPx(), center = Offset(w * 0.5f, h * 0.64f))
    }
}

@Composable
fun AppManagementGridIcon(
    modifier: Modifier = Modifier,
    size: Dp = 26.dp,
    tint: Color = Color(0xFF1E293B)
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeWidth = 2.dp.toPx()

        drawRoundRect(
            color = tint,
            topLeft = Offset(w * 0.35f, h * 0.12f),
            size = Size(w * 0.30f, h * 0.30f),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
            style = Stroke(width = strokeWidth)
        )
        drawRoundRect(
            color = tint,
            topLeft = Offset(w * 0.14f, h * 0.56f),
            size = Size(w * 0.30f, h * 0.30f),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
            style = Stroke(width = strokeWidth)
        )
        drawCircle(
            color = tint,
            radius = w * 0.16f,
            center = Offset(w * 0.74f, h * 0.71f),
            style = Stroke(width = strokeWidth)
        )
        drawCircle(
            color = tint,
            radius = w * 0.05f,
            center = Offset(w * 0.74f, h * 0.71f)
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.45f, h * 0.42f),
            end = Offset(w * 0.32f, h * 0.56f),
            strokeWidth = strokeWidth
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.55f, h * 0.42f),
            end = Offset(w * 0.68f, h * 0.58f),
            strokeWidth = strokeWidth
        )
    }
}
