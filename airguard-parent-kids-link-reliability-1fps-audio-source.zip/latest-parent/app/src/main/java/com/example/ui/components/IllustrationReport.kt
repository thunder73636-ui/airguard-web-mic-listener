package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun IllustrationReport(
    modifier: Modifier = Modifier,
    size: Dp = 72.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Background shadow / aura
        drawCircle(
            color = Color(0xFFD1FAE5).copy(alpha = 0.5f),
            radius = w * 0.42f,
            center = Offset(w * 0.62f, h * 0.45f)
        )

        // Back folded sheet
        val backSheet = Path().apply {
            moveTo(w * 0.28f, h * 0.16f)
            lineTo(w * 0.86f, h * 0.16f)
            lineTo(w * 0.80f, h * 0.88f)
            lineTo(w * 0.22f, h * 0.88f)
            close()
        }
        drawPath(backSheet, color = Color(0xFF93C5FD))

        // Front main white sheet
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(w * 0.18f, h * 0.22f),
            size = Size(w * 0.62f, h * 0.70f),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFFCBD5E1),
            topLeft = Offset(w * 0.18f, h * 0.22f),
            size = Size(w * 0.62f, h * 0.70f),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx()),
            style = Stroke(width = 1.5.dp.toPx())
        )

        // Header notch
        drawRoundRect(
            color = Color(0xFF8D7BD0),
            topLeft = Offset(w * 0.38f, h * 0.19f),
            size = Size(w * 0.22f, h * 0.08f),
            cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
        )

        // Pie chart circle inside document
        val pieCenter = Offset(w * 0.38f, h * 0.60f)
        val pieRadius = w * 0.14f
        drawArc(
            color = Color(0xFF10B981),
            startAngle = -45f,
            sweepAngle = 140f,
            useCenter = true,
            topLeft = Offset(pieCenter.x - pieRadius, pieCenter.y - pieRadius),
            size = Size(pieRadius * 2, pieRadius * 2)
        )
        drawArc(
            color = Color(0xFF8D7BD0),
            startAngle = 95f,
            sweepAngle = 110f,
            useCenter = true,
            topLeft = Offset(pieCenter.x - pieRadius, pieCenter.y - pieRadius),
            size = Size(pieRadius * 2, pieRadius * 2)
        )
        drawArc(
            color = Color(0xFFA78BFA),
            startAngle = 205f,
            sweepAngle = 110f,
            useCenter = true,
            topLeft = Offset(pieCenter.x - pieRadius, pieCenter.y - pieRadius),
            size = Size(pieRadius * 2, pieRadius * 2)
        )

        // Text lines
        val lineX = w * 0.58f
        drawLine(
            color = Color(0xFF94A3B8),
            start = Offset(lineX, h * 0.50f),
            end = Offset(w * 0.72f, h * 0.50f),
            strokeWidth = 2.dp.toPx()
        )
        drawLine(
            color = Color(0xFFCBD5E1),
            start = Offset(lineX, h * 0.60f),
            end = Offset(w * 0.70f, h * 0.60f),
            strokeWidth = 2.dp.toPx()
        )
        drawLine(
            color = Color(0xFFE2E8F0),
            start = Offset(lineX, h * 0.70f),
            end = Offset(w * 0.68f, h * 0.70f),
            strokeWidth = 2.dp.toPx()
        )
    }
}
