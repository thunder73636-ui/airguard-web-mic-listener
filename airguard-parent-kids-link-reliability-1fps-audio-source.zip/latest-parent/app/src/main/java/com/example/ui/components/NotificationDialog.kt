package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.NotificationLog
import com.example.data.repository.ParentRepository
import com.example.ui.theme.AirBluePrimary
import kotlinx.coroutines.flow.flowOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotificationDialog(
    deviceName: String,
    deviceId: String?,
    hasNotificationAccess: Boolean,
    repository: ParentRepository,
    onDismiss: () -> Unit
) {
    val notificationFlow = remember(repository, deviceId) {
        deviceId?.let(repository::observeNotifications) ?: flowOf(emptyList())
    }
    val notifications by notificationFlow.collectAsState(initial = emptyList())

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Child Notifications", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(deviceName, fontSize = 12.sp, color = Color.Gray)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }
                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = Color(0xFFF1F5F9))

                when {
                    deviceId == null -> EmptyNotificationState("Pair a child device to view its notification history.")
                    !hasNotificationAccess -> EmptyNotificationState("Notification Access is off on the child phone. Enable AirGuard Kids under Android Settings > Notification access to sync notifications.")
                    notifications.isEmpty() -> EmptyNotificationState("No child notifications have synced yet. New notifications will appear here while the child phone is connected.")
                    else -> {
                        Text(
                            "${notifications.size} captured",
                            modifier = Modifier.padding(top = 12.dp, bottom = 8.dp),
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().height(420.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(notifications.take(100), key = { it.id }) { notification ->
                                NotificationRow(notification)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyNotificationState(message: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Notifications, contentDescription = null, tint = AirBluePrimary)
        Spacer(Modifier.height(10.dp))
        Text(message, fontSize = 13.sp, color = Color.Gray)
    }
}

@Composable
private fun NotificationRow(notification: NotificationLog) {
    val time = remember(notification.timestamp) {
        SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(notification.timestamp))
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF8FAFC)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Surface(shape = CircleShape, color = AirBluePrimary.copy(alpha = 0.12f)) {
                Icon(
                    Icons.Default.Notifications,
                    contentDescription = null,
                    tint = AirBluePrimary,
                    modifier = Modifier.padding(8.dp)
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(notification.appName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(time, fontSize = 10.sp, color = Color.Gray)
                }
                if (notification.sender.isNotBlank()) {
                    Text(notification.sender, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                }
                if (notification.content.isNotBlank()) {
                    Text(notification.content, fontSize = 12.sp, color = Color(0xFF475569))
                }
            }
        }
    }
}
