package com.example.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AirProPurple
import com.example.ui.theme.AirProPurpleBg

@Composable
fun ProBadge(
    modifier: Modifier = Modifier,
    text: String = "PRO"
) {
    Surface(
        modifier = modifier,
        color = AirProPurpleBg,
        shape = RoundedCornerShape(4.dp)
    ) {
        Text(
            text = text,
            color = AirProPurple,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
