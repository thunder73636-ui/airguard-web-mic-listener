package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun RemoteCamera3DIcon(
    modifier: Modifier = Modifier,
    size: Dp = 56.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        drawRoundRect(
            color = Color(0xFF10B981),
            topLeft = Offset(w * 0.12f, h * 0.28f),
            size = Size(w * 0.76f, h * 0.54f),
            cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFF059669),
            topLeft = Offset(w * 0.32f, h * 0.20f),
            size = Size(w * 0.24f, h * 0.14f),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )
        drawCircle(
            color = Color(0xFFFBBF24),
            radius = w * 0.05f,
            center = Offset(w * 0.72f, h * 0.38f)
        )
        drawCircle(
            color = Color(0xFF1E3A8A),
            radius = w * 0.22f,
            center = Offset(w * 0.50f, h * 0.55f)
        )
        drawCircle(
            color = Color(0xFF8D7BD0),
            radius = w * 0.17f,
            center = Offset(w * 0.50f, h * 0.55f)
        )
        drawCircle(
            color = Color(0xFF60A5FA),
            radius = w * 0.09f,
            center = Offset(w * 0.50f, h * 0.55f)
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.04f,
            center = Offset(w * 0.46f, h * 0.50f)
        )
    }
}

@Composable
fun ScreenMirroring3DIcon(
    modifier: Modifier = Modifier,
    size: Dp = 56.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        drawRoundRect(
            color = Color(0xFF7968C4),
            topLeft = Offset(w * 0.38f, h * 0.38f),
            size = Size(w * 0.24f, h * 0.16f),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFF0284C7),
            topLeft = Offset(w * 0.14f, h * 0.24f),
            size = Size(w * 0.28f, h * 0.42f),
            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
        )
        drawCircle(
            color = Color(0xFFF59E0B),
            radius = w * 0.17f,
            center = Offset(w * 0.28f, h * 0.62f)
        )
        drawCircle(
            color = Color(0xFFFDE68A),
            radius = w * 0.10f,
            center = Offset(w * 0.28f, h * 0.62f)
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.035f,
            center = Offset(w * 0.24f, h * 0.58f)
        )
        drawRoundRect(
            color = Color(0xFF0284C7),
            topLeft = Offset(w * 0.58f, h * 0.24f),
            size = Size(w * 0.28f, h * 0.42f),
            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
        )
        drawCircle(
            color = Color(0xFFF59E0B),
            radius = w * 0.17f,
            center = Offset(w * 0.72f, h * 0.62f)
        )
        drawCircle(
            color = Color(0xFFFDE68A),
            radius = w * 0.10f,
            center = Offset(w * 0.72f, h * 0.62f)
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.035f,
            center = Offset(w * 0.68f, h * 0.58f)
        )
    }
}

@Composable
fun OneWayAudio3DIcon(
    modifier: Modifier = Modifier,
    size: Dp = 56.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        val arcPath = Path().apply {
            moveTo(w * 0.22f, h * 0.50f)
            cubicTo(w * 0.22f, h * 0.16f, w * 0.78f, h * 0.16f, w * 0.78f, h * 0.50f)
        }
        drawPath(
            arcPath,
            color = Color(0xFF10B981),
            style = Stroke(width = 6.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFF8D7BD0),
            topLeft = Offset(w * 0.12f, h * 0.44f),
            size = Size(w * 0.20f, h * 0.36f),
            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFF93C5FD),
            topLeft = Offset(w * 0.16f, h * 0.50f),
            size = Size(w * 0.12f, h * 0.24f),
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFF8D7BD0),
            topLeft = Offset(w * 0.68f, h * 0.44f),
            size = Size(w * 0.20f, h * 0.36f),
            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFF93C5FD),
            topLeft = Offset(w * 0.72f, h * 0.50f),
            size = Size(w * 0.12f, h * 0.24f),
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
        )
    }
}
