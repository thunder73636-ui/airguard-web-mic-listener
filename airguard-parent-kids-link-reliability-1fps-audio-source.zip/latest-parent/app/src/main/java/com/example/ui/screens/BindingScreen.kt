package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.util.Log
import android.widget.Toast
import com.example.data.manager.PairingManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PairingSession
import com.example.data.repository.ParentRepository
import com.example.ui.components.QrCodeView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BindingScreen(
    repository: ParentRepository,
    onDeviceAdded: (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var currentSession by remember { mutableStateOf<PairingSession?>(null) }
    val cloudError by repository.pairingManager.cloudError.collectAsState()
    var isCheckingStatus by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }
    var hasCompletedPairing by remember { mutableStateOf(false) }

    fun refreshCode() {
        coroutineScope.launch {
            val session = repository.generatePairingSession("Child Device")
            currentSession = session
        }
    }

    LaunchedEffect(Unit) {
        refreshCode()
    }

    // AUTOMATIC REAL-TIME FIRESTORE LISTENER FOR PAIRING HANDSHAKE
    LaunchedEffect(currentSession?.id) {
        val sid = currentSession?.id ?: return@LaunchedEffect
        repository.pairingManager.observeFirestorePairingSession(sid).collect { session ->
            if (!hasCompletedPairing && session != null && session.status == "PAIRED" && !session.childDeviceId.isNullOrBlank()) {
                val childId = session.childDeviceId
                val result = repository.pairingManager.completePairingFromFirestore(sid, childId)
                result.onSuccess { dev ->
                    val accountUid = repository.authRepository.getResolvedUid()
                    if (accountUid != "parent_user") {
                        runCatching { repository.claimGuestLinkedDevicesForAccount(accountUid) }
                            .onFailure { Log.w("BindingScreen", "Could not save paired child under Google account: ${it.message}") }
                    }
                    hasCompletedPairing = true
                    repository.attachChildTelemetryListeners(dev.id)
                    Toast.makeText(context, "Pairing handshake verified! Linked child device: ${dev.deviceName}", Toast.LENGTH_SHORT).show()
                    onDeviceAdded(dev.id)
                }.onFailure { error ->
                    Log.e("BindingScreen", "Pairing record was not ready: ${error.message}", error)
                    Toast.makeText(context, error.message ?: "Could not load the real child device record. Check Firebase rules and retry.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("AirGuard Kids Pairing Guide", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("How to link your child's phone:", fontWeight = FontWeight.SemiBold)
                    Text("1. Open the AirGuard Kids app on your child's phone.")
                    Text("2. Enter the 9-digit binding code displayed below.")
                    Text("3. Once verified, follow the on-screen permissions wizard to complete protection setup.")
                }
            },
            confirmButton = {
                Button(onClick = { showHelpDialog = false }) { Text("Got It") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            "2-Step Binding",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color(0xFF1E293B)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showHelpDialog = true }) {
                        Icon(Icons.Outlined.MoreVert, contentDescription = "More options")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFFFF8FC))
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Step 1 Card: QR Code & Link
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF8D7BD0),
                                modifier = Modifier.size(24.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("1", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "Install AirGuard Kids on the child's phone, then enter the 9-digit code or paste the QR link.",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF1E293B),
                                lineHeight = 20.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(18.dp))
                        // QR Code inside soft blue rounded frame
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFFF1EDFA),
                            border = BorderStroke(2.dp, Color(0xFFD6CCF0)),
                            modifier = Modifier.padding(4.dp)
                        ) {
                            Box(
                                modifier = Modifier.padding(14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                QrCodeView(
                                    data = currentSession?.qrPayload ?: "https://apps.airdroid.com/kids",
                                    size = 170.dp,
                                    moduleColor = Color(0xFF0F172A)
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.5.dp, Color(0xFFF59E0B)),
                                    shadowElevation = 2.dp,
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF7968C4), modifier = Modifier.size(16.dp))
                                        Text("Kids", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7968C4))
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        // Link button with share icon
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("URL", "https://apps.airdroid.com/kids"))
                                    Toast.makeText(context, "Link copied to clipboard", Toast.LENGTH_SHORT).show()
                                },
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF1F5F9)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp, horizontal = 16.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "apps.airdroid.com/kids",
                                    color = Color(0xFF7968C4),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    Icons.Outlined.Share,
                                    contentDescription = "Share Link",
                                    tint = Color(0xFF7968C4),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
            // Step 2 Card: 9-Digit Code
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF8D7BD0),
                                modifier = Modifier.size(24.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("2", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "Open AirDroid Kids and enter the binding code",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF1E293B)
                            )
                        }
                        if (cloudError != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "⚠ " + cloudError,
                                fontSize = 12.sp,
                                color = Color(0xFFB91C1C),
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            // Never show a made-up code: it does not exist in Firestore and can never pair.
                            text = currentSession?.code ?: "Generating…",
                            fontSize = if (currentSession == null) 20.sp else 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B),
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Waiting for child app to enter code...",
                            color = Color(0xFF7968C4),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            // Check Binding Status Link
            item {
                Row(
                    modifier = Modifier
                        .clickable {
                            coroutineScope.launch {
                                isCheckingStatus = true
                                val session = currentSession
                                val fs = repository.pairingManager.getFirestore()
                                if (session != null && fs != null) {
                                    try {
                                        val doc = fs.collection(PairingManager.COLLECTION_PAIRING_SESSIONS)
                                            .document(session.id)
                                            .get()
                                            .await()
                                        if (doc.exists() && doc.getString("status") == "PAIRED") {
                                            isCheckingStatus = false
                                            val childId = doc.getString("childDeviceId") ?: ""
                                            val result = repository.pairingManager.completePairingFromFirestore(session.id, childId)
                                            result.onSuccess { dev ->
                                                val accountUid = repository.authRepository.getResolvedUid()
                                                if (accountUid != "parent_user") {
                                                    runCatching { repository.claimGuestLinkedDevicesForAccount(accountUid) }
                                                        .onFailure { Log.w("BindingScreen", "Could not save paired child under Google account: ${it.message}") }
                                                }
                                                repository.attachChildTelemetryListeners(dev.id)
                                                Toast.makeText(context, "Pairing confirmed from child device via Firestore!", Toast.LENGTH_SHORT).show()
                                                onDeviceAdded(dev.id)
                                            }
                                            return@launch
                                        }
                                    } catch (e: Exception) {
                                        Log.w("BindingScreen", "Manual check error: ${e.message}")
                                    }
                                }
                                delay(500)
                                isCheckingStatus = false
                                Toast.makeText(context, "Waiting for code entry on child phone...", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Outlined.Build,
                        contentDescription = null,
                        tint = Color(0xFF7968C4),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        if (isCheckingStatus) "Checking Firestore status..." else "Check binding status",
                        color = Color(0xFF7968C4),
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                }
            }
            // Customer Support Bubble
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Surface(
                            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 2.dp),
                            color = Color(0xFF7968C4),
                            modifier = Modifier.clickable { showHelpDialog = true }
                        ) {
                            Text(
                                "Need more help?",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFEAE5F8),
                            border = BorderStroke(2.dp, Color.White),
                            shadowElevation = 3.dp,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.SupportAgent, contentDescription = "Support", tint = Color(0xFF7968C4), modifier = Modifier.size(28.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
