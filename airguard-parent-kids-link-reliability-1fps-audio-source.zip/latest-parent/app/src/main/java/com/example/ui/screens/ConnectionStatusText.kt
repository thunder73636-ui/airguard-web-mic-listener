package com.example.ui.screens

fun deviceLastSeenLabel(timestamp: Long): String {
    if (timestamp <= 0L) return "waiting for first sync"
    val minutes = ((System.currentTimeMillis() - timestamp).coerceAtLeast(0L) / 60_000L).toInt()
    return when {
        minutes < 1 -> "seen just now"
        minutes == 1 -> "seen 1 min ago"
        minutes < 60 -> "seen $minutes min ago"
        else -> "seen ${minutes / 60} hr ago"
    }
}
