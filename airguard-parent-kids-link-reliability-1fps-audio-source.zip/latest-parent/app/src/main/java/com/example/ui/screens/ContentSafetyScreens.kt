package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.ParentRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafetyFeatureDetailScreen(
    featureKey: String,
    deviceId: String,
    repository: ParentRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val device by repository.observeDeviceById(deviceId).collectAsState(initial = null)
    val notifications by repository.observeNotifications(deviceId).collectAsState(initial = emptyList())
    val socialDetections by repository.observeSocialDetections(deviceId).collectAsState(initial = emptyList())
    val snapshots by repository.observeSnapshots(deviceId).collectAsState(initial = emptyList())
    val callSmsLogs by repository.observeCallSms(deviceId).collectAsState(initial = emptyList())
    val webRules by repository.observeWebFilterRules(deviceId).collectAsState(initial = emptyList())
    val browsingLogs by repository.observeBrowsingLogs(deviceId).collectAsState(initial = emptyList())
    LaunchedEffect(deviceId) { repository.attachChildTelemetryListeners(deviceId) }

    val (title, icon) = when (featureKey) {
        "NOTIFICATIONS" -> "Notification Monitoring" to Icons.Outlined.Notifications
        "SOCIAL" -> "Social Content Detection" to Icons.Outlined.Visibility
        "IMAGES" -> "Inappropriate Image Detection" to Icons.Outlined.Image
        "SNAPSHOTS" -> "Screen & Camera Snapshots" to Icons.Outlined.CameraAlt
        "CALLS" -> "Call Log" to Icons.Outlined.Phone
        "WEB_RESTRICTIONS" -> "Website Restrictions" to Icons.Outlined.Block
        "WEB_LIMITS" -> "Web Time Limits" to Icons.Outlined.HourglassEmpty
        else -> "Browsing History" to Icons.Outlined.History
    }

    var newUrlInput by remember { mutableStateOf("") }
    var webLimitSlider by remember(device?.webDailyLimitMinutes) {
        mutableFloatStateOf((device?.webDailyLimitMinutes ?: 60).toFloat())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(device?.deviceName ?: "Child Device", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF1F5F9))
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color(0xFFF1EDFA),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(icon, contentDescription = null, tint = Color(0xFF7968C4), modifier = Modifier.size(20.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Feature Link Status", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (device?.isOnline == true) Color(0xFFD1FAE5) else Color(0xFFFEE2E2)
                            ) {
                                Text(
                                    if (device?.isOnline == true) "Active & Allowed" else "Offline",
                                    color = if (device?.isOnline == true) Color(0xFF047857) else Color(0xFFB91C1C),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Authorized telemetry synchronization with ${device?.deviceName ?: "child device"} via Cloud Firestore.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            when (featureKey) {
                "NOTIFICATIONS" -> {
                    item {
                        Text("Live child notifications (${notifications.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    if (notifications.isEmpty()) {
                        item {
                            EmptyStateCard(
                                if (device?.hasNotificationPermission == true) "Notification access is enabled. New notifications will appear here; trigger a notification on the child device to verify live sync."
                                else "Notification access is off on the child device. Enable AirGuard notification access in Android Settings to sync notifications."
                            )
                        }
                    } else {
                        items(notifications) { notif ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(notif.appName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF7968C4))
                                        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
                                        Text(sdf.format(Date(notif.timestamp)), fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("From: ${notif.sender}", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                    Text(notif.content, fontSize = 12.sp, color = Color(0xFF475569))
                                }
                            }
                        }
                    }
                }
                "SOCIAL" -> {
                    item {
                        Text("Social Content Scans & Keywords", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    if (socialDetections.isEmpty()) {
                        item {
                            EmptyStateCard("No high-risk social keywords detected across TikTok, Instagram, or WhatsApp.")
                        }
                    } else {
                        items(socialDetections) { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(item.platform, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (item.riskLevel == "High") Color(0xFFFEE2E2) else Color(0xFFFEF3C7)
                                        ) {
                                            Text(
                                                "${item.riskLevel} Risk",
                                                color = if (item.riskLevel == "High") Color(0xFFDC2626) else Color(0xFFD97706),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(item.snippet, fontSize = 13.sp, color = Color(0xFF334155))
                                }
                            }
                        }
                    }
                }
                "SNAPSHOTS" -> {
                    item {
                        Text("Screen & Camera Snapshots", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Standalone snapshots are disabled. Use a live camera session when the child device has granted camera access.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                    if (snapshots.isEmpty()) {
                        item {
                            EmptyStateCard("No live camera sessions have produced a snapshot.")
                        }
                    } else {
                        items(snapshots) { snap ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFEAE5F8),
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Screenshot, contentDescription = null, tint = Color(0xFF7968C4))
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text("${snap.type} Snapshot ${snap.status}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        val sdf = SimpleDateFormat("h:mm a, MMM d", Locale.getDefault())
                                        Text(sdf.format(Date(snap.timestamp)), fontSize = 12.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
                "CALLS" -> {
                    item {
                        Text("Live call log (${callSmsLogs.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    if (callSmsLogs.isEmpty()) {
                        item {
                            EmptyStateCard(
                                if (device?.hasCallLogPermission == true) "Call Log access is enabled. New calls sync while the child device is connected. SMS content is not collected by this build."
                                else "Call Log access is off on the child device. Grant AirGuard Kids the Android Call Log permission, then reopen AirGuard Kids to sync recent calls. SMS content is not collected by this build."
                            )
                        }
                    } else {
                        items(callSmsLogs) { log ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (log.type.contains("CALL")) Color(0xFFD1FAE5) else Color(0xFFEAE5F8),
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                if (log.type.contains("CALL")) Icons.Default.Call else Icons.Default.Message,
                                                contentDescription = null,
                                                tint = if (log.type.contains("CALL")) Color(0xFF047857) else Color(0xFF7968C4),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${log.contactName} (${log.phoneNumber})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("${log.type.replace('_', ' ')} · ${log.durationOrBody}", fontSize = 12.sp, color = Color(0xFF334155))
                                        Text(SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(log.timestamp)), fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
                "WEB_RESTRICTIONS" -> {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Saved Domain Rules", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Spacer(modifier = Modifier.height(5.dp))
                                Text(
                                    "Android does not let this build enforce domains inside Chrome or other third-party browsers. Use App Limits to restrict browser apps.",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = newUrlInput,
                                        onValueChange = { newUrlInput = it },
                                        placeholder = { Text("e.g. gambling.com or adult-site.net") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = {
                                            if (newUrlInput.isNotBlank()) {
                                                coroutineScope.launch {
                                                    repository.addWebFilterRule(deviceId, newUrlInput)
                                                    newUrlInput = ""
                                        Toast.makeText(context, "Domain saved for reference; browser blocking is not active", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7968C4))
                                    ) {
                                        Text("Block")
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Text("Active Website Block Rules (${webRules.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    if (webRules.isEmpty()) {
                        item {
                        EmptyStateCard("No custom domains are saved. Android does not let AirGuard reliably block sites or read history inside third-party browsers; app limits can restrict browser time.")
                        }
                    } else {
                        items(webRules) { rule ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(rule.urlPattern, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(rule.category, fontSize = 11.sp, color = Color.Gray)
                                    }
                                    IconButton(onClick = {
                                        coroutineScope.launch {
                                            repository.deleteWebFilterRule(rule.id)
                                            Toast.makeText(context, "Removed saved rule for ${rule.urlPattern}", Toast.LENGTH_SHORT).show()
                                        }
                                    }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
                "WEB_LIMITS" -> {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text("Daily Browser App Allowance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Tracks recognized browser apps using Android Usage Access and blocks them after the limit. It does not inspect pages or website history.", fontSize = 13.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(20.dp))
                                Text(
                                    "${webLimitSlider.toInt()} Minutes / Day",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF7968C4)
                                )
                                Slider(
                                    value = webLimitSlider,
                                    onValueChange = { webLimitSlider = it },
                                    valueRange = 15f..240f,
                                    steps = 14
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            try {
                                                repository.updateWebDailyLimit(deviceId, webLimitSlider.toInt())
                                                Toast.makeText(context, "Browser time limit saved and sent to child", Toast.LENGTH_SHORT).show()
                                            } catch (e: Exception) {
                                                Toast.makeText(context, e.message ?: "Could not save browser limit", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7968C4))
                                ) {
                                    Text("Save Web Limit")
                                }
                            }
                        }
                    }
                }
                else -> {
                    item {
                        Text("Visited Websites & Search Logs (${browsingLogs.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    if (browsingLogs.isEmpty()) {
                        item {
                            EmptyStateCard("Android does not expose browsing history from Chrome or other third-party browsers. This screen will show history only from a supervised browser integration.")
                        }
                    } else {
                        items(browsingLogs) { log ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(log.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(log.url, fontSize = 12.sp, color = Color(0xFF7968C4))
                                    }
                                    Text("${log.visitCount} visits", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun EmptyStateCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Box(
            modifier = Modifier.padding(24.dp).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(message, color = Color.Gray, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    }
}
