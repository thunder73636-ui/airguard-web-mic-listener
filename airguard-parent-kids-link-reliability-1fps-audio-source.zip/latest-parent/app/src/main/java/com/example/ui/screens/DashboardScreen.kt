package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Device
import com.example.data.model.ParentAccount
import com.example.data.repository.ParentRepository
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun DashboardScreen(
    repository: ParentRepository,
    devices: List<Device>,
    selectedDeviceIndex: Int,
    account: ParentAccount?,
    onSelectDeviceIndex: (Int) -> Unit,
    onNavigateToBinding: () -> Unit,
    onNavigateToUsage: (String) -> Unit,
    onNavigateToRemote: (String, String) -> Unit,
    onNavigateToSafetyFeature: (String, String) -> Unit, // featureKey, deviceId
    onToggleLock: (String, Boolean) -> Unit,
    onRefreshTelemetry: (String) -> Unit,
    onUpdateBlockNewInstalls: (String, Boolean) -> Unit = { _, _ -> },
    onUpdateAlwaysAllowedApps: (String, String) -> Unit = { _, _ -> },
    onUpdatePreventUninstall: (String, Boolean) -> Unit = { _, _ -> },
    onUpdateScreenTimeLimit: (String, Int) -> Unit = { _, _ -> },
    onRingDevice: (String, Boolean) -> Unit = { _, _ -> },
    onReconnectChild: (String) -> Unit = {},
    onTurnFlashlightOn: (String) -> Unit = {},
    onDeleteDevice: suspend (String) -> ParentRepository.DeleteDeviceResult = { ParentRepository.DeleteDeviceResult.REMOVED_FROM_CLOUD },
    onResolveExtraTimeRequest: (String, Boolean) -> Unit = { _, _ -> },
    onNavigateToFiles: (String) -> Unit = {},
    onRequestScreenLock: (String) -> Unit = {},
    onNavigateToWebMicListener: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showDeviceDropdown by remember { mutableStateOf(false) }
    var showNotificationDialog by remember { mutableStateOf(false) }
    var showEventReportDialog by remember { mutableStateOf(false) }
    var showPermissionAlertsDialog by remember { mutableStateOf(false) }
    var showNoDeviceDialog by remember { mutableStateOf(false) }
    var showDailyLimitDialog by remember { mutableStateOf(false) }
    var showAlwaysAllowedDialog by remember { mutableStateOf(false) }
    var showRingDeviceDialog by remember { mutableStateOf(false) }
    var isRinging by remember { mutableStateOf(false) }
    var showDeleteDeviceDialog by remember { mutableStateOf(false) }
    var isDeletingDevice by remember { mutableStateOf(false) }
    var showOfflinePinDialog by remember { mutableStateOf(false) }
    var offlinePin by remember { mutableStateOf("") }
    var offlinePinConfirm by remember { mutableStateOf("") }
    var isSavingOfflinePin by remember { mutableStateOf(false) }

    val activeDevice = devices.getOrNull(selectedDeviceIndex) ?: devices.firstOrNull()

    if (showDeleteDeviceDialog && activeDevice != null) {
        AlertDialog(
            onDismissRequest = { if (!isDeletingDevice) showDeleteDeviceDialog = false },
            icon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = AirOfflineRed) },
            title = { Text("Remove linked device?", fontWeight = FontWeight.Bold) },
            text = { Text("Remove ${activeDevice.deviceName} and its synced records from this Parent account? The child app will need to be paired again to reconnect.") },
            confirmButton = {
                Button(
                    enabled = !isDeletingDevice,
                    onClick = {
                        isDeletingDevice = true
                        coroutineScope.launch {
                            try {
                                onDeleteDevice(activeDevice.id)
                                showDeleteDeviceDialog = false
                            } catch (e: Exception) {
                                Toast.makeText(context, e.message ?: "Could not remove device. Check connection and try again.", Toast.LENGTH_LONG).show()
                            } finally {
                                isDeletingDevice = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AirOfflineRed)
                ) { Text(if (isDeletingDevice) "Removing…" else "Remove device") }
            },
            dismissButton = {
                TextButton(enabled = !isDeletingDevice, onClick = { showDeleteDeviceDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showOfflinePinDialog && activeDevice != null) {
        AlertDialog(
            onDismissRequest = { if (!isSavingOfflinePin) showOfflinePinDialog = false },
            title = { Text("Parent PIN", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Set a 6-digit PIN the child can use to dismiss AirGuard restrictions. It does not unlock Android's phone lock screen.", fontSize = 13.sp)
                    OutlinedTextField(
                        value = offlinePin,
                        onValueChange = { value -> offlinePin = value.filter(Char::isDigit).take(6) },
                        label = { Text("New 6-digit PIN") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                    OutlinedTextField(
                        value = offlinePinConfirm,
                        onValueChange = { value -> offlinePinConfirm = value.filter(Char::isDigit).take(6) },
                        label = { Text("Confirm PIN") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isSavingOfflinePin && offlinePin.length == 6 && offlinePin == offlinePinConfirm,
                    onClick = {
                        isSavingOfflinePin = true
                        coroutineScope.launch {
                            try {
                                repository.setOfflineUnlockPin(activeDevice.id, offlinePin)
                                Toast.makeText(context, "Parent PIN synced to child", Toast.LENGTH_LONG).show()
                                showOfflinePinDialog = false
                                offlinePin = ""
                                offlinePinConfirm = ""
                            } catch (e: Exception) {
                                Toast.makeText(context, e.message ?: "Could not save PIN", Toast.LENGTH_LONG).show()
                            } finally { isSavingOfflinePin = false }
                        }
                    }
                ) { Text(if (isSavingOfflinePin) "Saving…" else "Save PIN") }
            },
            dismissButton = {
                TextButton(onClick = { if (!isSavingOfflinePin) showOfflinePinDialog = false }) { Text("Cancel") }
            }
        )
    }

    fun handleDeviceFeatureClick(action: (String) -> Unit) {
        if (activeDevice != null) {
            action(activeDevice.id)
        } else {
            showNoDeviceDialog = true
        }
    }

    if (showNoDeviceDialog) {
        AlertDialog(
            onDismissRequest = { showNoDeviceDialog = false },
            icon = { Icon(Icons.Default.PhonelinkOff, contentDescription = null, tint = Color(0xFF7968C4), modifier = Modifier.size(36.dp)) },
            title = { Text("No Child Device Linked", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "You need to pair a child device running AirGuard Kids to access remote camera, app limits, downtime, and content safety.",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showNoDeviceDialog = false
                        onNavigateToBinding()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7968C4))
                ) {
                    Text("Pair Device Now")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNoDeviceDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showNotificationDialog) {
        NotificationDialog(
            deviceName = activeDevice?.deviceName ?: "Child Device",
            deviceId = activeDevice?.id,
            hasNotificationAccess = activeDevice?.hasNotificationPermission == true,
            repository = repository,
            onDismiss = { showNotificationDialog = false }
        )
    }

    if (showEventReportDialog && activeDevice != null) {
        AlertDialog(
            onDismissRequest = { showEventReportDialog = false },
            title = { Text("Today's Event Report", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Device: ${activeDevice.deviceName}", fontWeight = FontWeight.Medium)
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Screen Usage:", color = Color.Gray)
                        Text("${activeDevice.todayUsageMinutes} mins / ${activeDevice.screenTimeLimitMinutes} mins", fontWeight = FontWeight.Bold, color = AirBluePrimary)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Screen Unlocks:", color = Color.Gray)
                        Text("${activeDevice.unlockCountToday} times", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Notifications Captured:", color = Color.Gray)
                        Text("${activeDevice.notificationsCountToday} alerts", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Instant Block State:", color = Color.Gray)
                        Text(if (activeDevice.isLocked) "AirGuard Paused" else "Access Allowed", fontWeight = FontWeight.Bold, color = if (activeDevice.isLocked) AirOfflineRed else AirOnlineGreen)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showEventReportDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = AirBluePrimary)
                ) {
                    Text("Close")
                }
            }
        )
    }

    if (showPermissionAlertsDialog && activeDevice != null) {
        AlertDialog(
            onDismissRequest = { showPermissionAlertsDialog = false },
            title = { Text("Child Permissions & Protection", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "These statuses are reported by '${activeDevice.deviceName}'. Enable each permission on the child device when Android asks. Standard AirGuard setup does not require a factory reset.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    PermissionItem("Accessibility Service (Screen & Control)", activeDevice.hasAccessibilityPermission)
                    PermissionItem("Usage Access (App Usage Tracking)", activeDevice.hasUsageStatsPermission)
                    PermissionItem("Location Access (GPS Tracking)", activeDevice.hasLocationPermission)
                    PermissionItem("Camera & Microphone Access", activeDevice.hasCameraPermission && activeDevice.hasMicrophonePermission)
                    PermissionItem("Phone State", activeDevice.hasPhoneStatePermission)
                    PermissionItem("Call Log", activeDevice.hasCallLogPermission)
                    PermissionItem("Notifications", activeDevice.hasPostNotificationsPermission)
                    PermissionItem("Child media access", activeDevice.hasManageAllFilesPermission)
                    PermissionItem("Battery Optimization Exemption", activeDevice.isIgnoringBatteryOptimizations)
                    PermissionItem("Device Admin screen lock", activeDevice.hasAdminPermission)
                    Text(
                        "Device Admin enables a one-time screen lock. Persistent app blocking still requires Accessibility.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showPermissionAlertsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showDailyLimitDialog && activeDevice != null) {
        var tempLimit by remember(activeDevice.screenTimeLimitMinutes) {
            mutableFloatStateOf(activeDevice.screenTimeLimitMinutes.toFloat())
        }
        var tempLimitInput by remember(activeDevice.screenTimeLimitMinutes) {
            mutableStateOf(activeDevice.screenTimeLimitMinutes.toString())
        }
        AlertDialog(
            onDismissRequest = { showDailyLimitDialog = false },
            title = { Text("Daily Screen Time Quota", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Set total allowed daily device screen time:", fontSize = 13.sp, color = Color.Gray)
                    val hours = tempLimit.toInt() / 60
                    val minutes = tempLimit.toInt() % 60
                    Text(
                        "${hours}h ${minutes}m per day",
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = Color(0xFF7968C4)
                    )
                    OutlinedTextField(
                        value = tempLimitInput,
                        onValueChange = { value ->
                            if (value.isEmpty() || value.all(Char::isDigit)) {
                                tempLimitInput = value
                                value.toIntOrNull()?.let { tempLimit = it.coerceIn(1, 1_440).toFloat() }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Daily limit in minutes") },
                        supportingText = { Text("1–1,440 minutes (up to 24 hours)") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    Slider(
                        value = tempLimit,
                        onValueChange = { tempLimit = it; tempLimitInput = it.toInt().toString() },
                        valueRange = 1f..1_440f,
                        steps = 1_438
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val chosenLimit = tempLimitInput.toIntOrNull()?.coerceIn(1, 1_440)
                    if (chosenLimit == null) {
                        Toast.makeText(context, "Enter a limit from 1 to 1,440 minutes", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    onUpdateScreenTimeLimit(activeDevice.id, chosenLimit)
                    showDailyLimitDialog = false
                    Toast.makeText(context, "Daily limit updated", Toast.LENGTH_SHORT).show()
                }) {
                    Text("Save Limit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDailyLimitDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showAlwaysAllowedDialog && activeDevice != null) {
        var allowedText by remember(activeDevice.alwaysAllowedApps) {
            mutableStateOf(activeDevice.alwaysAllowedApps)
        }
        AlertDialog(
            onDismissRequest = { showAlwaysAllowedDialog = false },
            title = { Text("Always Allowed Apps", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("These apps remain accessible even during downtime or instant block:", fontSize = 13.sp, color = Color.Gray)
                    OutlinedTextField(
                        value = allowedText,
                        onValueChange = { allowedText = it },
                        label = { Text("Allowed Apps (comma-separated)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Phone", "Maps", "Calculator", "School").forEach { chip ->
                            FilterChip(
                                selected = allowedText.contains(chip),
                                onClick = {
                                    allowedText = if (allowedText.contains(chip)) {
                                        allowedText.split(",").map { it.trim() }.filter { it != chip }.joinToString(",")
                                    } else {
                                        if (allowedText.isBlank()) chip else "$allowedText,$chip"
                                    }
                                },
                                label = { Text(chip, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onUpdateAlwaysAllowedApps(activeDevice.id, allowedText)
                    showAlwaysAllowedDialog = false
                    Toast.makeText(context, "Always-allowed apps saved", Toast.LENGTH_SHORT).show()
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAlwaysAllowedDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showRingDeviceDialog && activeDevice != null) {
        AlertDialog(
            onDismissRequest = {
                if (isRinging) onRingDevice(activeDevice.id, false)
                isRinging = false
                showRingDeviceDialog = false
            },
            title = { Text("Find & Ring Child Phone", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Play the device's default ringtone for up to one minute. Sound settings or Do Not Disturb may silence it.", fontSize = 13.sp, color = Color.Gray)
                    if (isRinging) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Color(0xFF7968C4))
                        Text("Alarm sounding on ${activeDevice.deviceName}...", color = Color(0xFF7968C4), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isRinging = !isRinging
                        if (isRinging) {
                            onRingDevice(activeDevice.id, true)
                            Toast.makeText(context, "Ring request sent to ${activeDevice.deviceName}", Toast.LENGTH_SHORT).show()
                        } else {
                            onRingDevice(activeDevice.id, false)
                            showRingDeviceDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isRinging) Color(0xFFEF4444) else Color(0xFF7968C4))
                ) {
                    Text(if (isRinging) "Stop Ringing" else "Ring Child Phone")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    if (isRinging) onRingDevice(activeDevice.id, false)
                    isRinging = false
                    showRingDeviceDialog = false
                }) {
                    Text("Close")
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1F5F9)),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Top Royal Blue Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF1D4ED8), Color(0xFF7968C4), Color(0xFF8D7BD0))
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 22.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left: Avatar + Device Name
                        Box {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable {
                                    if (devices.isNotEmpty()) {
                                        showDeviceDropdown = true
                                    } else {
                                        onNavigateToBinding()
                                    }
                                }
                            ) {
                                if (activeDevice != null) {
                                    ChildMascotAvatar(size = 46.dp)
                                } else {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color.White.copy(alpha = 0.25f),
                                        modifier = Modifier.size(46.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Outlined.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = if (activeDevice != null) activeDevice.deviceName else "No Device Connected",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 17.sp
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            Icons.Default.ArrowDropDown,
                                            contentDescription = "Select Device",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    // Real connection status
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = when {
                                            activeDevice == null -> Color.White.copy(alpha = 0.2f)
                                            activeDevice.isOnline -> Color(0xFF047857)
                                            else -> Color(0xFFB45309)
                                        },
                                        modifier = Modifier.padding(top = 1.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        ) {
                                            if (activeDevice == null) {
                                                Text(
                                                    "No device linked   Tap '+' to pair",
                                                    color = Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            } else if (activeDevice.isOnline) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .background(Color(0xFF6EE7B7), CircleShape)
                                                )
                                                Spacer(modifier = Modifier.width(5.dp))
                                                Text(
                                                    if (activeDevice.batteryLevel > 0) "Linked · Online   ${activeDevice.batteryLevel}%" else "Linked · Online",
                                                    color = Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            } else {
                                                Icon(
                                                    Icons.Default.Warning,
                                                    contentDescription = null,
                                                    tint = Color(0xFFFDE68A),
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    "Linked · ${deviceLastSeenLabel(activeDevice.lastSeenTimestamp)}",
                                                    color = Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            DropdownMenu(
                                expanded = showDeviceDropdown,
                                onDismissRequest = { showDeviceDropdown = false }
                            ) {
                                devices.forEachIndexed { index, dev ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    Icons.Default.PhoneAndroid,
                                                    contentDescription = null,
                                                    tint = if (index == selectedDeviceIndex) Color(0xFF7968C4) else Color.Gray,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text(
                                                        dev.deviceName,
                                                        fontWeight = if (index == selectedDeviceIndex) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                    Text(dev.model, fontSize = 11.sp, color = Color.Gray)
                                                }
                                            }
                                        },
                                        onClick = {
                                            onSelectDeviceIndex(index)
                                            showDeviceDropdown = false
                                        }
                                    )
                                }
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF7968C4))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Pair New Device", color = Color(0xFF7968C4), fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    onClick = {
                                        showDeviceDropdown = false
                                        onNavigateToBinding()
                                    }
                                )
                            }
                        }

                        // Right: Notification Bell & Plus Icon
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showNotificationDialog = true }) {
                                Icon(
                                    Icons.Outlined.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            IconButton(onClick = onNavigateToBinding) {
                                Icon(
                                    Icons.Outlined.AddCircleOutline,
                                    contentDescription = "Add Device",
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Empty state only when NO device is paired
        if (devices.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFF1EDFA),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.PhoneAndroid,
                                    contentDescription = null,
                                    tint = Color(0xFF7968C4),
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            "No Child Device Linked",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Pair your child's phone with the 9-digit binding code or QR code to view live screen time, set app limits, track real-time GPS, and access remote camera.",
                            fontSize = 13.sp,
                            color = Color(0xFF716B7D),
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onNavigateToBinding,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7968C4)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Pair Child Device (+)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else if (activeDevice != null) {
            // Child Device Specs Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    activeDevice.deviceName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = Color(0xFF1E293B)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    "${activeDevice.model}   ${activeDevice.androidVersion}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF716B7D)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (activeDevice.isOnline) Color(0xFFEAF7EE) else Color(0xFFFFF3DD),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (activeDevice.isOnline) Color(0xFFB9DDC4) else Color(0xFFF0D7A9)
                                )
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .background(if (activeDevice.isOnline) Color(0xFF58A878) else Color(0xFFD99B3D), CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        if (activeDevice.isOnline) {
                                            if (activeDevice.batteryLevel > 0) "Linked · ${activeDevice.batteryLevel}%" else "Linked · Online"
                                        } else "Linked · ${deviceLastSeenLabel(activeDevice.lastSeenTimestamp)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (activeDevice.isOnline) Color(0xFF548B68) else Color(0xFFAA7B38)
                                    )
                                }
                            }
                            TextButton(onClick = { showDeleteDeviceDialog = true }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = AirOfflineRed)
                                Text("Remove", color = AirOfflineRed)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Color(0xFFF1F5F9))
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Protection Status: Active & Syncing",
                                fontSize = 12.sp,
                                color = Color(0xFF7968C4),
                                fontWeight = FontWeight.SemiBold
                            )
                            TextButton(onClick = { showPermissionAlertsDialog = true }) {
                                Text("Permissions >", fontSize = 12.sp, color = Color(0xFF7968C4))
                            }
                        }
                    }
                }
            }
        }

        // 2. Today's Event Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { handleDeviceFeatureClick { showEventReportDialog = true } },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Today's Event",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            if (activeDevice != null) "Detailed event report" else "Connect a child device to view events",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                    }
                    IllustrationReport(size = 72.dp)
                }
            }
        }

        // 3. Quick Tools Grid (Remote Camera, Screen Mirroring status, One-Way Audio)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 18.dp, horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                    // Tool 1: Remote Camera
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                handleDeviceFeatureClick { devId -> onNavigateToRemote(devId, "CAMERA") }
                            }
                    ) {
                        RemoteCamera3DIcon(size = 56.dp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Remote\nCamera",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF1E293B),
                            lineHeight = 17.sp
                        )
                    }

                    // Tool 2: Screen Mirroring
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { handleDeviceFeatureClick { devId -> onNavigateToRemote(devId, "SCREEN_MIRROR") } }
                    ) {
                        ScreenMirroring3DIcon(size = 56.dp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Screen\nMirror",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF1E293B),
                            lineHeight = 17.sp
                        )
                    }

                    // Tool 3: One-Way Audio
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                handleDeviceFeatureClick { devId -> onNavigateToRemote(devId, "ONE_WAY_AUDIO") }
                            }
                    ) {
                        OneWayAudio3DIcon(size = 56.dp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Microphone",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF1E293B),
                            lineHeight = 17.sp
                        )
                    }

                    // Tool 4: Live Accessibility Screenshots
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                handleDeviceFeatureClick { devId -> onNavigateToRemote(devId, "ACCESSIBILITY_SCREENSHOT") }
                            }
                    ) {
                        Icon(
                            Icons.Default.Screenshot,
                            contentDescription = "Live screenshots",
                            tint = Color(0xFF7968C4),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Accessibility\nView",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF1E293B),
                            lineHeight = 17.sp
                        )
                    }
                    }

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                    // Reconnect nudge: ask the child service to apply flash OFF and refresh presence.
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                handleDeviceFeatureClick { devId -> onReconnectChild(devId) }
                            }
                    ) {
                        Icon(
                            Icons.Default.FlashOff,
                            contentDescription = "Reconnect child device",
                            tint = Color(0xFF7968C4),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Reconnect\n(Flash OFF)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF1E293B),
                            lineHeight = 17.sp
                        )
                    }

                    // Torch ON is a separate action from the harmless reconnect/flash-OFF nudge.
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                if (activeDevice == null) {
                                    showNoDeviceDialog = true
                                } else if (!activeDevice.hasCameraPermission) {
                                    Toast.makeText(context, "Camera permission is required on the child phone for its flashlight", Toast.LENGTH_LONG).show()
                                } else {
                                    onTurnFlashlightOn(activeDevice.id)
                                }
                            }
                    ) {
                        Icon(
                            Icons.Default.FlashOn,
                            contentDescription = "Turn child flashlight on",
                            tint = Color(0xFF7968C4),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Flashlight\nON",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF1E293B),
                            lineHeight = 17.sp
                        )
                    }

                    // Tool 5: child-permission-gated media gallery
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                handleDeviceFeatureClick { devId -> onNavigateToFiles(devId) }
                            }
                    ) {
                        Icon(
                            Icons.Default.FolderOpen,
                            contentDescription = "View child file listing",
                            tint = Color(0xFF7968C4),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Images &\nVideos",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF1E293B),
                            lineHeight = 17.sp
                        )
                    }
                    }

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f).clickable { onNavigateToWebMicListener() }) {
                            Icon(Icons.Default.Headphones, contentDescription = "Website microphone listener", tint = Color(0xFF7968C4), modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Website Mic\nListener", fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, color = Color(0xFF1E293B), lineHeight = 17.sp)
                        }
                        Spacer(Modifier.weight(3f))
                    }
                }
            }
        }

        // 4. Device Alerts Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { handleDeviceFeatureClick { showPermissionAlertsDialog = true } },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Device Alerts",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .background(Color(0xFF10B981), CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(Color(0xFF8D7BD0), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            if (activeDevice != null) "Real-time sync active for ${activeDevice.deviceName}" else "No active alerts. Connect a child device.",
                            fontSize = 14.sp,
                            color = Color(0xFF334155),
                            fontWeight = FontWeight.Normal
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(Color(0xFF10B981), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                "Supervision permissions active",
                                fontSize = 14.sp,
                                color = Color(0xFF334155),
                                fontWeight = FontWeight.Normal
                            )
                        }
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF10B981),
                            modifier = Modifier.size(20.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                            }
                        }
                    }
                }
            }
        }

        // 5. Screen Time & Apps Section
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                if (activeDevice != null && activeDevice.extraTimeRequestAt > activeDevice.extraTimeRequestHandledAt) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7E6)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Extra time requested", fontWeight = FontWeight.Bold, color = Color(0xFF7A4D00))
                            Text("${activeDevice.deviceName} is asking for 15 more minutes.", fontSize = 13.sp, color = Color(0xFF6B5B3E))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                                Button(onClick = { onResolveExtraTimeRequest(activeDevice.id, true) }) { Text("Allow 15 min") }
                                TextButton(onClick = { onResolveExtraTimeRequest(activeDevice.id, false) }) { Text("Decline") }
                            }
                        }
                    }
                }
                SectionHeader("Screen Time & Apps", onPlanClick = {
                    handleDeviceFeatureClick { onNavigateToUsage(it) }
                })
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column {
                        // Instant Block
                        FeatureRowWithPro(
                            icon = { InstantBlockIcon(size = 24.dp) },
                            title = "Instant Block",
                            onClick = {
                                handleDeviceFeatureClick { devId ->
                                    activeDevice?.let { onToggleLock(devId, !it.isLocked) }
                                }
                            },
                            rightContent = {
                                if (activeDevice != null) {
                                    Switch(
                                        checked = activeDevice.isLocked,
                                        onCheckedChange = { onToggleLock(activeDevice.id, it) },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color.White,
                                            checkedTrackColor = Color(0xFF7968C4)
                                        )
                                    )
                                } else {
                                    Text(">", color = Color(0xFF94A3B8), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        )
                        TextButton(
                            onClick = {
                                handleDeviceFeatureClick { deviceId ->
                                    if (activeDevice?.hasAdminPermission == true) {
                                        onRequestScreenLock(deviceId)
                                    } else {
                                        Toast.makeText(
                                            context,
                                            "Enable Device Admin on the child phone in Kids app permissions first.",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Lock screen now (no Accessibility)")
                        }
                        Text(
                            text = "Requires Device Admin on the child phone. The child can unlock with its PIN.",
                            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                        TextButton(
                            onClick = {
                                handleDeviceFeatureClick {
                                    offlinePin = ""
                                    offlinePinConfirm = ""
                                    showOfflinePinDialog = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Password, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Set Parent PIN")
                        }
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        // Downtime
                        FeatureRowWithArrow(
                            icon = { DowntimeHourglassIcon(size = 24.dp) },
                            title = "Downtime Schedules",
                            onClick = { handleDeviceFeatureClick { onNavigateToUsage(it) } }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        // App Management
                        FeatureRowWithArrow(
                            icon = { AppManagementGridIcon(size = 24.dp) },
                            title = "App Limits & Management",
                            onClick = { handleDeviceFeatureClick { onNavigateToUsage(it) } }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        // Daily Screen Time Quota
                        FeatureRowWithPro(
                            icon = { Icon(Icons.Outlined.Timer, contentDescription = null, tint = Color(0xFF7968C4), modifier = Modifier.size(24.dp)) },
                            title = "Daily Screen Time Quota",
                            onClick = { handleDeviceFeatureClick { showDailyLimitDialog = true } },
                            rightContent = {
                                Text(
                                    if (activeDevice != null) "${activeDevice.screenTimeLimitMinutes / 60}h ${activeDevice.screenTimeLimitMinutes % 60}m >" else ">",
                                    color = Color(0xFF7968C4),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        // Always Allowed Apps
                        FeatureRowWithPro(
                            icon = { Icon(Icons.Outlined.CheckCircleOutline, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(24.dp)) },
                            title = "Always Allowed Apps",
                            onClick = { handleDeviceFeatureClick { showAlwaysAllowedDialog = true } },
                            rightContent = {
                                Text(
                                    if (activeDevice != null) "${activeDevice.alwaysAllowedApps.split(',').size} apps >" else ">",
                                    color = Color(0xFF716B7D),
                                    fontSize = 13.sp
                                )
                            }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        Text(
                            "Blocking new installs or uninstall needs Android Enterprise device-owner provisioning; these controls are not active in this consumer build.",
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                            color = Color(0xFF716B7D),
                            fontSize = 12.sp
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        // Find & Ring Phone
                        FeatureRowWithArrow(
                            icon = { Icon(Icons.Outlined.NotificationsActive, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(24.dp)) },
                            title = "Find & Ring Phone (Loud Alarm)",
                            onClick = { handleDeviceFeatureClick { showRingDeviceDialog = true } }
                        )
                    }
                }
            }
        }

        // 6. Content Safety Section
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                SectionHeader("Content Safety")
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column {
                        FeatureRowWithPro(
                            icon = { Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = null, tint = Color(0xFF1E293B), modifier = Modifier.size(24.dp)) },
                            title = "Notification Monitoring",
                            onClick = { handleDeviceFeatureClick { onNavigateToSafetyFeature("NOTIFICATIONS", it) } }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        FeatureRowWithArrow(
                            icon = { Icon(Icons.Outlined.Visibility, contentDescription = null, tint = Color(0xFF1E293B), modifier = Modifier.size(24.dp)) },
                            title = "Social Content Detection",
                            onClick = { handleDeviceFeatureClick { onNavigateToSafetyFeature("SOCIAL", it) } }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        FeatureRowWithArrow(
                            icon = { Icon(Icons.Outlined.Image, contentDescription = null, tint = Color(0xFF1E293B), modifier = Modifier.size(24.dp)) },
                            title = "Inappropriate Image Detection",
                            onClick = { handleDeviceFeatureClick { onNavigateToSafetyFeature("IMAGES", it) } }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        FeatureRowWithArrow(
                            icon = { Icon(Icons.Outlined.CameraAlt, contentDescription = null, tint = Color(0xFF1E293B), modifier = Modifier.size(24.dp)) },
                            title = "Screen & Camera Snapshots",
                            onClick = { handleDeviceFeatureClick { onNavigateToSafetyFeature("SNAPSHOTS", it) } }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        FeatureRowWithArrow(
                            icon = { Icon(Icons.Outlined.PhoneInTalk, contentDescription = null, tint = Color(0xFF1E293B), modifier = Modifier.size(24.dp)) },
                            title = "Call Log Monitoring",
                            onClick = { handleDeviceFeatureClick { onNavigateToSafetyFeature("CALLS", it) } }
                        )
                    }
                }
            }
        }

        // 7. Safe Browsing Section
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                SectionHeader("Safe Browsing")
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column {
                        FeatureRowWithArrow(
                            icon = { Icon(Icons.Outlined.Security, contentDescription = null, tint = Color(0xFF1E293B), modifier = Modifier.size(24.dp)) },
                            title = "Website Restrictions",
                            onClick = { handleDeviceFeatureClick { onNavigateToSafetyFeature("WEB_RESTRICTIONS", it) } }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        FeatureRowWithArrow(
                            icon = { Icon(Icons.Outlined.HourglassBottom, contentDescription = null, tint = Color(0xFF1E293B), modifier = Modifier.size(24.dp)) },
                            title = "Web Time Limits",
                            onClick = { handleDeviceFeatureClick { onNavigateToSafetyFeature("WEB_LIMITS", it) } }
                        )
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        FeatureRowWithArrow(
                            icon = { Icon(Icons.Outlined.History, contentDescription = null, tint = Color(0xFF1E293B), modifier = Modifier.size(24.dp)) },
                            title = "Browsing History",
                            onClick = { handleDeviceFeatureClick { onNavigateToSafetyFeature("BROWSING_HISTORY", it) } }
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    onPlanClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = RoundedCornerShape(2.dp),
                color = Color(0xFF7968C4),
                modifier = Modifier
                    .width(4.dp)
                    .height(16.dp)
            ) {}
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                title,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF1E293B)
            )
        }
        if (onPlanClick != null) {
            TextButton(
                onClick = onPlanClick,
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Text(
                    "Plan >",
                    color = Color(0xFF716B7D),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun FeatureRowWithArrow(
    icon: @Composable () -> Unit,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            icon()
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                title,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp,
                color = Color(0xFF1E293B)
            )
        }
        Text(
            ">",
            color = Color(0xFF94A3B8),
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun FeatureRowWithPro(
    icon: @Composable () -> Unit,
    title: String,
    onClick: () -> Unit,
    rightContent: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            icon()
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                title,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp,
                color = Color(0xFF1E293B)
            )
        }
        if (rightContent != null) {
            rightContent()
        } else {
            Text(
                ">",
                color = Color(0xFF94A3B8),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun PermissionItem(name: String, granted: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, fontSize = 13.sp)
        Text(
            if (granted) "Granted" else "Missing",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (granted) AirOnlineGreen else AirOfflineRed
        )
    }
}
