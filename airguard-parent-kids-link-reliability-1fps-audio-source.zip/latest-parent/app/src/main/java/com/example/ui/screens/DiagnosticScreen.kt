package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DiagnosticStageStatus
import com.example.data.model.MediaDiagnostics
import com.example.media.MediaSignalingManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticScreen(
    deviceId: String,
    deviceName: String,
    signalingManager: MediaSignalingManager,
    onBack: () -> Unit,
    onRetry: () -> Unit
) {
    val diagnostics by signalingManager.diagnostics.collectAsState()
    val sessionState by signalingManager.sessionState.collectAsState()
    val sessionDetails by signalingManager.sessionDetails.collectAsState()

    val elapsedMinutes = diagnostics.elapsedSeconds / 60
    val elapsedSecs = diagnostics.elapsedSeconds % 60
    val elapsedTimeFormatted = "%02d:%02d".format(elapsedMinutes, elapsedSecs)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Stream Media Diagnostics", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(deviceName, fontSize = 12.sp, color = Color.Gray)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onRetry) {
                        Icon(Icons.Default.Refresh, contentDescription = "Retry Session")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF1F5F9)
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Overall Status Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Overall Status", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            StatusBadge(status = diagnostics.overallStatus)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (sessionDetails.isNotBlank()) sessionDetails else diagnostics.overallStatus.displayLabel,
                            fontSize = 13.sp,
                            color = Color(0xFF475569)
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color(0xFFF1F5F9))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Elapsed Session Time:", fontSize = 12.sp, color = Color.Gray)
                            Text(elapsedTimeFormatted, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E293B))
                        }
                    }
                }
            }

            // 2. PeerConnection & ICE State
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("WebRTC Transport & ICE States", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        DiagnosticRow(
                            label = "PeerConnection",
                            value = diagnostics.peerConnectionState,
                            isOk = diagnostics.peerConnectionState == "CONNECTED" || diagnostics.peerConnectionState == "CREATED"
                        )
                        DiagnosticRow(
                            label = "ICE Connection",
                            value = diagnostics.iceConnectionState,
                            isOk = diagnostics.iceConnectionState == "CONNECTED" || diagnostics.iceConnectionState == "COMPLETED"
                        )
                        DiagnosticRow(
                            label = "Signaling State",
                            value = diagnostics.signalingState,
                            isOk = diagnostics.signalingState == "STABLE"
                        )
                        DiagnosticRow(
                            label = "Signaling Channel",
                            value = "Firestore (devices & remote_requests)",
                            isOk = true
                        )
                    }
                }
            }

            // 3. Camera Pipeline Diagnostics (Request → Session → Remote track → Frames received → Renderer status)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Videocam, contentDescription = null, tint = Color(0xFF7968C4))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Camera Pipeline Trace", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        FlowStageItem(
                            stepName = "1. Request",
                            description = "Dispatched remote request to Firestore",
                            status = if (diagnostics.requestDispatched) "Dispatched" else "Not started",
                            isSuccess = diagnostics.requestDispatched
                        )

                        FlowStageItem(
                            stepName = "2. Session",
                            description = "WebRTC PeerConnection & SDP negotiation",
                            status = if (diagnostics.sessionCreated) "Session Established" else "Waiting",
                            isSuccess = diagnostics.sessionCreated
                        )

                        FlowStageItem(
                            stepName = "3. Remote Track",
                            description = "Incoming VideoTrack arrival via onAddTrack / onTrack",
                            status = if (diagnostics.remoteVideoTrackReceived) "Track Received" else "Awaiting Track",
                            isSuccess = diagnostics.remoteVideoTrackReceived
                        )

                        FlowStageItem(
                            stepName = "4. Frames Received",
                            description = "Video frames decoded from Child device",
                            status = "${diagnostics.videoFramesReceivedCount} frames received",
                            isSuccess = diagnostics.videoFramesReceivedCount > 0
                        )

                        FlowStageItem(
                            stepName = "5. Renderer Status",
                            description = "SurfaceViewRenderer hardware OpenGL binding",
                            status = diagnostics.rendererStatus,
                            isSuccess = diagnostics.rendererStatus.contains("attached", ignoreCase = true) ||
                                    diagnostics.rendererStatus.contains("ready", ignoreCase = true)
                        )
                    }
                }
            }

            // 4. Audio Pipeline Diagnostics (Request → Session → Remote track → Incoming audio → Playback status)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Mic, contentDescription = null, tint = Color(0xFF10B981))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Microphone Audio Pipeline Trace", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        FlowStageItem(
                            stepName = "1. Request",
                            description = "Dispatched audio request to Firestore",
                            status = if (diagnostics.requestDispatched) "Dispatched" else "Not started",
                            isSuccess = diagnostics.requestDispatched
                        )

                        FlowStageItem(
                            stepName = "2. Session",
                            description = "WebRTC audio transceiver (RECV_ONLY)",
                            status = if (diagnostics.sessionCreated) "Session Active" else "Waiting",
                            isSuccess = diagnostics.sessionCreated
                        )

                        FlowStageItem(
                            stepName = "3. Remote Track",
                            description = "Incoming AudioTrack enabled and unmuted",
                            status = if (diagnostics.remoteAudioTrackReceived) "Track Arrived (Enabled & Unmuted)" else "Awaiting AudioTrack",
                            isSuccess = diagnostics.remoteAudioTrackReceived
                        )

                        FlowStageItem(
                            stepName = "4. Incoming Audio",
                            description = "Inbound RTP audio stream data bytes",
                            status = "${diagnostics.audioBytesReceivedCount} bytes received",
                            isSuccess = diagnostics.audioBytesReceivedCount > 0
                        )

                        FlowStageItem(
                            stepName = "5. Playback & Routing",
                            description = "Android Audio Focus & Speakerphone Routing",
                            status = "${diagnostics.audioRoutingMode} | ${diagnostics.audioPlaybackStatus}",
                            isSuccess = diagnostics.audioFocusGranted || diagnostics.audioPlaybackStatus.contains("Active", ignoreCase = true)
                        )
                    }
                }
            }

            // 5. Exception Messages (sanitized, no tokens/SDP/credentials)
            if (diagnostics.lastExceptionMessage != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFEF4444))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Diagnostic Exception Notice", fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = diagnostics.lastExceptionMessage ?: "",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFB91C1C)
                            )
                        }
                    }
                }
            }

            // 6. Action Button
            item {
                Button(
                    onClick = onRetry,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7968C4))
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Restart Media Pipeline & Trace", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: DiagnosticStageStatus) {
    val (bgColor, textColor) = when (status) {
        DiagnosticStageStatus.NOT_STARTED -> Color(0xFFF1F5F9) to Color(0xFF716B7D)
        DiagnosticStageStatus.WAITING -> Color(0xFFFEF3C7) to Color(0xFFD97706)
        DiagnosticStageStatus.CONNECTED_NO_MEDIA -> Color(0xFFEAE5F8) to Color(0xFF7968C4)
        DiagnosticStageStatus.RECEIVING_MEDIA -> Color(0xFFDCFCE7) to Color(0xFF16A34A)
        DiagnosticStageStatus.PLAYBACK_OR_RENDER_FAILED -> Color(0xFFFEE2E2) to Color(0xFFDC2626)
        DiagnosticStageStatus.CONNECTION_FAILED -> Color(0xFFFEE2E2) to Color(0xFFDC2626)
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor
    ) {
        Text(
            text = status.displayLabel,
            color = textColor,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String, isOk: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 13.sp, color = Color(0xFF716B7D))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(if (isOk) Color(0xFF10B981) else Color(0xFFF59E0B), CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1E293B))
        }
    }
}

@Composable
private fun FlowStageItem(
    stepName: String,
    description: String,
    status: String,
    isSuccess: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            shape = CircleShape,
            color = if (isSuccess) Color(0xFFDCFCE7) else Color(0xFFF1F5F9),
            modifier = Modifier.size(24.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                if (isSuccess) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(14.dp))
                } else {
                    Box(modifier = Modifier.size(6.dp).background(Color(0xFF94A3B8), CircleShape))
                }
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(stepName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E293B))
            Text(description, fontSize = 11.sp, color = Color(0xFF716B7D))
            Text(status, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (isSuccess) Color(0xFF16A34A) else Color(0xFFE11D48))
        }
    }
}
