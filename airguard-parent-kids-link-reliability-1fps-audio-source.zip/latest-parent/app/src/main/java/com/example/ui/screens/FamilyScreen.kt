package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Device
import com.example.data.model.ParentAccount
import com.example.data.repository.ParentRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FamilyScreen(
    devices: List<Device>,
    account: ParentAccount?,
    repository: ParentRepository,
    onBack: () -> Unit,
    onAddDevice: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var suspiciousKeywordFilter by remember(account?.suspiciousKeywordFilter) {
        mutableStateOf(account?.suspiciousKeywordFilter ?: true)
    }
    var explicitContentFilter by remember(account?.explicitContentFilter) {
        mutableStateOf(account?.explicitContentFilter ?: true)
    }
    var customKeywords by remember {
        mutableStateOf(listOf("bullying", "drugs", "violence", "threat"))
    }
    var newKeywordInput by remember { mutableStateOf("") }
    var showAddKeywordDialog by remember { mutableStateOf(false) }
    var devicePendingDeletion by remember { mutableStateOf<Device?>(null) }
    var isDeletingDevice by remember { mutableStateOf(false) }

    devicePendingDeletion?.let { device ->
        AlertDialog(
            onDismissRequest = { if (!isDeletingDevice) devicePendingDeletion = null },
            icon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = AirOfflineRed) },
            title = { Text("Remove linked child?", fontWeight = FontWeight.Bold) },
            text = { Text("Remove ${device.deviceName} and its synced records from this Parent account? The child will need to be paired again.") },
            confirmButton = {
                Button(
                    enabled = !isDeletingDevice,
                    onClick = {
                        isDeletingDevice = true
                        coroutineScope.launch {
                            try {
                                val result = repository.deleteDevice(device.id)
                                val message = when (result) {
                                    ParentRepository.DeleteDeviceResult.REMOVED_FROM_CLOUD -> "${device.deviceName} unlinked and removed"
                                    ParentRepository.DeleteDeviceResult.REMOVED_LOCALLY_PENDING_SYNC -> "${device.deviceName} removed here. Cloud unlink will retry when available."
                                }
                                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                                devicePendingDeletion = null
                            } catch (e: Exception) {
                                Toast.makeText(context, e.message ?: "Could not remove device. Check connection and try again.", Toast.LENGTH_LONG).show()
                            } finally {
                                isDeletingDevice = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AirOfflineRed)
                ) { Text(if (isDeletingDevice) "Removing…" else "Remove child") }
            },
            dismissButton = {
                TextButton(enabled = !isDeletingDevice, onClick = { devicePendingDeletion = null }) { Text("Cancel") }
            }
        )
    }

    if (showAddKeywordDialog) {
        AlertDialog(
            onDismissRequest = { showAddKeywordDialog = false },
            title = { Text("Add Monitored Keyword", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newKeywordInput,
                    onValueChange = { newKeywordInput = it },
                    label = { Text("Keyword or Phrase") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newKeywordInput.isNotBlank()) {
                        customKeywords = customKeywords + newKeywordInput.trim().lowercase()
                        newKeywordInput = ""
                        showAddKeywordDialog = false
                        Toast.makeText(context, "Keyword added to alert list", Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddKeywordDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Family & Content Detection", fontWeight = FontWeight.Bold) }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddDevice,
                containerColor = AirBluePrimary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Child Device")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(AirBackground)
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = AirBluePrimary.copy(alpha = 0.15f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.FamilyRestroom, contentDescription = null, tint = AirBluePrimary)
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Family Group", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Organizer: ${account?.name ?: "Parent Account"} (${account?.email})", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }

            item {
                Text("Linked Child Devices (${devices.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            if (devices.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("No child devices linked yet.", color = Color.Gray, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = onAddDevice) {
                                Text("Pair Device")
                            }
                        }
                    }
                }
            } else {
                items(devices, key = { it.id }) { dev ->
                    Card(
                        modifier = Modifier.fillMaxWidth().animateContentSize().animateItemPlacement(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (dev.isOnline) AirOnlineGreen.copy(alpha = 0.15f) else AirOfflineRed.copy(alpha = 0.15f),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Default.PhoneAndroid,
                                            contentDescription = null,
                                            tint = if (dev.isOnline) AirOnlineGreen else AirOfflineRed
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(dev.deviceName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text(
                                        if (dev.batteryLevel > 0) "${dev.model}   Battery ${dev.batteryLevel}%" else dev.model,
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                    Text(
                                        if (dev.isOnline) "Linked · online now" else "Linked · ${deviceLastSeenLabel(dev.lastSeenTimestamp)}",
                                        fontSize = 11.sp,
                                        color = if (dev.isOnline) AirOnlineGreen else AirOfflineRed,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = { devicePendingDeletion = dev }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = AirOfflineRed)
                                    Text("Remove", color = AirOfflineRed)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text("Content Detection & Safety", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Explicit Content Filter", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                Text("Block adult web domains and inappropriate search results.", fontSize = 12.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = explicitContentFilter,
                                onCheckedChange = { checked ->
                                    explicitContentFilter = checked
                                    coroutineScope.launch {
                                        repository.updateSafetyFilters(suspiciousKeywordFilter, checked)
                                        Toast.makeText(context, "Filter updated", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }
                        HorizontalDivider(color = Color(0xFFF3F4F6), modifier = Modifier.padding(vertical = 12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Suspicious Keyword Alerts", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                Text("Notify parent when sensitive words are typed or received in messages.", fontSize = 12.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = suspiciousKeywordFilter,
                                onCheckedChange = { checked ->
                                    suspiciousKeywordFilter = checked
                                    coroutineScope.launch {
                                        repository.updateSafetyFilters(checked, explicitContentFilter)
                                        Toast.makeText(context, "Keyword alert setting updated", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }

                        if (suspiciousKeywordFilter) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Text("Monitored Keywords:", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                customKeywords.forEach { kw ->
                                    InputChip(
                                        selected = true,
                                        onClick = {
                                            customKeywords = customKeywords - kw
                                        },
                                        label = { Text(kw, fontSize = 12.sp) },
                                        trailingIcon = {
                                            Icon(Icons.Default.Close, contentDescription = "Remove", modifier = Modifier.size(14.dp))
                                        }
                                    )
                                }
                                AssistChip(
                                    onClick = { showAddKeywordDialog = true },
                                    label = { Text("+ Add", fontSize = 12.sp) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF1EDFA))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Default.PrivacyTip, contentDescription = null, tint = AirBluePrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Child Privacy Protection", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AirBlueDark)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("AirGuard only detects flagged keywords and safety alerts. Data is encrypted and securely synced to your family's private Firebase backend.", fontSize = 12.sp, color = Color(0xFF1E3A8A))
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(36.dp))
            }
        }
    }
}
