package com.example.ui.screens

import android.graphics.BitmapFactory
import android.content.Intent
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.compose.ui.platform.LocalContext
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.repository.ParentRepository
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID
import java.io.File

@Composable
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
fun FilesScreen(deviceId: String, deviceName: String, repository: ParentRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val firestore = remember { repository.getFirestore() }
    val doc = remember(deviceId, firestore) { firestore?.collection("remote_requests")?.document("media_access")?.collection("devices")?.document(deviceId) }
    var data by remember { mutableStateOf<Map<String, Any>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var mediaType by remember { mutableStateOf("IMAGES") }
    var currentPath by remember(deviceId) { mutableStateOf("") }
    var requestId by remember(deviceId) { mutableStateOf(UUID.randomUUID().toString()) }
    var transferStatus by remember(deviceId) { mutableStateOf("") }
    var transferId by remember(deviceId) { mutableStateOf("") }
    var transferAction by remember(deviceId) { mutableStateOf("OPEN") }
    var selectedShareEntry by remember(deviceId) { mutableStateOf<Pair<String, String>?>(null) }
    var videoPlaybackFile by remember(deviceId) { mutableStateOf<File?>(null) }

    DisposableEffect(doc, transferId) {
        if (doc == null || transferId.isBlank()) onDispose { }
        else {
            val transferDoc = doc.collection("downloads").document(transferId)
            val reg = transferDoc.addSnapshotListener { snapshot, listenerError ->
                if (listenerError != null) transferStatus = listenerError.localizedMessage ?: "Transfer failed"
                else when (snapshot?.getString("status")) {
                    "READY" -> if (!transferStatus.startsWith("Receiving")) {
                        transferStatus = "Receiving ${snapshot.getString("fileName") ?: "file"}…"
                        scope.launch {
                            runCatching {
                                val count = (snapshot.getLong("chunkCount") ?: 0L).toInt()
                                require(count in 1..100) { "Invalid file transfer." }
                                val bytes = java.io.ByteArrayOutputStream()
                                for (index in 0 until count) {
                                    val chunk = transferDoc.collection("chunks").document(index.toString()).get().await()
                                    val encoded = chunk.getString("data") ?: error("File transfer is incomplete.")
                                    bytes.write(Base64.decode(encoded, Base64.DEFAULT))
                                }
                                val safeName = (snapshot.getString("fileName") ?: "child-file").replace(Regex("[^A-Za-z0-9._ -]"), "_").take(120)
                                val folder = File(context.cacheDir, "opened_child_files").apply { mkdirs() }
                                val output = File(folder, safeName).apply { writeBytes(bytes.toByteArray()) }
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", output)
                                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(output.extension.lowercase()) ?: "application/octet-stream"
                                when (transferAction) {
                                    "SHARE" -> {
                                        val share = Intent(Intent.ACTION_SEND).apply {
                                            type = mime
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            clipData = android.content.ClipData.newUri(context.contentResolver, output.name, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(share, "Share ${output.name}"))
                                        transferStatus = "Ready to share ${output.name}"
                                    }
                                    "PLAY_VIDEO" -> {
                                        videoPlaybackFile = output
                                        transferStatus = "Playing ${output.name}"
                                    }
                                    else -> {
                                        val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        context.startActivity(Intent.createChooser(view, "Open ${output.name}"))
                                        transferStatus = "Opened ${output.name}"
                                    }
                                }
                                transferDoc.update("status", "OPENED").await()
                            }.onFailure { transferStatus = it.localizedMessage ?: "Could not open file." }
                        }
                    }
                    "ERROR" -> transferStatus = snapshot.getString("details") ?: "Child could not read this file."
                    "PENDING", "TRANSFERRING" -> transferStatus = "Preparing file from child…"
                }
            }
            onDispose { reg.remove() }
        }
    }

    DisposableEffect(doc) {
        if (doc == null) {
            error = "Firebase is unavailable."
            onDispose { }
        } else {
            val registration: ListenerRegistration = doc.addSnapshotListener { snapshot, listenerError ->
                if (listenerError != null) error = listenerError.localizedMessage
                else {
                    error = null
                    data = snapshot?.data
                }
            }
            onDispose { registration.remove() }
        }
    }

    fun requestListing(type: String, newRequestId: String = UUID.randomUUID().toString(), path: String = currentPath) {
        mediaType = type
        currentPath = path
        requestId = newRequestId
        error = null
        scope.launch {
            runCatching {
                doc?.set(mapOf(
                    "deviceId" to deviceId,
                    "requestId" to newRequestId,
                    "status" to "PENDING",
                    "mediaType" to type,
                    "currentPath" to path,
                    "parentUid" to repository.authRepository.getCurrentUid(),
                    "requestedAt" to System.currentTimeMillis(),
                    "entries" to emptyList<Map<String, Any>>(),
                    "previewPath" to "",
                    "previewBase64" to ""
                ))?.await()
            }.onFailure { error = it.localizedMessage ?: "Could not request media list." }
        }
    }

    LaunchedEffect(doc, deviceId) { if (doc != null) requestListing(mediaType) }

    fun finish() {
        scope.launch { runCatching { doc?.update("status", "ENDED")?.await() }; onBack() }
    }

    fun requestFileTransfer(name: String, path: String, action: String) {
        val id = UUID.randomUUID().toString()
        transferAction = action
        transferId = id
        transferStatus = "Requesting $name from child…"
        scope.launch {
            runCatching { doc?.collection("downloads")?.document(id)?.set(mapOf(
                "transferId" to id, "deviceId" to deviceId, "path" to path,
                "fileName" to name, "status" to "PENDING", "requestedAt" to System.currentTimeMillis(),
                "parentUid" to repository.authRepository.getCurrentUid()
            ))?.await() }.onFailure { transferStatus = it.localizedMessage ?: "Could not request file." }
        }
    }

    val responseMatchesRequest = data?.get("requestId") == requestId &&
        data?.get("mediaType") == mediaType &&
        (data?.get("currentPath") as? String ?: "") == currentPath
    val status = if (responseMatchesRequest) data?.get("status") as? String ?: "PENDING" else "PENDING"
    val servedType = data?.get("mediaType") as? String ?: mediaType
    val entries = if (responseMatchesRequest && servedType == mediaType) (data?.get("entries") as? List<*>)?.mapNotNull { it as? Map<*, *> }.orEmpty() else emptyList()
    val previewPath = if (responseMatchesRequest) data?.get("previewPath") as? String ?: "" else ""
    val previewForPath = if (responseMatchesRequest) data?.get("previewForPath") as? String ?: "" else ""
    val previewBase64 = if (responseMatchesRequest) data?.get("previewBase64") as? String ?: "" else ""
    val previewBitmap = remember(previewBase64, previewForPath) {
        runCatching {
            if (previewBase64.isBlank()) null else Base64.decode(previewBase64, Base64.DEFAULT).let { bytes ->
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
            }
        }.getOrNull()
    }
    val previewName = entries.firstOrNull { it["path"] == previewPath }?.get("name") as? String ?: "Selected video"

    selectedShareEntry?.let { (name, path) ->
        AlertDialog(
            onDismissRequest = { selectedShareEntry = null },
            icon = { Icon(Icons.Default.Share, contentDescription = null) },
            title = { Text(name, maxLines = 1) },
            text = { Text("Download this file from the child device and open Android’s share menu? Transfers are limited to 20 MB.") },
            confirmButton = {
                TextButton(onClick = {
                    selectedShareEntry = null
                    requestFileTransfer(name, path, "SHARE")
                }) { Text("Share file") }
            },
            dismissButton = {
                TextButton(onClick = { selectedShareEntry = null }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Child Files & Media - $deviceName") },
                navigationIcon = { IconButton(onClick = { finish() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
                actions = {
                    TextButton(onClick = { requestListing(mediaType, UUID.randomUUID().toString()) }) { Text("Refresh") }
                    TextButton(onClick = { finish() }) { Text("Close") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Text("Child files and media", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("Browse shared storage from the child phone. Long-press a file to share it; tap a video preview to play it. Protected Android app-data folders are excluded.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(12.dp))
            TabRow(selectedTabIndex = when (mediaType) { "VIDEOS" -> 1; "FILES" -> 2; else -> 0 }) {
                Tab(selected = mediaType == "IMAGES", onClick = { if (mediaType != "IMAGES") requestListing("IMAGES") }, text = { Text("Images") }, icon = { Icon(Icons.Default.Image, null) })
                Tab(selected = mediaType == "VIDEOS", onClick = { if (mediaType != "VIDEOS") requestListing("VIDEOS") }, text = { Text("Videos") }, icon = { Icon(Icons.Default.Movie, null) })
                Tab(selected = mediaType == "FILES", onClick = { if (mediaType != "FILES") requestListing("FILES", path = "") }, text = { Text("Files") }, icon = { Icon(Icons.Default.Folder, null) })
            }
            if (mediaType == "FILES") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(currentPath.ifBlank { "/" }, Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, maxLines = 1)
                    if (currentPath.isNotBlank()) {
                        TextButton(onClick = {
                            val parent = currentPath.trimEnd('/').substringBeforeLast('/', "")
                            requestListing("FILES", path = parent)
                        }) { Text("Up") }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (transferStatus.isNotBlank()) Text(transferStatus, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            when {
                error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
                status == "PENDING" -> Text("Loading media from the child device…")
                status == "PERMISSION_REQUIRED" -> Text("Enable media access in AirGuard Kids Settings, then tap Refresh.")
                status != "ACTIVE" -> Text("Media listing unavailable ($status).")
                else -> {
                    Text("${entries.size} ${mediaType.lowercase()} found", style = MaterialTheme.typography.labelLarge)
                    if (mediaType != "FILES" && previewPath.isNotBlank()) {
                        Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(if (mediaType == "VIDEOS") "Video preview" else "Image preview", fontWeight = FontWeight.SemiBold)
                                if (previewBitmap != null && previewForPath == previewPath) {
                                    Image(previewBitmap, contentDescription = "Selected media preview", modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp))
                                } else {
                                    Text("Preparing preview…", modifier = Modifier.padding(vertical = 20.dp))
                                }
                                if (mediaType == "VIDEOS" && previewForPath == previewPath) {
                                    TextButton(onClick = { requestFileTransfer(previewName, previewPath, "PLAY_VIDEO") }) {
                                        Icon(Icons.Default.Movie, contentDescription = null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Play video here (up to 20 MB)")
                                    }
                                }
                                videoPlaybackFile?.let { file ->
                                    Spacer(Modifier.height(8.dp))
                                    InlineVideoPlayer(file = file, modifier = Modifier.fillMaxWidth().height(230.dp))
                                }
                            }
                        }
                    }
                        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        items(entries, key = { it["path"].toString() }) { entry ->
                            val name = entry["name"] as? String ?: "Unknown"
                            val path = entry["path"] as? String ?: ""
                            val size = (entry["size"] as? Number)?.toLong() ?: 0L
                            val modifiedAt = (entry["modifiedAt"] as? Number)?.toLong() ?: 0L
                            val isDirectory = entry["directory"] as? Boolean ?: false
                            ListItem(
                                headlineContent = { Text(name, maxLines = 1) },
                                supportingContent = {
                                    Text(if (isDirectory) "Folder" else "${formatBytes(size)} · ${if (modifiedAt > 0) java.text.DateFormat.getDateTimeInstance().format(java.util.Date(modifiedAt)) else "Date unavailable"}")
                                },
                                leadingContent = {
                                    Icon(
                                        when {
                                            mediaType == "FILES" && isDirectory -> Icons.Default.Folder
                                            mediaType == "FILES" -> Icons.Default.InsertDriveFile
                                            mediaType == "VIDEOS" -> Icons.Default.Movie
                                            else -> Icons.Default.Image
                                        },
                                        contentDescription = null
                                    )
                                },
                                modifier = Modifier.combinedClickable(
                                    enabled = mediaType == "FILES" || !isDirectory,
                                    onClick = {
                                        if (mediaType == "FILES" && isDirectory) requestListing("FILES", path = path)
                                        else if (mediaType == "FILES") requestFileTransfer(name, path, "OPEN")
                                        else scope.launch {
                                            videoPlaybackFile = null
                                            runCatching { doc?.update(mapOf("previewPath" to path, "previewBase64" to ""))?.await() }
                                                .onFailure { error = it.localizedMessage }
                                        }
                                    },
                                    onLongClick = {
                                        if (mediaType == "FILES" && !isDirectory) selectedShareEntry = name to path
                                    }
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InlineVideoPlayer(file: File, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { viewContext ->
            VideoView(viewContext).apply {
                tag = file.absolutePath
                val controls = MediaController(viewContext)
                setMediaController(controls)
                controls.setAnchorView(this)
                setVideoURI(Uri.fromFile(file))
                setOnPreparedListener { it.start() }
            }
        },
        update = { player ->
            if (player.tag != file.absolutePath) {
                player.tag = file.absolutePath
                player.setVideoURI(Uri.fromFile(file))
                player.setOnPreparedListener { it.start() }
            }
        }
    )
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    else -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
}
