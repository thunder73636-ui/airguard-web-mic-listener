package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.LocationOff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.RingVolume
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Device
import com.example.data.model.LocationLog
import com.example.data.repository.ParentRepository
import com.example.ui.components.hoverLift
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val LocationCanvas = Color(0xFFFFF8FC)
private val LocationLilac = Color(0xFFEDE7FF)
private val LocationPink = Color(0xFFFFE5EF)
private val LocationInk = Color(0xFF29243A)
private val LocationMuted = Color(0xFF777185)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationScreen(
    devices: List<Device>,
    selectedDeviceIndex: Int,
    repository: ParentRepository,
    onSelectDeviceIndex: (Int) -> Unit,
    onNavigateToBinding: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val device = devices.getOrNull(selectedDeviceIndex) ?: devices.firstOrNull()
    var deviceMenuOpen by remember { mutableStateOf(false) }
    var isRingRequested by remember(device?.id) { mutableStateOf(false) }

    val logs by (device?.let { repository.observeLocationLogs(it.id) } ?: flowOf(emptyList()))
        .collectAsState(initial = emptyList())
    var selectedLocationLog by remember(device?.id) { mutableStateOf<LocationLog?>(null) }
    val mapLatitude = selectedLocationLog?.latitude ?: device?.latitude
    val mapLongitude = selectedLocationLog?.longitude ?: device?.longitude
    val mapTimestamp = selectedLocationLog?.timestamp ?: device?.locationTimestamp ?: 0L
    val mapPointIsAvailable = mapLatitude != null && mapLongitude != null && mapTimestamp > 0L

    LaunchedEffect(isRingRequested) {
        if (isRingRequested) {
            delay(65_000L)
            isRingRequested = false
        }
    }

    val pulse = rememberInfiniteTransition(label = "location_pin_pulse")
    val pinScale by pulse.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1_100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "location_pin_scale"
    )

    Scaffold(containerColor = LocationCanvas) { padding ->
      BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(padding)) {
        val expanded = maxWidth >= 840.dp
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .wrapContentWidth(Alignment.CenterHorizontally)
                .widthIn(max = if (expanded) 840.dp else 640.dp)
                .navigationBarsPadding()
                .padding(horizontal = if (expanded) 24.dp else 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = LocationLilac),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(color = Color.White.copy(alpha = 0.8f), shape = CircleShape, modifier = Modifier.size(54.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("🌷", fontSize = 27.sp)
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Little explorer", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = LocationInk)
                            Text("A gentle check-in for your family", fontSize = 13.sp, color = LocationMuted)
                        }
                    }
                }
            }

            if (device == null) {
                item {
                    Card(
                        shape = RoundedCornerShape(26.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.LocationOff, contentDescription = null, tint = Color(0xFFB59DCC), modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("No little phone linked yet", fontWeight = FontWeight.Bold, color = LocationInk, fontSize = 18.sp)
                            Spacer(Modifier.height(6.dp))
                            Text("Pair the child phone once. It will stay in your family list even when it is temporarily offline.", textAlign = TextAlign.Center, color = LocationMuted, fontSize = 13.sp)
                            Spacer(Modifier.height(18.dp))
                            Button(onClick = onNavigateToBinding, shape = RoundedCornerShape(16.dp)) { Text("Link a phone") }
                        }
                    }
                }
            } else {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Your family device", color = LocationMuted, fontSize = 12.sp)
                            Text(device.deviceName.ifBlank { "Child phone" }, color = LocationInk, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        Box {
                            FilledTonalButton(onClick = { deviceMenuOpen = true }, shape = RoundedCornerShape(16.dp)) {
                                Icon(Icons.Default.PhoneAndroid, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Choose device")
                            }
                            DropdownMenu(expanded = deviceMenuOpen, onDismissRequest = { deviceMenuOpen = false }) {
                                devices.forEachIndexed { index, item ->
                                    DropdownMenuItem(
                                        text = { Text(item.deviceName.ifBlank { "Child phone" }) },
                                        onClick = {
                                            onSelectDeviceIndex(index)
                                            deviceMenuOpen = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Card(
                        shape = RoundedCornerShape(28.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().animateContentSize().hoverLift()
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                color = LocationPink,
                                shape = CircleShape,
                                modifier = Modifier.size(104.dp).scale(pinScale)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFFE66F9A), modifier = Modifier.size(54.dp))
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            StatusPill(device.isOnline, device.lastSeenTimestamp)
                            Spacer(Modifier.height(16.dp))

                            if (mapPointIsAvailable) {
                                Text(if (selectedLocationLog == null) "Latest shared location" else "Selected check-in", fontWeight = FontWeight.Bold, color = LocationInk, fontSize = 17.sp)
                                Spacer(Modifier.height(7.dp))
                                Text(
                                    String.format(Locale.US, "%.5f, %.5f", mapLatitude, mapLongitude),
                                    color = Color(0xFF66548C),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(Modifier.height(5.dp))
                                Text("Updated ${formatLocationTime(mapTimestamp)}", color = LocationMuted, fontSize = 12.sp)
                                Spacer(Modifier.height(14.dp))
                                LocationPreviewCard(
                                    title = device.deviceName.ifBlank { "Child phone" },
                                    updatedAt = mapTimestamp,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(Modifier.height(17.dp))
                                if (selectedLocationLog != null) {
                                    TextButton(
                                        onClick = { selectedLocationLog = null },
                                        modifier = Modifier.align(Alignment.End)
                                    ) { Text("Show latest location") }
                                }
                                FilledTonalButton(
                                    onClick = {
                                        openLocationInMaps(context, mapLatitude!!, mapLongitude!!)
                                    },
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.fillMaxWidth().hoverLift()
                                ) {
                                    Icon(Icons.Default.Map, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Open this location in Maps")
                                }
                            } else {
                                Text("Waiting for a location", fontWeight = FontWeight.Bold, color = LocationInk, fontSize = 17.sp)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "This phone has not shared coordinates yet. Check its location permission, turn on location services, and confirm it has internet access.",
                                    color = LocationMuted,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                item {
                    Button(
                        onClick = {
                            if (!device.isOnline) {
                                Toast.makeText(context, "${device.deviceName} is linked, but offline right now", Toast.LENGTH_LONG).show()
                            } else {
                                val ring = !isRingRequested
                                scope.launch {
                                    try {
                                        repository.requestPhoneRing(device.id, ring)
                                        isRingRequested = ring
                                        Toast.makeText(context, if (ring) "Ring request sent" else "Stop request sent", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, e.message ?: "Could not send ring request", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        },
                        enabled = device.isOnline,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRingRequested) Color(0xFFE6A13D) else Color(0xFF8171C7),
                            disabledContainerColor = Color(0xFFE5E1EB)
                        ),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().height(54.dp)
                    ) {
                        Icon(if (isRingRequested) Icons.Default.StopCircle else Icons.Default.RingVolume, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            when {
                                isRingRequested -> "Stop ringing"
                                !device.isOnline -> "Phone is offline"
                                else -> "Ring this phone"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                item {
                    Column {
                        Text("Recent check-ins", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = LocationInk)
                        Text("Select a check-in, then open it in your Maps app.", fontSize = 12.sp, color = LocationMuted)
                    }
                }
                if (logs.isEmpty()) {
                    item {
                        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MyLocation, contentDescription = null, tint = Color(0xFFAA8DC7))
                                Spacer(Modifier.width(10.dp))
                                Text("Location history will appear here when the child phone shares a new check-in.", color = LocationMuted, fontSize = 13.sp)
                            }
                        }
                    }
                } else {
                    items(logs.take(12), key = { it.id }) { log ->
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedLocationLog?.id == log.id) LocationLilac else Color.White
                            ),
                            modifier = Modifier.fillMaxWidth().hoverLift().clickable {
                                selectedLocationLog = log
                            }
                        ) {
                            Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(color = LocationLilac, shape = CircleShape, modifier = Modifier.size(40.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF8171C7))
                                    }
                                }
                                Spacer(Modifier.width(11.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(String.format(Locale.US, "%.5f, %.5f", log.latitude, log.longitude), fontWeight = FontWeight.SemiBold, color = LocationInk, fontSize = 13.sp)
                                    Text(formatLocationTime(log.timestamp), color = LocationMuted, fontSize = 11.sp)
                                }
                                Icon(Icons.Default.Map, contentDescription = "Open check-in in Maps", tint = Color(0xFF8171C7))
                            }
                        }
                    }
                }
            }
        }
      }
    }
}

@Composable
private fun LocationPreviewCard(
    title: String,
    updatedAt: Long,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(96.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE9E7F3))
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(color = Color.White, shape = CircleShape, modifier = Modifier.size(52.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF8171C7), modifier = Modifier.size(30.dp))
                }
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Map opens in your Maps app", color = LocationInk, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("$title · ${formatLocationTime(updatedAt)}", color = LocationMuted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun StatusPill(isOnline: Boolean, lastSeen: Long) {
    val label = if (isOnline) "Linked · Online now" else "Linked · ${formatLastSeen(lastSeen)}"
    val background = if (isOnline) Color(0xFFE4F7EB) else Color(0xFFFFF1D8)
    val dot = if (isOnline) Color(0xFF50AD75) else Color(0xFFD99B3D)
    Surface(color = background, shape = RoundedCornerShape(30.dp)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(dot, CircleShape))
            Spacer(Modifier.width(7.dp))
            Text(label, color = LocationInk, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun formatLocationTime(timestamp: Long): String =
    SimpleDateFormat("EEE, h:mm a", Locale.getDefault()).format(Date(timestamp))

private fun formatLastSeen(timestamp: Long): String {
    if (timestamp <= 0L) return "waiting for first sync"
    val minutes = ((System.currentTimeMillis() - timestamp).coerceAtLeast(0L) / 60_000L).toInt()
    return when {
        minutes < 1 -> "seen just now"
        minutes == 1 -> "seen 1 min ago"
        minutes < 60 -> "seen $minutes min ago"
        else -> "seen ${minutes / 60} hr ago"
    }
}

private fun openLocationInMaps(context: android.content.Context, latitude: Double, longitude: Double) {
    val coordinates = "$latitude,$longitude"
    try {
        val uri = Uri.parse("geo:$coordinates?q=$coordinates")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    } catch (_: android.content.ActivityNotFoundException) {
        try {
            val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=$latitude%2C$longitude")
            context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
        } catch (_: Exception) {
            Toast.makeText(context, "No map app or browser is available", Toast.LENGTH_SHORT).show()
        }
    }
}
