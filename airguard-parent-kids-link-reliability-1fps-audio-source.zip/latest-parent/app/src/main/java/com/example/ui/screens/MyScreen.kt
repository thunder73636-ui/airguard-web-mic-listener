package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Device
import com.example.data.model.ParentAccount
import com.example.data.repository.ParentRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyScreen(
    account: ParentAccount?,
    devices: List<Device>,
    repository: ParentRepository,
    onNavigateToBinding: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showAdminCodeDialog by remember { mutableStateOf(false) }
    var adminPin by remember { mutableStateOf("1234") }
    var showRedeemDialog by remember { mutableStateOf(false) }
    var redeemCode by remember { mutableStateOf("") }
    var showDevicesDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showRateDialog by remember { mutableStateOf(false) }
    var showSubscriptionInfoDialog by remember { mutableStateOf(false) }
    var showSupportDialog by remember { mutableStateOf(false) }
    var isAuthLoading by remember { mutableStateOf(false) }

    if (showSubscriptionInfoDialog) {
        AlertDialog(
            onDismissRequest = { showSubscriptionInfoDialog = false },
            title = { Text("My Subscription", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Plan: AirGuard Full Access (All Features Unlocked)", fontWeight = FontWeight.SemiBold, color = Color(0xFF7968C4))
                    Text("Time left: Unlimited / Lifetime", color = Color.Gray)
                    Text("Remote camera, screen mirroring, downtime, app management, and location features are completely unlocked.")
                }
            },
            confirmButton = {
                Button(onClick = { showSubscriptionInfoDialog = false }) { Text("OK") }
            }
        )
    }

    if (showAdminCodeDialog) {
        AlertDialog(
            onDismissRequest = { showAdminCodeDialog = false },
            title = { Text("Parent Admin PIN", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Set a 4-digit PIN required to unlock app settings or child modifications:", fontSize = 13.sp, color = Color.Gray)
                    OutlinedTextField(
                        value = adminPin,
                        onValueChange = { if (it.length <= 4) adminPin = it },
                        label = { Text("4-Digit PIN") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    showAdminCodeDialog = false
                    Toast.makeText(context, "Admin PIN saved", Toast.LENGTH_SHORT).show()
                }) { Text("Save PIN") }
            },
            dismissButton = {
                TextButton(onClick = { showAdminCodeDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showDevicesDialog) {
        AlertDialog(
            onDismissRequest = { showDevicesDialog = false },
            title = { Text("Child's Devices (${devices.size})", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (devices.isEmpty()) {
                        Text("No child devices are currently linked.", color = Color.Gray)
                    } else {
                        devices.forEach { dev ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8FC)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(dev.deviceName, fontWeight = FontWeight.Bold)
                                        Text("${dev.batteryLevel}% Battery", color = Color(0xFF047857), fontWeight = FontWeight.SemiBold)
                                    }
                                    Text("Model: ${dev.model}", fontSize = 11.sp, color = Color.Gray)
                                    Text("IP: ${dev.ipAddress}   ${dev.androidVersion}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    showDevicesDialog = false
                    onNavigateToBinding()
                }) {
                    Text("+ Pair New Device")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDevicesDialog = false }) { Text("Close") }
            }
        )
    }

    if (showRedeemDialog) {
        AlertDialog(
            onDismissRequest = { showRedeemDialog = false },
            title = { Text("Redeem a Code", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = redeemCode,
                    onValueChange = { redeemCode = it },
                    label = { Text("Promo or Activation Code") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    showRedeemDialog = false
                    Toast.makeText(context, "Code '$redeemCode' applied successfully!", Toast.LENGTH_SHORT).show()
                }) { Text("Redeem") }
            },
            dismissButton = {
                TextButton(onClick = { showRedeemDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showRateDialog) {
        AlertDialog(
            onDismissRequest = { showRateDialog = false },
            title = { Text("Rate AirGuard", fontWeight = FontWeight.Bold) },
            text = {
                Text("Enjoying AirGuard Parental Control? Please leave a 5-star rating on Google Play Store to support development!")
            },
            confirmButton = {
                Button(onClick = {
                    showRateDialog = false
                    Toast.makeText(context, "Thank you for your rating!", Toast.LENGTH_SHORT).show()
                }) { Text("Rate 5 Stars") }
            },
            dismissButton = {
                TextButton(onClick = { showRateDialog = false }) { Text("Later") }
            }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("About AirGuard", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Version: V2.7.8.0", fontWeight = FontWeight.Bold)
                    Text("AirGuard Parent Edition", color = Color(0xFF7968C4))
                    Text("Compliant with Google Play Family and Child Safety standards.")
                    Text("All features (remote camera, mirroring, audio, web safety) unlocked.")
                }
            },
            confirmButton = {
                Button(onClick = { showAboutDialog = false }) { Text("OK") }
            }
        )
    }

    if (showSupportDialog) {
        AlertDialog(
            onDismissRequest = { showSupportDialog = false },
            title = { Text("Customer Support", fontWeight = FontWeight.Bold) },
            text = {
                Text("Need help linking your child's device? Contact 24/7 AirGuard support at support@airguard.com.")
            },
            confirmButton = {
                Button(onClick = { showSupportDialog = false }) { Text("Contact Support") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF8FC)),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFFEDE9FE), Color(0xFFFFF8FC))
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val activity = context as? Activity
                            if (activity != null) {
                                isAuthLoading = true
                                coroutineScope.launch {
                                    val res = repository.authRepository.signInWithGoogle(activity)
                                    isAuthLoading = false
                                    res.onSuccess {
                                        try {
                                            val savedLinks = repository.claimGuestLinkedDevicesForAccount(it.uid)
                                            val linkedMessage = if (savedLinks == 1) "1 child link saved" else "$savedLinks child links saved"
                                            Toast.makeText(context, "Signed in with Google as ${it.displayName}; $linkedMessage to this account", Toast.LENGTH_LONG).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Signed in, but child links could not be saved: ${e.localizedMessage ?: "check internet and Firestore rules"}", Toast.LENGTH_LONG).show()
                                        }
                                    }.onFailure {
                                        Toast.makeText(context, "Sign in: ${it.localizedMessage}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFD6CCF0),
                        modifier = Modifier.size(60.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (isAuthLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color(0xFF7968C4), strokeWidth = 2.dp)
                            } else {
                                Icon(
                                    Icons.Default.Person,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (account?.isLoggedIn == true) account.name else "Parent Account",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (account?.isLoggedIn == true) account.email else "Tap to Sign in with Google",
                                fontSize = 13.sp,
                                color = Color(0xFF716B7D)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(">", color = Color(0xFF94A3B8), fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    SettingsItemRow(
                        icon = Icons.Outlined.AddBox,
                        title = "Features & License",
                        subtitle = "Full Access (All Features Unlocked)",
                        trailingText = "Active >",
                        onClick = { showSubscriptionInfoDialog = true }
                    )
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    SettingsItemRow(
                        icon = Icons.Outlined.Home,
                        title = "Family Members",
                        trailingText = "Organizer >",
                        onClick = {
                            val parentName = account?.name ?: "Parent User"
                            Toast.makeText(context, "Family Group: $parentName (Organizer)", Toast.LENGTH_SHORT).show()
                        }
                    )
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    SettingsItemRow(
                        icon = Icons.Outlined.Mail,
                        title = "Email Reports",
                        trailingText = "Daily >",
                        onClick = {
                            Toast.makeText(context, "Daily parent email reports enabled", Toast.LENGTH_SHORT).show()
                        }
                    )
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    SettingsItemRow(
                        icon = Icons.Outlined.PhoneAndroid,
                        title = "Child's Devices",
                        trailingText = "${devices.size} >",
                        onClick = { showDevicesDialog = true }
                    )
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    SettingsItemRow(
                        icon = Icons.Outlined.Lock,
                        title = "Admin Code",
                        trailingText = ">",
                        onClick = { showAdminCodeDialog = true }
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    SettingsItemRow(
                        icon = Icons.Outlined.CardGiftcard,
                        title = "Redeem a Code",
                        trailingText = ">",
                        onClick = { showRedeemDialog = true }
                    )
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    SettingsItemRow(
                        icon = Icons.Outlined.CleaningServices,
                        title = "Clear Cache",
                        trailingText = ">",
                        onClick = {
                            Toast.makeText(context, "Cache cleared successfully (0.0 MB)", Toast.LENGTH_SHORT).show()
                        }
                    )
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    SettingsItemRow(
                        icon = Icons.Outlined.Share,
                        title = "Share with Friends",
                        trailingText = ">",
                        onClick = {
                            val shareIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, "Keep your kids safe online with AirGuard: https://apps.airdroid.com/kids")
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share AirGuard"))
                        }
                    )
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    SettingsItemRow(
                        icon = Icons.Outlined.StarOutline,
                        title = "Rate Us",
                        trailingText = ">",
                        onClick = { showRateDialog = true }
                    )
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    SettingsItemRow(
                        icon = Icons.Outlined.Info,
                        title = "About Us",
                        trailingText = "V2.7.8.0 >",
                        onClick = { showAboutDialog = true }
                    )
                }
            }
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            coroutineScope.launch {
                                repository.logout()
                                Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
                            }
                        }
                ) {
                    Box(modifier = Modifier.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Sign Out",
                            fontWeight = FontWeight.Medium,
                            fontSize = 15.sp,
                            color = Color(0xFF334155)
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFFEAE5F8),
                    border = BorderStroke(2.dp, Color.White),
                    shadowElevation = 3.dp,
                    modifier = Modifier
                        .size(44.dp)
                        .clickable { showSupportDialog = true }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.SupportAgent, contentDescription = "Support", tint = Color(0xFF7968C4), modifier = Modifier.size(28.dp))
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsItemRow(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    trailingText: String? = null,
    trailingBadge: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                icon,
                contentDescription = null,
                tint = Color(0xFF1E293B),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    title,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    color = Color(0xFF1E293B)
                )
                if (subtitle != null) {
                    Text(
                        subtitle,
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }
        }
        if (trailingBadge != null) {
            Text(
                trailingBadge,
                color = Color(0xFFA855F7),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        } else if (trailingText != null) {
            Text(
                trailingText,
                color = Color(0xFF94A3B8),
                fontSize = 13.sp,
                fontWeight = FontWeight.Normal
            )
        }
    }
}
