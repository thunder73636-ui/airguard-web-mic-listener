package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.DiagnosticStageStatus
import com.example.data.model.MediaSessionState
import com.example.data.repository.ParentRepository
import com.example.media.RemoteAudioPlayer
import com.example.media.RemoteVideoSurface
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.collect
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemoteScreen(
    deviceId: String,
    initialType: String = "CAMERA",
    repository: ParentRepository,
    onBack: () -> Unit,
    onNavigateToDiagnostics: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val device by repository.observeDeviceById(deviceId).collectAsState(initial = null)
    var currentType by remember { mutableStateOf(initialType) } // ONE_WAY_AUDIO, CAMERA, SCREEN_MIRROR, ACCESSIBILITY_SCREENSHOT

    val signalingManager = remember { repository.createMediaSignalingManager() }
    val sessionState by signalingManager.sessionState.collectAsState()
    val sessionDetails by signalingManager.sessionDetails.collectAsState()
    val turnFallbackAvailable by signalingManager.turnFallbackAvailable.collectAsState()
    val diagnostics by signalingManager.diagnostics.collectAsState()
    val snapshotError by signalingManager.snapshotError.collectAsState()
    var childSnapshot by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(signalingManager) {
        // StateFlow conflates frames while decoding, so a slow Parent phone renders the newest
        // available image instead of starting a cancellable decode for every incoming frame.
        signalingManager.childSnapshot.collect { bytes ->
            if (bytes == null) {
                childSnapshot = null
                return@collect
            }
            val nextFrame = withContext(Dispatchers.Default) {
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
            childSnapshot = nextFrame
        }
    }
    DisposableEffect(childSnapshot) {
        // Capture this exact bitmap. Reading the delegated state inside onDispose can recycle
        // the newly arrived frame while Compose is still drawing it.
        val frameToRecycle = childSnapshot
        onDispose { frameToRecycle?.recycle() }
    }

    val audioPlayer = remember { RemoteAudioPlayer(context) }
    var isAudioMuted by remember { mutableStateOf(false) }
    var audioVolume by remember { mutableFloatStateOf(0.85f) }
    var isCameraAudioListening by remember { mutableStateOf(true) }
    var isAccessibilityAudioListening by remember { mutableStateOf(false) }
    var isFrontCamera by remember { mutableStateOf(false) }
    var isFlashlightOn by remember { mutableStateOf(false) }
    var showDiagnosticModal by remember { mutableStateOf(false) }
    var showFullscreenVideo by remember { mutableStateOf(false) }
    var showFullscreenScreenshot by remember { mutableStateOf(false) }

    var elapsedSeconds by remember { mutableIntStateOf(0) }
    var isTimerRunning by remember { mutableStateOf(false) }

    val deviceName = device?.deviceName ?: "Child Device"
    val isOnline = device?.isOnline ?: false
    val hasPermission = when (currentType) {
        "CAMERA" -> device?.hasCameraPermission ?: false
        "ONE_WAY_AUDIO" -> device?.hasMicrophonePermission ?: false
        "SCREEN_MIRROR" -> true // The child must approve Android's one-session screen-capture prompt.
        "ACCESSIBILITY_SCREENSHOT" -> (device?.hasAccessibilityPermission == true) && (device?.hasMicrophonePermission == true)
        else -> device?.hasAccessibilityPermission ?: false
    }

    fun resetCallTimer() {
        elapsedSeconds = 0
        isTimerRunning = false
    }

    // Connect AudioPlayer routing callbacks to WebRTC diagnostics
    LaunchedEffect(audioPlayer) {
        audioPlayer.onRoutingChanged = { focusGranted, routingMode, playbackStatus ->
            signalingManager.webRtcManager.updateAudioRoutingDiagnostics(focusGranted, routingMode, playbackStatus)
        }
    }

    // Start one user-visible request. Retry policy belongs to the signaling manager so a
    // permission denial or offline child cannot trigger an endless stream of consent prompts.
    LaunchedEffect(currentType, deviceId) {
        resetCallTimer()
        val parentUid = repository.authRepository.getCurrentUid()
        signalingManager.startSession(
            deviceId = deviceId,
            type = currentType,
            parentUid = parentUid,
            isDeviceOnline = isOnline,
            hasPermission = hasPermission
        )
        if (currentType == "ACCESSIBILITY_SCREENSHOT") {
            signalingManager.sendControlCommand("SET_MICROPHONE", mapOf("enabled" to false))
        }
    }

    // Audio routing and focus configuration for incoming child audio (One-Way Audio & Camera Listen-in)
    LaunchedEffect(
        currentType,
        sessionState,
        diagnostics.overallStatus,
        diagnostics.remoteAudioTrackReceived,
        isCameraAudioListening,
        isAccessibilityAudioListening,
        isAudioMuted,
        audioVolume
    ) {
        val isMediaConnected = sessionState == MediaSessionState.CONNECTED ||
                diagnostics.overallStatus == DiagnosticStageStatus.RECEIVING_MEDIA ||
                diagnostics.remoteAudioTrackReceived

        val shouldListen = when (currentType) {
            "ONE_WAY_AUDIO" -> isMediaConnected
            "CAMERA" -> isMediaConnected && isCameraAudioListening
            "ACCESSIBILITY_SCREENSHOT" -> isAccessibilityAudioListening && isMediaConnected
            else -> false
        }

        if (shouldListen) {
            audioPlayer.start()
            audioPlayer.setVolume(audioVolume)
            audioPlayer.setMuted(isAudioMuted)
            signalingManager.webRtcManager.setAudioMuted(isAudioMuted)
            signalingManager.webRtcManager.setAudioVolume(audioVolume)
            isTimerRunning = true
        } else {
            audioPlayer.pause()
            signalingManager.webRtcManager.setAudioMuted(true)
            if (currentType != "ONE_WAY_AUDIO") {
                isTimerRunning = false
            }
        }
    }

    // Timer effect for call length
    LaunchedEffect(isTimerRunning) {
        if (isTimerRunning) {
            while (true) {
                delay(1000)
                elapsedSeconds++
            }
        }
    }

    // Cleanup resources on disposal
    DisposableEffect(Unit) {
        onDispose {
            signalingManager.endSession()
            audioPlayer.release()
        }
    }

    DisposableEffect(isFlashlightOn) {
        onDispose {
            if (isFlashlightOn) signalingManager.toggleChildFlash(false)
        }
    }

    val minutes = elapsedSeconds / 60
    val seconds = elapsedSeconds % 60
    val formattedTime = "%02d:%02d".format(minutes, seconds)

    if (showFullscreenVideo && (currentType == "CAMERA" || currentType == "SCREEN_MIRROR")) {
        Dialog(
            onDismissRequest = { showFullscreenVideo = false },
            properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true, dismissOnClickOutside = false)
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                RemoteVideoSurface(
                    webRtcManager = signalingManager.webRtcManager,
                    diagnostics = diagnostics,
                    deviceName = deviceName,
                    modifier = Modifier.fillMaxSize()
                )
                Row(
                    modifier = Modifier.align(Alignment.TopStart).fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { showFullscreenVideo = false },
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.55f), CircleShape)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close full screen", tint = Color.White)
                    }
                    if (currentType == "CAMERA") {
                        IconButton(
                            onClick = {
                                if (isFlashlightOn) {
                                    isFlashlightOn = false
                                    signalingManager.toggleChildFlash(false)
                                }
                                isFrontCamera = !isFrontCamera
                                signalingManager.flipChildCamera(isFrontCamera)
                            },
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.55f), CircleShape)
                        ) {
                            Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Switch camera", tint = Color.White)
                        }
                        IconButton(
                            onClick = {
                                isFlashlightOn = !isFlashlightOn
                                signalingManager.toggleChildFlash(isFlashlightOn)
                            },
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.55f), CircleShape)
                        ) {
                            Icon(
                                if (isFlashlightOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                contentDescription = if (isFlashlightOn) "Turn flashlight off" else "Turn flashlight on",
                                tint = if (isFlashlightOn) Color(0xFFFFD54F) else Color.White
                            )
                        }
                    }
                }
            }
        }
    }

    if (showFullscreenScreenshot && currentType == "ACCESSIBILITY_SCREENSHOT" && childSnapshot != null) {
        Dialog(
            onDismissRequest = { showFullscreenScreenshot = false },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                childSnapshot?.let { frame ->
                    Image(
                        bitmap = frame.asImageBitmap(),
                        contentDescription = "Accessibility View full screen",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
                IconButton(
                    onClick = { showFullscreenScreenshot = false },
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close full screen", tint = Color.White)
                }
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(16.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF047857)
                ) {
                    Text(
                        "LIVE",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showDiagnosticModal) {
        DiagnosticScreen(
            deviceId = deviceId,
            deviceName = deviceName,
            signalingManager = signalingManager,
            onBack = { showDiagnosticModal = false },
            onRetry = {
                resetCallTimer()
                val parentUid = repository.authRepository.getCurrentUid()
            signalingManager.startSession(deviceId, currentType, parentUid, isOnline, hasPermission)
            }
        )
        return
    }

    // Handle Connecting, Failed, or Permission-Denied States
    val isBusyConnecting = sessionState == MediaSessionState.CONNECTING ||
            sessionState == MediaSessionState.OFFER_SENT ||
            sessionState == MediaSessionState.ANSWER_RECEIVED ||
            sessionState == MediaSessionState.RECONNECTING
    if (isBusyConnecting) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = deviceName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF1E293B)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color(0xFF1E293B))
                        }
                    },
                    actions = {
                        IconButton(onClick = { showDiagnosticModal = true }) {
                            Icon(Icons.Outlined.Analytics, contentDescription = "Diagnostics", tint = Color(0xFF7968C4))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            containerColor = Color.White
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp)
                ) {
                    ConnectingDeviceIllustration()
                    Spacer(modifier = Modifier.height(36.dp))
                    Text(
                        text = "Connecting to $deviceName...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = Color(0xFF1E293B),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = sessionDetails.ifBlank { "Negotiating WebRTC SDP media offer with child device..." },
                        fontSize = 13.sp,
                        color = Color(0xFF716B7D),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    OutlinedButton(
                        onClick = { showDiagnosticModal = true },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Outlined.Analytics, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View Live Pipeline Diagnostics")
                    }
                }
            }
        }
        return
    }

    // Handle Error States (Failed, Timeout, Permission Denied, Device Offline)
    val isErrorState = sessionState == MediaSessionState.FAILED ||
            sessionState == MediaSessionState.PERMISSION_DENIED ||
            sessionState == MediaSessionState.DEVICE_OFFLINE
    if (isErrorState) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = deviceName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF1E293B)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color(0xFF1E293B))
                        }
                    },
                    actions = {
                        IconButton(onClick = { showDiagnosticModal = true }) {
                            Icon(Icons.Outlined.Analytics, contentDescription = "Diagnostics", tint = Color(0xFF7968C4))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            containerColor = Color.White
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(28.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFFEE2E2),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = Color(0xFFEF4444),
                                modifier = Modifier.size(40.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    val errorTitle = when (sessionState) {
                        MediaSessionState.PERMISSION_DENIED -> "Permission Authorization Required"
                        MediaSessionState.DEVICE_OFFLINE -> "Child Device Offline"
                        else -> "Stream Connection Failed"
                    }
                    Text(
                        text = errorTitle,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color(0xFF0F172A),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = sessionDetails,
                        fontSize = 13.sp,
                        color = Color(0xFF716B7D),
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = {
                            resetCallTimer()
                            val parentUid = repository.authRepository.getCurrentUid()
                            signalingManager.startSession(deviceId, currentType, parentUid, isOnline, hasPermission)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7968C4)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Retry Connection", fontWeight = FontWeight.Bold)
                    }
                    if (turnFallbackAvailable) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                val parentUid = repository.authRepository.getCurrentUid()
                                signalingManager.startSession(deviceId, currentType, parentUid, isOnline, hasPermission, forceRelay = true)
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Retry using TURN relay", fontWeight = FontWeight.Bold)
                        }
                        Text(
                            "Firebase still carries the connection setup; TURN relays the audio/video if direct networking failed.",
                            modifier = Modifier.padding(top = 8.dp),
                            fontSize = 12.sp,
                            color = Color(0xFF716B7D),
                            textAlign = TextAlign.Center
                        )
                    } else if (sessionState == MediaSessionState.FAILED &&
                        sessionDetails.contains("TURN relay is required", ignoreCase = true)
                    ) {
                        Text(
                            "TURN retry is unavailable because this APK has no TURN server credentials. Add TURN_SERVER_URL, TURN_USERNAME, and TURN_CREDENTIAL, then rebuild both apps.",
                            modifier = Modifier.padding(top = 10.dp),
                            fontSize = 12.sp,
                            color = Color(0xFFB45309),
                            textAlign = TextAlign.Center
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { showDiagnosticModal = true },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Outlined.Analytics, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("View Diagnostics Breakdown")
                    }
                }
            }
        }
        return
    }

    // One-Way Audio Connected Screen
            if (currentType == "ONE_WAY_AUDIO") {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "One-Way Audio",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF1E293B)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color(0xFF1E293B))
                        }
                    },
                    actions = {
                        IconButton(onClick = { showDiagnosticModal = true }) {
                            Icon(Icons.Outlined.Analytics, contentDescription = "Diagnostics", tint = Color(0xFF7968C4))
                        }
                        IconButton(onClick = { currentType = "CAMERA" }) {
                            Icon(Icons.Outlined.Videocam, contentDescription = "Switch to Camera", tint = Color(0xFF716B7D))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            containerColor = Color.White
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // Real status badge distinguishing Receiving Media vs Connected Without Media
                val (statusBg, statusFg, statusLabel) = when (diagnostics.overallStatus) {
                    DiagnosticStageStatus.RECEIVING_MEDIA ->
                        Triple(Color(0xFFDCFCE7), Color(0xFF166534), "Audio Active (${diagnostics.audioBytesReceivedCount} bytes)")
                    DiagnosticStageStatus.CONNECTED_NO_MEDIA ->
                        Triple(Color(0xFFEAE5F8), Color(0xFF1D4ED8), "Connected (Waiting for Audio)")
                    else ->
                        Triple(Color(0xFFFEF3C7), Color(0xFFB45309), diagnostics.overallStatus.displayLabel)
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = statusBg
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(6.dp).background(statusFg, CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = statusLabel,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusFg
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = deviceName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = Color(0xFF1E293B)
                )

                Spacer(modifier = Modifier.height(32.dp))
                OneWayAudioIllustration(isAudioMuted = isAudioMuted)

                Spacer(modifier = Modifier.height(36.dp))
                Text(
                    text = formattedTime,
                    fontWeight = FontWeight.Bold,
                    fontSize = 40.sp,
                    color = Color(0xFF1E293B),
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Speaker Volume Slider
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.VolumeDown, contentDescription = null, tint = Color(0xFF716B7D), modifier = Modifier.size(20.dp))
                    Slider(
                        value = audioVolume,
                        onValueChange = {
                            audioVolume = it
                            audioPlayer.setVolume(it)
                        },
                        valueRange = 0f..1f,
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF7968C4), activeTrackColor = Color(0xFF7968C4))
                    )
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF716B7D), modifier = Modifier.size(20.dp))
                }

                Spacer(modifier = Modifier.weight(1f))

                // Concentric Mute / Unmute Button
                ConcentricAudioButton(
                    isMuted = isAudioMuted,
                    onClick = {
                        isAudioMuted = !isAudioMuted
                        audioPlayer.setMuted(isAudioMuted)
                        Toast.makeText(
                            context,
                            if (isAudioMuted) "Microphone stream muted" else "Microphone stream unmuted",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isAudioMuted) "Tap to Unmute Speaker" else "Tap to Mute Speaker",
                    fontSize = 12.sp,
                    color = Color(0xFF716B7D)
                )
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
        return
    }

    // Remote Camera & Screen Mirroring Connected Screen
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = when (currentType) {
                                "CAMERA" -> "Remote Camera"
                                "ACCESSIBILITY_SCREENSHOT" -> "Accessibility View"
                                "ONE_WAY_AUDIO" -> "One-Way Audio"
                                else -> "Screen Mirroring"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(deviceName, fontSize = 12.sp, color = Color.Gray)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showDiagnosticModal = true }) {
                        Icon(Icons.Outlined.Analytics, contentDescription = "Diagnostics", tint = Color(0xFF7968C4))
                    }

                    val isReceiving = if (currentType == "ACCESSIBILITY_SCREENSHOT") {
                        childSnapshot != null
                    } else diagnostics.videoFramesReceivedCount > 0
                    val badgeColor = if (isReceiving) Color(0xFFD1FAE5) else Color(0xFFFEF3C7)
                    val badgeText = when {
                        !isReceiving -> "Awaiting Frames"
                        currentType == "ACCESSIBILITY_SCREENSHOT" -> "LIVE SCREENSHOTS"
                        else -> "LIVE (${diagnostics.videoFramesReceivedCount} frames)"
                    }
                    val textColor = if (isReceiving) Color(0xFF047857) else Color(0xFFB45309)

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = badgeColor,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(modifier = Modifier.size(6.dp).background(textColor, CircleShape))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(badgeText, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = textColor)
                        }
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF1F5F9))
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mode Switcher Chips
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = currentType == "ONE_WAY_AUDIO",
                        onClick = { currentType = "ONE_WAY_AUDIO" },
                        label = { Text("Microphone", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF7968C4),
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = currentType == "CAMERA",
                        onClick = { currentType = "CAMERA" },
                        label = { Text("Camera", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF7968C4),
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = currentType == "SCREEN_MIRROR",
                        onClick = { currentType = "SCREEN_MIRROR" },
                        label = { Text("Screen Mirror", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF7968C4),
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = currentType == "ACCESSIBILITY_SCREENSHOT",
                        onClick = { currentType = "ACCESSIBILITY_SCREENSHOT" },
                        label = { Text("Accessibility View", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF7968C4),
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            item {
                Text(
                    if (currentType == "ACCESSIBILITY_SCREENSHOT") {
                        "Live screenshots use the Accessibility service enabled on the child phone. Select another mode to end this stream."
                    } else {
                        "Choose a live connection mode. Screen Mirror requires the child to approve Android's screen-capture prompt."
                    },
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }

            item {
                Text(
                    if (currentType == "SCREEN_MIRROR") {
                        "The child device must accept Android's screen-capture prompt before its live screen is shown here."
                    } else if (currentType == "ACCESSIBILITY_SCREENSHOT") {
                        "Accessibility Screenshot uses the Accessibility service enabled on the child phone."
                    } else {
                        "Screen mirror uses Android's on-device capture confirmation each time it starts."
                    },
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }

            if (currentType == "ACCESSIBILITY_SCREENSHOT") {
                item {
                    if (snapshotError != null) {
                        Text(snapshotError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            }

            // Real Live Video Surface Viewport with genuine WebRTC SurfaceViewRenderer
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                ) {
                    Box(Modifier.fillMaxSize()) {
                        if (currentType == "ACCESSIBILITY_SCREENSHOT") {
                            childSnapshot?.let { frame ->
                                Image(
                                    bitmap = frame.asImageBitmap(),
                                    contentDescription = "Screenshot from child device",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )
                            } ?: Text(
                                    snapshotError ?: "Connect to start receiving live frames.",
                                    color = Color.White,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                        } else RemoteVideoSurface(
                            webRtcManager = signalingManager.webRtcManager,
                            diagnostics = diagnostics,
                            deviceName = deviceName
                        )
                        if (currentType == "CAMERA" || currentType == "SCREEN_MIRROR" ||
                            (currentType == "ACCESSIBILITY_SCREENSHOT" && childSnapshot != null)
                        ) {
                            IconButton(
                                onClick = {
                                    if (currentType == "ACCESSIBILITY_SCREENSHOT") {
                                        showFullscreenScreenshot = true
                                    } else {
                                        showFullscreenVideo = true
                                    }
                                },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(10.dp)
                                    .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                            ) {
                                Icon(Icons.Default.Fullscreen, contentDescription = "View stream full screen", tint = Color.White)
                            }
                        }
                    }
                }
            }

            // Stream Diagnostics & Telemetry Pill
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        if (diagnostics.overallStatus == DiagnosticStageStatus.RECEIVING_MEDIA) Color(0xFF10B981) else Color(0xFFF59E0B),
                                        CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ICE: ${diagnostics.iceConnectionState}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF334155)
                            )
                        }
                        Text(
                            text = if (diagnostics.videoFramesReceivedCount > 0)
                                "${diagnostics.videoFramesReceivedCount} frames decoded"
                            else
                                "Awaiting video stream",
                            fontSize = 11.sp,
                            color = Color(0xFF716B7D)
                        )
                        Text(
                            text = if (diagnostics.remoteAudioTrackReceived) "Audio Live" else "Audio Muted",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (diagnostics.remoteAudioTrackReceived) Color(0xFF059669) else Color(0xFF94A3B8)
                        )
                    }
                }
            }

            // Audio Listen-in Control (hear child device's microphone while watching live camera)
            if (currentType == "CAMERA") {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        if (isCameraAudioListening && !isAudioMuted) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                        contentDescription = null,
                                        tint = if (isCameraAudioListening && !isAudioMuted) Color(0xFF7968C4) else Color(0xFF94A3B8),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "Listen to Environment",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color(0xFF1E293B)
                                    )
                                }
                                Switch(
                                    checked = isCameraAudioListening && !isAudioMuted,
                                    onCheckedChange = { active ->
                                        isCameraAudioListening = active
                                        isAudioMuted = !active
                                        Toast.makeText(
                                            context,
                                            if (active) "Ambient audio stream listening enabled" else "Ambient audio listening paused",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFF7968C4)
                                    )
                                )
                            }

                            if (isCameraAudioListening && !isAudioMuted) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "Volume",
                                        fontSize = 12.sp,
                                        color = Color(0xFF716B7D),
                                        modifier = Modifier.width(50.dp)
                                    )
                                    Slider(
                                        value = audioVolume,
                                        onValueChange = { vol ->
                                            audioVolume = vol
                                        },
                                        valueRange = 0f..1f,
                                        modifier = Modifier.weight(1f),
                                        colors = SliderDefaults.colors(
                                            thumbColor = Color(0xFF7968C4),
                                            activeTrackColor = Color(0xFF7968C4)
                                        )
                                    )
                                    Text(
                                        "${(audioVolume * 100).toInt()}%",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF334155),
                                        modifier = Modifier.width(36.dp),
                                        textAlign = TextAlign.End
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (currentType == "ACCESSIBILITY_SCREENSHOT") {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        if (isAccessibilityAudioListening) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                        contentDescription = null,
                                        tint = if (isAccessibilityAudioListening) Color(0xFF7968C4) else Color(0xFF94A3B8),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("Listen to Environment", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                                    }
                                }
                                Switch(
                                    checked = isAccessibilityAudioListening,
                                    onCheckedChange = { active ->
                                        isAccessibilityAudioListening = active
                                        isAudioMuted = !active
                                        audioPlayer.setMuted(!active)
                                        signalingManager.webRtcManager.setAudioMuted(!active)
                                        signalingManager.sendControlCommand("SET_MICROPHONE", mapOf("enabled" to active))
                                        Toast.makeText(context, if (active) "Environment audio enabled" else "Environment audio paused", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF7968C4))
                                )
                            }
                            if (isAccessibilityAudioListening) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Volume", fontSize = 12.sp, color = Color(0xFF716B7D), modifier = Modifier.width(50.dp))
                                    Slider(
                                        value = audioVolume,
                                        onValueChange = { audioVolume = it; audioPlayer.setVolume(it) },
                                        valueRange = 0f..1f,
                                        modifier = Modifier.weight(1f),
                                        colors = SliderDefaults.colors(thumbColor = Color(0xFF7968C4), activeTrackColor = Color(0xFF7968C4))
                                    )
                                    Text("${(audioVolume * 100).toInt()}%", fontSize = 12.sp, color = Color(0xFF334155), modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
                                }
                            }
                        }
                    }
                }
            }

            // Remote Camera / Stream Controls
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Remote Supervisory Controls", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            TextButton(onClick = { showDiagnosticModal = true }) {
                                Icon(Icons.Outlined.Analytics, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Diagnostics >", fontSize = 12.sp, color = Color(0xFF7968C4))
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            if (currentType == "CAMERA") {
                                StreamActionButton(
                                    icon = Icons.Default.FlipCameraAndroid,
                                    label = if (isFrontCamera) "Front Cam" else "Rear Cam",
                                    onClick = {
                                        isFrontCamera = !isFrontCamera
                                        signalingManager.flipChildCamera(isFrontCamera)
                                        Toast.makeText(
                                            context,
                                            if (isFrontCamera) "Signaled child: switch to Front Camera" else "Signaled child: switch to Rear Camera",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                )
                                StreamActionButton(
                                    icon = Icons.Default.FlashOn,
                                    label = "Flashlight ON",
                                    onClick = {
                                        isFlashlightOn = true
                                        signalingManager.toggleChildFlash(true)
                                        Toast.makeText(
                                            context,
                                            "Signaled child: Flashlight ON",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                )
                                StreamActionButton(
                                    icon = Icons.Default.FlashOff,
                                    label = "Flashlight OFF",
                                    onClick = {
                                        isFlashlightOn = false
                                        signalingManager.toggleChildFlash(false)
                                        Toast.makeText(context, "Signaled child: Flashlight OFF", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            } else {
                                StreamActionButton(
                                    icon = Icons.Default.Lock,
                                    label = "Lock Screen",
                                    onClick = {
                                        coroutineScope.launch {
                                            repository.toggleDeviceLock(deviceId, true)
                                            Toast.makeText(context, "Sent lock command to $deviceName", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectingDeviceIllustration() {
    val infiniteTransition = rememberInfiniteTransition(label = "connecting_dots")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    Box(
        modifier = Modifier.size(160.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            drawCircle(
                color = Color(0xFFF1EDFA),
                radius = w * 0.46f,
                center = Offset(w * 0.5f, h * 0.5f)
            )

            val phoneRect = Path().apply {
                addRoundRect(
                    androidx.compose.ui.geometry.RoundRect(
                        left = w * 0.32f,
                        top = h * 0.22f,
                        right = w * 0.68f,
                        bottom = h * 0.78f,
                        cornerRadius = CornerRadius(22.dp.toPx(), 22.dp.toPx())
                    )
                )
            }
            drawPath(phoneRect, color = Color(0xFF8D7BD0))

            val screenRect = Path().apply {
                addRoundRect(
                    androidx.compose.ui.geometry.RoundRect(
                        left = w * 0.36f,
                        top = h * 0.26f,
                        right = w * 0.64f,
                        bottom = h * 0.74f,
                        cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx())
                    )
                )
            }
            drawPath(screenRect, color = Color(0xFF7968C4))
        }

        Box(
            modifier = Modifier
                .size(46.dp)
                .rotate(rotation),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val numDots = 8
                val radius = size.width * 0.38f
                val cx = size.width / 2f
                val cy = size.height / 2f
                for (i in 0 until numDots) {
                    val angle = (i * (360f / numDots)) * (PI / 180f)
                    val dx = cx + (radius * cos(angle)).toFloat()
                    val dy = cy + (radius * sin(angle)).toFloat()
                    val dotAlpha = 0.3f + 0.7f * (i.toFloat() / numDots)
                    drawCircle(
                        color = Color.White.copy(alpha = dotAlpha),
                        radius = 2.8.dp.toPx(),
                        center = Offset(dx, dy)
                    )
                }
            }
        }
    }
}

@Composable
private fun OneWayAudioIllustration(isAudioMuted: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "audio_bars")
    val waveFactor by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bars"
    )

    Box(
        modifier = Modifier.size(240.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f

            drawCircle(color = Color(0xFFF3F7FF), radius = w * 0.48f, center = Offset(cx, cy))
            drawCircle(color = Color(0xFFF1EDFA), radius = w * 0.44f, center = Offset(cx, cy))
            drawCircle(
                color = Color(0xFFE0EDFF),
                radius = w * 0.38f,
                center = Offset(cx, cy),
                style = Stroke(width = 1.5.dp.toPx())
            )

            if (!isAudioMuted) {
                val barCount = 7
                val barWidth = 4.dp.toPx()
                val totalWidth = 40.dp.toPx()
                val startX = cx - (totalWidth / 2f)
                val spacing = (totalWidth - (barCount * barWidth)) / (barCount - 1)
                val heights = listOf(14f, 22f, 32f, 40f, 30f, 18f, 12f)
                for (i in 0 until barCount) {
                    val baseH = heights[i]
                    val dynamicH = (baseH * (0.6f + 0.5f * sin((i + waveFactor * 4) * 1.2).toFloat().coerceAtLeast(0f))).dp.toPx()
                    drawRoundRect(
                        color = Color(0xFF60A5FA),
                        topLeft = Offset(startX + i * (barWidth + spacing), cy - (dynamicH / 2f)),
                        size = Size(barWidth, dynamicH),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )
                }
            } else {
                drawLine(
                    color = Color(0xFFCBD5E1),
                    start = Offset(cx - 18.dp.toPx(), cy),
                    end = Offset(cx + 18.dp.toPx(), cy),
                    strokeWidth = 3.dp.toPx()
                )
            }

            val headbandPath = Path().apply {
                moveTo(cx - 52.dp.toPx(), cy + 6.dp.toPx())
                cubicTo(
                    cx - 52.dp.toPx(), cy - 62.dp.toPx(),
                    cx + 52.dp.toPx(), cy - 62.dp.toPx(),
                    cx + 52.dp.toPx(), cy + 6.dp.toPx()
                )
            }
            drawPath(headbandPath, color = Color(0xFF8D7BD0), style = Stroke(width = 12.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))

            val leftEarcupCenter = Offset(cx - 52.dp.toPx(), cy + 6.dp.toPx())
            drawRoundRect(
                color = Color(0xFF4ADE80),
                topLeft = Offset(leftEarcupCenter.x - 12.dp.toPx(), leftEarcupCenter.y - 20.dp.toPx()),
                size = Size(24.dp.toPx(), 40.dp.toPx()),
                cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
            )
            drawRoundRect(
                color = Color(0xFF16A34A),
                topLeft = Offset(leftEarcupCenter.x - 5.dp.toPx(), leftEarcupCenter.y - 12.dp.toPx()),
                size = Size(10.dp.toPx(), 24.dp.toPx()),
                cornerRadius = CornerRadius(5.dp.toPx(), 5.dp.toPx())
            )

            val rightEarcupCenter = Offset(cx + 52.dp.toPx(), cy + 6.dp.toPx())
            drawRoundRect(
                color = Color(0xFF4ADE80),
                topLeft = Offset(rightEarcupCenter.x - 12.dp.toPx(), rightEarcupCenter.y - 20.dp.toPx()),
                size = Size(24.dp.toPx(), 40.dp.toPx()),
                cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
            )
            drawRoundRect(
                color = Color(0xFF16A34A),
                topLeft = Offset(rightEarcupCenter.x - 5.dp.toPx(), rightEarcupCenter.y - 12.dp.toPx()),
                size = Size(10.dp.toPx(), 24.dp.toPx()),
                cornerRadius = CornerRadius(5.dp.toPx(), 5.dp.toPx())
            )
        }
    }
}

@Composable
private fun ConcentricAudioButton(
    isMuted: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = CircleShape,
            color = Color.Transparent,
            border = androidx.compose.foundation.BorderStroke(3.dp, Color(0xFFEAE5F8)),
            modifier = Modifier.size(72.dp)
        ) {}

        Surface(
            shape = CircleShape,
            color = if (isMuted) Color(0xFF94A3B8) else Color(0xFF7968C4),
            shadowElevation = 4.dp,
            modifier = Modifier.size(42.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    if (isMuted) Icons.Default.MicOff else Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun StreamActionButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Surface(
            shape = CircleShape,
            color = Color(0xFFF1F5F9),
            modifier = Modifier.size(48.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = Color(0xFF1E293B), modifier = Modifier.size(22.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, color = Color(0xFF475569))
    }
}
