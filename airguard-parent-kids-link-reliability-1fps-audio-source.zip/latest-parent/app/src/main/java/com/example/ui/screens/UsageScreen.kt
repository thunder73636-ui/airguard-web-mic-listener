package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppRule
import com.example.data.repository.ParentRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsageScreen(
    deviceId: String,
    repository: ParentRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val device by repository.observeDeviceById(deviceId).collectAsState(initial = null)
    val appRules by repository.observeAppRules(deviceId).collectAsState(initial = emptyList())
    val todayAppUsage by repository.observeTodayAppUsage(deviceId).collectAsState(initial = emptyMap())

    fun submitCloudAction(successMessage: String, action: suspend () -> Unit) {
        coroutineScope.launch {
            try {
                action()
                Toast.makeText(context, successMessage, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, e.message ?: "Could not send command to child device", Toast.LENGTH_LONG).show()
            }
        }
    }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Daily Limit, 1: Downtime, 2: Apps
    var limitMinutes by remember(device?.screenTimeLimitMinutes) {
        mutableFloatStateOf((device?.screenTimeLimitMinutes ?: 180).toFloat())
    }
    var limitInput by remember(device?.screenTimeLimitMinutes) {
        mutableStateOf((device?.screenTimeLimitMinutes ?: 180).toString())
    }
    var downtimeEnabled by remember(device?.downtimeEnabled) {
        mutableStateOf(device?.downtimeEnabled ?: false)
    }
    var startHour by remember(device?.downtimeStartHour) {
        mutableIntStateOf(device?.downtimeStartHour ?: 21)
    }
    var startMinute by remember(device?.downtimeStartMinute) {
        mutableIntStateOf(device?.downtimeStartMinute ?: 30)
    }
    var endHour by remember(device?.downtimeEndHour) {
        mutableIntStateOf(device?.downtimeEndHour ?: 7)
    }
    var endMinute by remember(device?.downtimeEndMinute) {
        mutableIntStateOf(device?.downtimeEndMinute ?: 0)
    }
    var selectedDays by remember(device?.downtimeDays) {
        mutableStateOf(
            (device?.downtimeDays ?: "Mon,Tue,Wed,Thu,Sun").split(",").toSet()
        )
    }

    val currentDevice = device
    val appUsageAvailable = currentDevice?.hasUsageStatsPermission == true
    val usageRules = remember(appRules, todayAppUsage, appUsageAvailable) {
        appRules.map { rule ->
            rule.copy(todayUsageMinutes = if (appUsageAvailable) {
                todayAppUsage[rule.packageName] ?: if (todayAppUsage.isEmpty()) rule.todayUsageMinutes else 0
            } else rule.todayUsageMinutes)
        }.sortedByDescending { it.todayUsageMinutes }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Screen Time & Limits", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(currentDevice?.deviceName ?: "Child Device", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(AirBackground)
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = AirBluePrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Daily Limit", fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Downtime", fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("App Usage (${appRules.size})", fontWeight = FontWeight.SemiBold) }
                )
            }

            when (selectedTab) {
                0 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("Child's screen time today", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Spacer(Modifier.height(6.dp))
                                    val used = currentDevice?.todayUsageMinutes ?: 0
                                    Text("${used / 60}h ${used % 60}m used", fontWeight = FontWeight.Bold, fontSize = 24.sp, color = AirBluePrimary)
                                    Text(
                                        if (currentDevice?.hasUsageStatsPermission == true) "Updates about every 45 seconds while the child device is connected."
                                        else "Usage Access is off on the child device, so screen time cannot update yet.",
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = CircleShape,
                                            color = if (currentDevice?.isLocked == true) AirOfflineRed.copy(alpha = 0.15f) else AirBluePrimary.copy(alpha = 0.15f),
                                            modifier = Modifier.size(40.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    if (currentDevice?.isLocked == true) Icons.Default.Lock else Icons.Default.LockOpen,
                                                    contentDescription = null,
                                                    tint = if (currentDevice?.isLocked == true) AirOfflineRed else AirBluePrimary
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text("Pause App Access", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            Text(
                                                if (currentDevice?.isLocked == true) "AirGuard restrictions are active; Android system settings and emergency calls remain available" else "Pause child app access with a visible AirGuard restriction screen",
                                                fontSize = 12.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = currentDevice?.isLocked ?: false,
                                        onCheckedChange = { locked ->
                                            submitCloudAction(if (locked) "Instant block sent to child device" else "Unlock sent to child device") {
                                                repository.toggleDeviceLock(deviceId, locked)
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Text("Daily Allowance", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Limit how much total screen time the device can use each day.",
                                        fontSize = 13.sp,
                                        color = Color.Gray
                                    )
                                    Spacer(modifier = Modifier.height(24.dp))
                                    val hours = limitMinutes.toInt() / 60
                                    val mins = limitMinutes.toInt() % 60
                                    Text(
                                        text = "${limitMinutes.toInt()} Minutes ($hours hrs $mins mins)",
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AirBluePrimary
                                    )
                                    OutlinedTextField(
                                        value = limitInput,
                                        onValueChange = { value ->
                                            if (value.isEmpty() || value.all(Char::isDigit)) {
                                                limitInput = value
                                                value.toIntOrNull()?.let { limitMinutes = it.coerceIn(1, 1_440).toFloat() }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Daily limit in minutes") },
                                        supportingText = { Text("Choose any whole-minute limit from 1 to 1,440 (24 hours).") },
                                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Slider(
                                        value = limitMinutes,
                                        onValueChange = { limitMinutes = it; limitInput = it.toInt().toString() },
                                        valueRange = 1f..1_440f,
                                        steps = 1_438,
                                        colors = SliderDefaults.colors(thumbColor = AirBluePrimary, activeTrackColor = AirBluePrimary)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("1m", fontSize = 11.sp, color = Color.Gray)
                                        Text("3 hrs (Recommended)", fontSize = 11.sp, color = Color.Gray)
                                        Text("24 hrs", fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Spacer(modifier = Modifier.height(24.dp))
                                    Button(
                                        onClick = {
                                            submitCloudAction("Daily limit saved and synced with child phone") {
                                                val chosenLimit = limitInput.toIntOrNull()?.coerceIn(1, 1_440)
                                                    ?: throw IllegalArgumentException("Enter a daily limit from 1 to 1,440 minutes")
                                                repository.updateScreenTimeLimit(deviceId, chosenLimit)
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().height(48.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = AirBluePrimary),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("Save Daily Limit", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = AirBluePrimary)
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text("Downtime Schedule", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                                Text("Lock down device during bedtime or study hours", fontSize = 12.sp, color = Color.Gray)
                                            }
                                        }
                                        Switch(
                                            checked = downtimeEnabled,
                                            onCheckedChange = { downtimeEnabled = it }
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(20.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        TimeCard(
                                            label = "Bedtime Start",
                                            timeString = "%02d:%02d".format(startHour, startMinute),
                                            modifier = Modifier.weight(1f),
                                            onAdjust = {
                                                startHour = (startHour + 1) % 24
                                            }
                                        )
                                        TimeCard(
                                            label = "Wake-up End",
                                            timeString = "%02d:%02d".format(endHour, endMinute),
                                            modifier = Modifier.weight(1f),
                                            onAdjust = {
                                                endHour = (endHour + 1) % 24
                                            }
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(20.dp))
                                    Text("Active Days", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        days.forEach { day ->
                                            val isSelected = selectedDays.contains(day)
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = {
                                                    selectedDays = if (isSelected) {
                                                        if (selectedDays.size > 1) selectedDays - day else selectedDays
                                                    } else {
                                                        selectedDays + day
                                                    }
                                                },
                                                label = { Text(day, fontSize = 11.sp) },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = AirBluePrimary,
                                                    selectedLabelColor = Color.White
                                                )
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(24.dp))
                                    Button(
                                        onClick = {
                                            submitCloudAction("Downtime schedule saved and synced") {
                                                repository.updateDowntime(
                                                    deviceId = deviceId,
                                                    enabled = downtimeEnabled,
                                                    startHour = startHour,
                                                    startMinute = startMinute,
                                                    endHour = endHour,
                                                    endMinute = endMinute,
                                                    days = selectedDays.joinToString(",")
                                                )
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().height(48.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = AirBluePrimary),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("Save Downtime Schedule", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1EDFA)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = AirBluePrimary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        when {
                                            currentDevice?.hasAccessibilityPermission != true -> "App blocks are not active yet. Enable AirGuard Accessibility on the child phone; Android shows a visible restriction screen when a blocked app opens."
                                            currentDevice?.hasUsageStatsPermission != true -> "App blocking is active. Per-app and daily usage counts need Usage Access on the child phone."
                                            appRules.isEmpty() -> "Waiting for the child phone to sync its installed app list."
                                            appUsageAvailable -> "Today’s per-app foreground time refreshes while the child phone is connected."
                                            else -> "App rules are available, but usage durations need Usage Access on the child phone."
                                        },
                                        fontSize = 12.sp,
                                        color = AirBlueDark
                                    )
                                }
                            }
                        }
                        if (appRules.isEmpty()) {
                            item { Text("No installed apps have synced yet.", color = Color.Gray, fontSize = 13.sp) }
                        }
                        items(usageRules, key = { it.id }) { rule ->
                            AppRuleCard(
                                rule = rule,
                                usageAvailable = appUsageAvailable,
                                onToggleBlock = { blocked ->
                                    submitCloudAction("${rule.appName} ${if (blocked) "block" else "unblock"} sent to child") {
                                        repository.toggleAppBlock(rule.id, blocked)
                                    }
                                },
                                onUpdateLimit = { minutes ->
                                    submitCloudAction("${rule.appName} app limit saved") {
                                        repository.updateAppLimit(rule.id, minutes)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeCard(
    label: String,
    timeString: String,
    modifier: Modifier = Modifier,
    onAdjust: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onAdjust() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8FC)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 11.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(4.dp))
            Text(timeString, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AirBluePrimary)
            Spacer(modifier = Modifier.height(2.dp))
            Text("Tap to adjust hour", fontSize = 10.sp, color = Color.LightGray)
        }
    }
}

@Composable
private fun AppRuleCard(
    rule: AppRule,
    usageAvailable: Boolean,
    onToggleBlock: (Boolean) -> Unit,
    onUpdateLimit: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AirBluePrimary.copy(alpha = 0.12f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Apps, contentDescription = null, tint = AirBluePrimary)
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(rule.appName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            if (usageAvailable) "${rule.category}   Used ${rule.todayUsageMinutes}m today"
                            else "${rule.category}   Usage Access off",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (rule.isBlocked) "Blocked" else "Allowed",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (rule.isBlocked) AirOfflineRed else AirOnlineGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = rule.isBlocked,
                        onCheckedChange = onToggleBlock
                    )
                }
            }

            if (!rule.isBlocked) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (rule.dailyLimitMinutes > 0) "Daily Limit: ${rule.dailyLimitMinutes}m" else "Daily Limit: Unlimited",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Row {
                        TextButton(onClick = { onUpdateLimit((rule.dailyLimitMinutes - 15).coerceAtLeast(0)) }) {
                            Text("-15m", fontSize = 12.sp)
                        }
                        TextButton(onClick = { onUpdateLimit((rule.dailyLimitMinutes + 15).coerceAtLeast(15).coerceAtMost(360)) }) {
                            Text("+15m", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
