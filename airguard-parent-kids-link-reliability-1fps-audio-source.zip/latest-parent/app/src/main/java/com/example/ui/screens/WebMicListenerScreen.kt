package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.example.data.repository.ParentRepository
import com.example.media.WebRTCManager
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription
import java.util.UUID

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun WebMicListenerScreen(repository: ParentRepository, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var code by remember { mutableStateOf("") }
    var state by remember { mutableStateOf("Enter the code shown on the microphone website.") }
    var listening by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val firestore = remember { repository.getFirestore() }
    val manager = remember { WebRTCManager(context) }
    var documentListener by remember { mutableStateOf<ListenerRegistration?>(null) }
    var candidateListener by remember { mutableStateOf<ListenerRegistration?>(null) }
    var handledOffer by remember { mutableStateOf(false) }
    val seenCandidates = remember { mutableSetOf<String>() }

    fun stop() {
        documentListener?.remove(); documentListener = null
        candidateListener?.remove(); candidateListener = null
        manager.onLocalIceCandidate = null
        manager.close()
        listening = false; handledOffer = false; seenCandidates.clear()
    }

    fun connect() {
        val sessionId = code.trim().lowercase()
        if (!Regex("^[a-f0-9]{32}$").matches(sessionId)) { state = "Enter a valid 32-character code."; return }
        val db = firestore
        if (db == null) { state = "AirGuard Firebase is unavailable. Sign in and try again."; return }
        stop()
        if (!manager.startSession("ONE_WAY_AUDIO")) { state = "Could not initialize audio listener."; return }
        listening = true; state = "Waiting for the website microphone…"
        val session = db.collection("web_audio_sessions").document(sessionId)
        manager.onLocalIceCandidate = { ice ->
            val id = UUID.randomUUID().toString().replace("-", "")
            session.collection("receiver_candidates").document(id).set(mapOf(
                "candidate" to JSONObject().put("candidate", ice.sdp).put("sdpMid", ice.sdpMid ?: "").put("sdpMLineIndex", ice.sdpMLineIndex).toString()
            ))
        }
        documentListener = session.addSnapshotListener { snapshot, error ->
            if (error != null) { state = error.message ?: "Signaling connection failed."; return@addSnapshotListener }
            val offer = snapshot?.getString("offer").orEmpty()
            if (offer.isNotBlank() && !handledOffer) {
                handledOffer = true
                manager.createAnswerForRemoteOffer(offer) { answer ->
                    session.update("answer", answer.description, "status", "answered")
                    state = "Connected. Live audio is playing through this device."
                }
            }
        }
        candidateListener = session.collection("sender_candidates").addSnapshotListener { snapshot, _ ->
            snapshot?.documents?.forEach { doc ->
                if (seenCandidates.add(doc.id)) {
                    runCatching {
                        val item = JSONObject(doc.getString("candidate") ?: "{}")
                        manager.addRemoteIceCandidate(IceCandidate(item.optString("sdpMid"), item.optInt("sdpMLineIndex"), item.optString("candidate")))
                    }
                }
            }
        }
        scope.launch {
            try {
                val snapshot = session.get().await()
                if (!snapshot.exists()) { state = "Session not found. Check the code and try again."; stop() }
            } catch (e: Exception) { state = e.message ?: "Could not open session."; stop() }
        }
    }

    DisposableEffect(Unit) { onDispose { stop(); manager.close() } }
    Scaffold(topBar = { TopAppBar(title = { Text("Website mic listener") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Default.Headphones, null, modifier = Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(20.dp))
            Text("Listen to website microphone", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Start the mic on the website, then enter its session code here.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(value = code, onValueChange = { code = it.filter(Char::isLetterOrDigit).take(32).lowercase() }, label = { Text("Session code") }, singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None), enabled = !listening, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(14.dp))
            Button(onClick = { if (listening) stop() else connect() }, modifier = Modifier.fillMaxWidth()) { Text(if (listening) "Stop listening" else "Connect") }
            Spacer(Modifier.height(18.dp))
            Text(state, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
