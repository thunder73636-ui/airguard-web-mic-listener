package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// AirGuard Theme Colors
val AirBluePrimary = Color(0xFF7968C4)
val AirBlueGradientEnd = Color(0xFFAA91DF)
val AirBlueDark = Color(0xFF514776)
val AirBackground = Color(0xFFFFF8FC)
val AirCardBackground = Color(0xFFFFFFFF)
val AirProPurple = Color(0xFFD979A2)
val AirProPurpleBg = Color(0xFFFFE8F1)
val AirOnlineGreen = Color(0xFF58A878)
val AirWarningAmber = Color(0xFFD99B3D)
val AirOfflineRed = Color(0xFFD97878)
val AirTextPrimary = Color(0xFF302A3B)
val AirTextSecondary = Color(0xFF716B7D)
val AirDivider = Color(0xFFF0E5EF)
