package com.example.util

import java.security.SecureRandom

object CryptoUtils {
    private val secureRandom = SecureRandom()

    /**
     * Generates a cryptographically secure 9-digit pairing code
     * formatted as three 3-digit groups (e.g., "492 817 305").
     */
    fun generateSecurePairingCode(): String {
        val part1 = 100 + secureRandom.nextInt(900)
        val part2 = 100 + secureRandom.nextInt(900)
        val part3 = 100 + secureRandom.nextInt(900)
        return "$part1 $part2 $part3"
    }

    /**
     * Builds the pairing payload URL that child devices scan or open.
     */
    fun buildPairingPayload(code: String, deviceName: String): String {
        val cleanCode = code.replace(" ", "")
        val timestamp = System.currentTimeMillis()
        return "https://apps.airdroid.com/kids?pairCode=$cleanCode&device=${deviceName.replace(" ", "%20")}&ts=$timestamp"
    }
}
