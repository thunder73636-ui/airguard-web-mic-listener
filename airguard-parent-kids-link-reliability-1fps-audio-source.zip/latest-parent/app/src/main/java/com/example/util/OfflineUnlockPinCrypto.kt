package com.example.util

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Shared Parent/Kids format for a salted verifier; the raw PIN is never uploaded. */
object OfflineUnlockPinCrypto {
    const val ITERATIONS = 120_000
    private const val KEY_BITS = 256
    private val random = SecureRandom()

    fun newSalt(): String = ByteArray(16).also(random::nextBytes).let {
        Base64.encodeToString(it, Base64.NO_WRAP)
    }

    fun derive(pin: String, salt: String): String {
        val saltBytes = Base64.decode(salt, Base64.NO_WRAP)
        val spec = PBEKeySpec(pin.toCharArray(), saltBytes, ITERATIONS, KEY_BITS)
        return try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
                .generateSecret(spec).encoded
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } finally {
            spec.clearPassword()
        }
    }

    fun matches(pin: String, salt: String, expectedHash: String): Boolean = try {
        MessageDigest.isEqual(
            Base64.decode(derive(pin, salt), Base64.NO_WRAP),
            Base64.decode(expectedHash, Base64.NO_WRAP)
        )
    } catch (_: Exception) {
        false
    }
}
