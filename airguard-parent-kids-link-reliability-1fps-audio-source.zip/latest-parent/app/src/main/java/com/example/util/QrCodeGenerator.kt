package com.example.util

object QrCodeGenerator {
    const val MATRIX_SIZE = 29

    fun generateMatrix(data: String): Array<BooleanArray> {
        val matrix = Array(MATRIX_SIZE) { BooleanArray(MATRIX_SIZE) }
        val reserved = Array(MATRIX_SIZE) { BooleanArray(MATRIX_SIZE) }

        // 1. Finder Patterns (7x7 at top-left, top-right, bottom-left)
        fun placeFinder(startX: Int, startY: Int) {
            for (y in 0 until 7) {
                for (x in 0 until 7) {
                    val isBorder = x == 0 || x == 6 || y == 0 || y == 6
                    val isCenter = x in 2..4 && y in 2..4
                    matrix[startY + y][startX + x] = isBorder || isCenter
                    reserved[startY + y][startX + x] = true
                }
            }
            // Separators
            for (y in -1..7) {
                for (x in -1..7) {
                    val px = startX + x
                    val py = startY + y
                    if (px in 0 until MATRIX_SIZE && py in 0 until MATRIX_SIZE) {
                        reserved[py][px] = true
                        if (x == -1 || x == 7 || y == -1 || y == 7) {
                            matrix[py][px] = false
                        }
                    }
                }
            }
        }

        placeFinder(0, 0)
        placeFinder(MATRIX_SIZE - 7, 0)
        placeFinder(0, MATRIX_SIZE - 7)

        // 2. Alignment pattern (at 22, 22 for Version 3)
        fun placeAlignment(cx: Int, cy: Int) {
            for (y in -2..2) {
                for (x in -2..2) {
                    val isEdge = kotlin.math.abs(x) == 2 || kotlin.math.abs(y) == 2
                    val isCenter = x == 0 && y == 0
                    val px = cx + x
                    val py = cy + y
                    if (px in 0 until MATRIX_SIZE && py in 0 until MATRIX_SIZE) {
                        matrix[py][px] = isEdge || isCenter
                        reserved[py][px] = true
                    }
                }
            }
        }
        placeAlignment(22, 22)

        // 3. Timing patterns (Row 6, Col 6)
        for (i in 8 until MATRIX_SIZE - 8) {
            val bit = (i % 2 == 0)
            if (!reserved[6][i]) {
                matrix[6][i] = bit
                reserved[6][i] = true
            }
            if (!reserved[i][6]) {
                matrix[i][6] = bit
                reserved[i][6] = true
            }
        }

        // 4. Dark module
        matrix[MATRIX_SIZE - 8][8] = true
        reserved[MATRIX_SIZE - 8][8] = true

        // 5. Fill remaining data bits with hash-derived pseudo bitstream
        val hash = data.toByteArray().fold(0L) { acc, b -> (acc * 31 + (b.toInt() and 0xFF)) }
        var bitIndex = 0

        // Traverse 2-column paths from right to left
        var x = MATRIX_SIZE - 1
        while (x > 0) {
            if (x == 6) x-- // Skip vertical timing pattern
            val col1 = x
            val col2 = x - 1
            val upward = ((col1 + 1) / 2) % 2 == 1
            val yRange = if (upward) (MATRIX_SIZE - 1 downTo 0) else (0 until MATRIX_SIZE)

            for (y in yRange) {
                for (cx in listOf(col1, col2)) {
                    if (!reserved[y][cx]) {
                        val pseudoBit = ((hash shr (bitIndex % 60)) and 1L) == 1L
                        val mask = ((cx + y) % 2 == 0)
                        matrix[y][cx] = pseudoBit xor mask
                        bitIndex++
                    }
                }
            }
            x -= 2
        }

        return matrix
    }
}
