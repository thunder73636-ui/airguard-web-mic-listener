package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.Device
import com.example.data.model.ParentAccount
import com.example.data.repository.AuthUiState
import com.example.data.repository.AuthRepository
import com.example.data.repository.UserProfile
import com.example.data.repository.devicesVisibleToParent
import com.example.data.repository.ParentRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DevicePairingAndTelemetryRobolectricTest {

    private lateinit var context: Context
    private lateinit var repository: ParentRepository
    private lateinit var db: AppDatabase

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = AppDatabase.getInstance(context)
        repository = ParentRepository(context)
    }

    @Test
    fun testInitialStateHasNoDevices() = runBlocking {
        db.deviceDao().deleteAllDevices()
        val devices = repository.observeDevices().first()
        assertTrue("Device list should start empty when no devices are paired", devices.isEmpty())
    }

    @Test
    fun testGeneratePairingSession() = runBlocking {
        val session = repository.generatePairingSession("Vivo I2208")
        assertNotNull(session)
        assertEquals("WAITING", session.status)
        assertEquals("Pairing code must have 3 segments", 3, session.code.split(" ").size)
        assertTrue("QR payload must include pair URL", session.qrPayload.contains("airdroid.com/kids"))
    }

    @Test
    fun testPairingUsesPersistedParentUidWhenFirebaseAuthIsNotReady() = runBlocking {
        db.parentAccountDao().saveAccount(
            ParentAccount(firebaseUid = "persisted-parent-uid", isLoggedIn = true)
        )

        val authRepository = AuthRepository(context)
        assertEquals("persisted-parent-uid", authRepository.getResolvedUid())
    }

    @Test
    fun testUnauthenticatedLocalPairingDeviceStillAppearsInDeviceList() {
        val localPair = Device(id = "local-pair", deviceName = "Child", parentUid = "parent_user")
        val otherAccountDevice = Device(id = "other", deviceName = "Other", parentUid = "another-parent")

        val visible = devicesVisibleToParent(
            listOf(localPair, otherAccountDevice),
            AuthUiState.Unauthenticated()
        )

        assertEquals(listOf("local-pair"), visible.map { it.id })
    }

    @Test
    fun testAuthenticatedDeviceListDoesNotShowOtherAccounts() {
        val own = Device(id = "own", parentUid = "parent-a")
        val other = Device(id = "other", parentUid = "parent-b")
        assertEquals(
            listOf("own"),
            devicesVisibleToParent(listOf(own, other), AuthUiState.Authenticated(UserProfile("parent-a", "", ""))).map { it.id }
        )
    }

    @Test
    fun testToggleDeviceLockDoesNotPretendToSucceedWithoutFirebase() = runBlocking {
        val device = Device(
            id = "test_dev_lock",
            deviceName = "Test Phone",
            isLocked = false
        )
        db.deviceDao().insertOrUpdate(device)

        val result = runCatching { repository.toggleDeviceLock("test_dev_lock", true) }
        val updated = db.deviceDao().getDeviceById("test_dev_lock")
        assertTrue("Cloud lock command must fail clearly when Firebase is unavailable", result.isFailure)
        assertNotNull(updated)
        assertFalse("Local state must not claim a command succeeded when cloud write failed", updated!!.isLocked)
    }

    @Test
    fun testUpdateScreenTimeLimitDoesNotPretendToSucceedWithoutFirebase() = runBlocking {
        val device = Device(
            id = "test_dev_limit",
            deviceName = "Test Phone",
            screenTimeLimitMinutes = 120
        )
        db.deviceDao().insertOrUpdate(device)

        val result = runCatching { repository.updateScreenTimeLimit("test_dev_limit", 240) }
        val updated = db.deviceDao().getDeviceById("test_dev_limit")
        assertTrue("Cloud screen-time command must fail clearly when Firebase is unavailable", result.isFailure)
        assertNotNull(updated)
        assertEquals("Local limit must stay unchanged after a failed cloud write", 120, updated!!.screenTimeLimitMinutes)
    }

    @Test
    fun testRemoteFeatureRequestDispatch() = runBlocking {
        val request = repository.dispatchRemoteFeatureRequest("test_dev_remote", "CAMERA")
        assertEquals("CAMERA", request.type)
        assertEquals("test_dev_remote", request.deviceId)
        assertEquals("PENDING_CONSENT", request.status)
    }

    @Test
    fun testDeviceOfflineDetection() {
        val now = System.currentTimeMillis()
        val onlineDevice = Device(
            id = "d1",
            deviceName = "Online Device",
            isOnline = true,
            lastSeenTimestamp = now - 30_000 // 30 sec ago
        )
        val offlineDevice = Device(
            id = "d2",
            deviceName = "Offline Device",
            isOnline = false,
            lastSeenTimestamp = now - 300_000 // 5 min ago
        )

        val isD1Online = onlineDevice.isOnline && (now - onlineDevice.lastSeenTimestamp < 120_000)
        val isD2Online = offlineDevice.isOnline && (now - offlineDevice.lastSeenTimestamp < 120_000)

        assertTrue("Device with recent heartbeat must be detected as online", isD1Online)
        assertFalse("Device with stale heartbeat or offline flag must be detected as offline", isD2Online)
    }
}
