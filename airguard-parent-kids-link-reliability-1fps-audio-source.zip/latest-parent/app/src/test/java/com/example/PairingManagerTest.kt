package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.manager.PairingManager
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PairingManagerTest {

    private lateinit var context: Context
    private lateinit var pairingManager: PairingManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        pairingManager = PairingManager(context)
    }

    @Test
    fun testGenerateSecurePairingToken() {
        val token1 = pairingManager.generateSecurePairingToken(32)
        val token2 = pairingManager.generateSecurePairingToken(32)

        assertTrue("Token should start with ptk_ prefix", token1.startsWith("ptk_"))
        assertEquals("Token should have 64 hex characters + 4 prefix chars", 68, token1.length)
        assertNotEquals("Cryptographically secure random tokens must be unique", token1, token2)
    }

    @Test
    fun testGenerateSecurePairingCode() {
        val code = pairingManager.generateSecurePairingCode()
        val parts = code.split(" ")
        assertEquals("Pairing code must have 3 parts", 3, parts.size)
        parts.forEach { part ->
            assertEquals("Each part must be 3 digits", 3, part.length)
            val number = part.toIntOrNull()
            assertNotNull("Part must be numeric", number)
            assertTrue("Part must be between 100 and 999", number!! in 100..999)
        }
    }

    @Test
    fun testGenerateQrCodePayload() {
        val token = "ptk_1234567890abcdef"
        val code = "492 817 305"
        val device = "Vivo I2208"
        val payload = pairingManager.generateQrCodePayload(token, code, device, "test_uid")

        assertTrue("Payload should contain AirDroid Kids deep link", payload.contains("https://apps.airdroid.com/kids/pair"))
        assertTrue("Payload should contain token", payload.contains("token=$token"))
        assertTrue("Payload should contain cleaned code", payload.contains("code=492817305"))
        assertTrue("Payload should contain encoded device name", payload.contains("device=Vivo%20I2208"))
    }
}
