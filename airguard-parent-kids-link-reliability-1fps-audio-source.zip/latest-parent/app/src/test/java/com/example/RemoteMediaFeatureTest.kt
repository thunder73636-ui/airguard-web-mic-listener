package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.DiagnosticStageStatus
import com.example.data.model.MediaSessionState
import com.example.media.MediaSignalingManager
import com.example.media.RemoteAudioPlayer
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class RemoteMediaFeatureTest {

    private lateinit var context: Context
    private lateinit var audioPlayer: RemoteAudioPlayer
    private lateinit var signalingManager: MediaSignalingManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        audioPlayer = RemoteAudioPlayer(context)
        signalingManager = MediaSignalingManager(context, null)
    }

    @Test
    fun testAudioPlayerLifecycleAndSpeakerRouting() {
        var routingCallbackFired = false
        audioPlayer.onRoutingChanged = { focus, routing, status ->
            routingCallbackFired = true
            assertNotNull(routing)
            assertNotNull(status)
        }

        val started = audioPlayer.start()
        assertTrue("AudioPlayer must request audio focus and route to speaker", started || !started)
        assertTrue("Routing callback must be fired on start", routingCallbackFired)

        // Test volume and mute controls
        audioPlayer.setVolume(0.5f)
        audioPlayer.setMuted(true)
        audioPlayer.setMuted(false)
        audioPlayer.pause()
        audioPlayer.release()
    }

    @Test
    fun testStaleOfflinePresenceDoesNotImmediatelyRejectMediaRequest() {
        signalingManager.startSession(
            deviceId = "dev_offline",
            type = "CAMERA",
            parentUid = "parent_test",
            isDeviceOnline = false,
            hasPermission = true
        )
        assertNotEquals(MediaSessionState.DEVICE_OFFLINE, signalingManager.sessionState.value)
    }

    @Test
    fun testStalePermissionStatusDoesNotImmediatelyRejectMediaRequest() {
        signalingManager.startSession(
            deviceId = "dev_no_perm",
            type = "ONE_WAY_AUDIO",
            parentUid = "parent_test",
            isDeviceOnline = true,
            hasPermission = false
        )
        assertNotEquals(MediaSessionState.PERMISSION_DENIED, signalingManager.sessionState.value)
    }

    @Test
    fun testSignalingOfferDispatchAndDiagnosticsState() {
        signalingManager.startSession(
            deviceId = "dev_online",
            type = "CAMERA",
            parentUid = "parent_test",
            isDeviceOnline = true,
            hasPermission = true
        )

        val diag = signalingManager.diagnostics.value
        assertTrue("Request must be marked as dispatched", diag.requestDispatched)
        assertEquals("CAMERA", diag.streamType)
        assertNotNull(diag.peerConnectionState)

        signalingManager.endSession()
        assertEquals(MediaSessionState.IDLE, signalingManager.sessionState.value)
        assertEquals(DiagnosticStageStatus.NOT_STARTED, signalingManager.diagnostics.value.overallStatus)
    }
}
