package com.example.media

import com.example.data.model.MediaSessionState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TurnServerConfigTest {
    @Test
    fun parsesMultipleRelayTransportsAndRemovesDuplicates() {
        assertEquals(
            listOf("turn:relay.example:3478?transport=udp", "turns:relay.example:5349?transport=tcp"),
            TurnServerConfig.urls(" turn:relay.example:3478?transport=udp ; turns:relay.example:5349?transport=tcp, turn:relay.example:3478?transport=udp ")
        )
    }

    @Test
    fun requiresAValidTurnUrlAndBothCredentials() {
        assertTrue(TurnServerConfig.isConfigured("turn:relay.example:3478,turns:relay.example:5349", "u", "p"))
        assertFalse(TurnServerConfig.isConfigured("stun:relay.example:3478", "u", "p"))
        assertFalse(TurnServerConfig.isConfigured("turn:relay.example:3478", "", "p"))
    }

    @Test
    fun acceptsMeteredStunAlongsideTurnUrls() {
        assertTrue(TurnServerConfig.isIceServerUrl("stun:stun.relay.metered.ca:80"))
        assertTrue(TurnServerConfig.isIceServerUrl("turns:relay.example:443?transport=tcp"))
        assertFalse(TurnServerConfig.isIceServerUrl("https://relay.example"))
    }

    @Test
    fun relayRetryIsBoundedAndOnlyForRecoverableMediaStates() {
        assertTrue(MediaRecoveryPolicy.shouldRetryWithTurn(MediaSessionState.FAILED, true, false, false))
        assertTrue(MediaRecoveryPolicy.shouldRetryWithTurn(MediaSessionState.DISCONNECTED, true, false, false))
        assertFalse(MediaRecoveryPolicy.shouldRetryWithTurn(MediaSessionState.PERMISSION_DENIED, true, false, false))
        assertFalse(MediaRecoveryPolicy.shouldRetryWithTurn(MediaSessionState.DEVICE_OFFLINE, true, false, false))
        assertFalse(MediaRecoveryPolicy.shouldRetryWithTurn(MediaSessionState.FAILED, false, false, false))
        assertFalse(MediaRecoveryPolicy.shouldRetryWithTurn(MediaSessionState.FAILED, true, true, false))
        assertFalse(MediaRecoveryPolicy.shouldRetryWithTurn(MediaSessionState.FAILED, true, false, true))
    }
}
